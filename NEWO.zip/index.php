<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';
$page_title = 'Home';
$page_description = 'Explore and learn new skills with our digital courses.';

// Student Context
$student_teacher_id = $_SESSION['student_teacher_id'] ?? null;
$teacher_where = $student_teacher_id ? "(teacher_id IS NULL OR teacher_id = $student_teacher_id)" : "teacher_id IS NULL";
$teacher_where_aliased = $student_teacher_id ? "(c.teacher_id IS NULL OR c.teacher_id = $student_teacher_id)" : "c.teacher_id IS NULL";

// Fetch active banners
$banners = $conn->query("SELECT image, link FROM banners WHERE status = 'active' AND deleted_at IS NULL AND $teacher_where ORDER BY id DESC LIMIT 10");

// Fetch latest courses
$latest_courses = $conn->query("SELECT id, title, mrp, price, image FROM courses WHERE status = 'active' AND deleted_at IS NULL AND $teacher_where ORDER BY created_at DESC LIMIT 10");

// Fetch top courses (most purchased)
$top_courses = $conn->query("SELECT c.id, c.title, c.mrp, c.price, c.image, COUNT(o.id) as sales FROM courses c LEFT JOIN orders o ON c.id = o.course_id AND o.status = 'success' WHERE c.status = 'active' AND c.deleted_at IS NULL AND $teacher_where_aliased GROUP BY c.id ORDER BY sales DESC LIMIT 10");

// Fetch categories
$categories = $conn->query("SELECT id, name FROM categories WHERE $teacher_where ORDER BY name");

include 'common/header.php';
?>

<main>
    <!-- Search Bar -->
    <div class="px-4 py-3">
        <form action="/course.php" method="GET" class="relative">
            <input type="text" name="q" placeholder="Search courses..."
                class="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 text-gray-900 focus:outline-none focus:border-primary">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
        </form>
    </div>

    <!-- Banner Slider -->
    <?php if ($banners && $banners->num_rows > 0): ?>
        <div class="relative overflow-hidden mb-4" id="slider-container">
            <div id="slider" class="flex transition-transform duration-500" style="will-change: transform;">
                <?php while ($b = $banners->fetch_assoc()): ?>
                    <div class="w-full flex-shrink-0 px-4">
                        <a href="<?php echo clean($b['link'] ?: '#'); ?>" class="block">
                            <img src="/uploads/banners/<?php echo clean($b['image']); ?>" alt="Banner"
                                class="w-full aspect-video object-cover" loading="lazy">
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <script>
            (function () {
                const slider = document.getElementById('slider');
                if (!slider) return;
                const slides = slider.children;
                if (slides.length <= 1) return;
                let current = 0;
                let startX = 0;
                let isDragging = false;

                function goTo(i) {
                    current = (i + slides.length) % slides.length;
                    slider.style.transform = 'translateX(-' + (current * 100) + '%)';
                }

                setInterval(() => goTo(current + 1), 4000);

                slider.addEventListener('touchstart', e => { startX = e.touches[0].clientX; isDragging = true; });
                slider.addEventListener('touchend', e => {
                    if (!isDragging) return;
                    isDragging = false;
                    const diff = startX - e.changedTouches[0].clientX;
                    if (Math.abs(diff) > 50) goTo(current + (diff > 0 ? 1 : -1));
                });
            })();
        </script>
    <?php endif; ?>

    <!-- Categories -->
    <?php if ($categories && $categories->num_rows > 0): ?>
        <div class="px-4 mb-4">
            <div class="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
                <a href="/course.php" class="flex-shrink-0 px-4 py-2 bg-primary text-white text-sm font-medium">All</a>
                <?php while ($cat = $categories->fetch_assoc()): ?>
                    <a href="/course.php?cat=<?php echo $cat['id']; ?>"
                        class="flex-shrink-0 px-4 py-2 bg-white text-gray-700 text-sm font-medium border border-gray-200"><?php echo clean($cat['name']); ?></a>
                <?php endwhile; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Latest Courses (Horizontal Scroll) -->
    <?php if ($latest_courses && $latest_courses->num_rows > 0): ?>
        <section class="mb-6">
            <div class="flex items-center justify-between px-4 mb-3">
                <h2 class="text-lg font-bold text-gray-900">Latest Courses</h2>
                <a href="/course.php?sort=latest" class="text-primary text-sm font-medium">View All</a>
            </div>
            <div class="flex gap-3 overflow-x-auto px-4 hide-scrollbar">
                <?php while ($c = $latest_courses->fetch_assoc()):
                    $discount = $c['mrp'] > 0 ? round((($c['mrp'] - $c['price']) / $c['mrp']) * 100) : 0;
                    ?>
                    <a href="/course_detail.php?id=<?php echo $c['id']; ?>" class="flex-shrink-0 w-44 bg-white shadow-sm">
                        <img src="/uploads/courses/<?php echo clean($c['image']); ?>" alt="<?php echo clean($c['title']); ?>"
                            class="w-full aspect-video object-cover" loading="lazy">
                        <div class="p-3">
                            <h3 class="text-sm font-semibold text-gray-900 line-clamp-2 mb-2"><?php echo clean($c['title']); ?>
                            </h3>
                            <div class="flex items-center gap-2">
                                <span
                                    class="text-primary font-bold text-sm">&#8377;<?php echo number_format($c['price']); ?></span>
                                <?php if ($c['mrp'] > $c['price']): ?>
                                    <span
                                        class="text-gray-400 text-xs line-through">&#8377;<?php echo number_format($c['mrp']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Top Courses (Grid) -->
    <?php if ($top_courses && $top_courses->num_rows > 0): ?>
        <section class="mb-6">
            <div class="flex items-center justify-between px-4 mb-3">
                <h2 class="text-lg font-bold text-gray-900">Top Courses</h2>
                <a href="/course.php" class="text-primary text-sm font-medium">View All</a>
            </div>
            <div class="grid grid-cols-2 gap-3 px-4">
                <?php while ($c = $top_courses->fetch_assoc()):
                    $discount = $c['mrp'] > 0 ? round((($c['mrp'] - $c['price']) / $c['mrp']) * 100) : 0;
                    ?>
                    <a href="/course_detail.php?id=<?php echo $c['id']; ?>" class="bg-white shadow-sm">
                        <div class="relative">
                            <img src="/uploads/courses/<?php echo clean($c['image']); ?>"
                                alt="<?php echo clean($c['title']); ?>" class="w-full aspect-video object-cover" loading="lazy">
                            <?php if ($discount > 0): ?>
                                <span
                                    class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-0.5 font-bold"><?php echo $discount; ?>%
                                    OFF</span>
                            <?php endif; ?>
                        </div>
                        <div class="p-3">
                            <h3 class="text-sm font-semibold text-gray-900 line-clamp-2 mb-2"><?php echo clean($c['title']); ?>
                            </h3>
                            <div class="flex items-center gap-2">
                                <span
                                    class="text-primary font-bold text-sm">&#8377;<?php echo number_format($c['price']); ?></span>
                                <?php if ($c['mrp'] > $c['price']): ?>
                                    <span
                                        class="text-gray-400 text-xs line-through">&#8377;<?php echo number_format($c['mrp']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php include 'common/bottom.php'; ?>