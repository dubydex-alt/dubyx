<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

// Add community_url to settings if it doesn't exist
$check_sql = "SELECT id FROM settings WHERE setting_key = 'community_url'";
$result = $conn->query($check_sql);

if ($result && $result->num_rows === 0) {
    if ($conn->query("INSERT INTO settings (setting_key, setting_value) VALUES ('community_url', '')")) {
        echo "Successfully added community_url to settings table.\n";
    } else {
        echo "Error adding setting: " . $conn->error . "\n";
    }
} else {
    echo "community_url already exists in settings.\n";
}
?>