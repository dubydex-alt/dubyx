<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting OneSignal migration...\n";

// 1. Add onesignal_id to users table
$check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'onesignal_id'");
if ($check_column->num_rows == 0) {
    if ($conn->query("ALTER TABLE users ADD COLUMN onesignal_id VARCHAR(255) DEFAULT NULL AFTER email")) {
        echo "Column 'onesignal_id' added to 'users' table.\n";
    } else {
        echo "Error adding 'onesignal_id' column: " . $conn->error . "\n";
    }
} else {
    echo "Column 'onesignal_id' already exists in 'users' table.\n";
}

// 2. Add OneSignal settings to settings table
$settings_cols = [
    'onesignal_app_id' => "VARCHAR(255) DEFAULT NULL",
    'onesignal_rest_key' => "VARCHAR(255) DEFAULT NULL"
];

foreach ($settings_cols as $col => $type) {
    $check_settings = $conn->query("SHOW COLUMNS FROM settings LIKE '$col'");
    if ($check_settings->num_rows == 0) {
        if ($conn->query("ALTER TABLE settings ADD COLUMN $col $type")) {
            echo "Column '$col' added to 'settings' table.\n";
        } else {
            echo "Error adding '$col' column: " . $conn->error . "\n";
        }
    } else {
        echo "Column '$col' already exists in 'settings' table.\n";
    }
}

echo "Migration finished.\n";
?>