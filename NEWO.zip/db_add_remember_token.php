<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

/**
 * db_add_remember_token.php
 * Run once to add the remember_token column to existing installs.
 */
require_once 'common/config.php';

$check = $conn->query("SHOW COLUMNS FROM `users` LIKE 'remember_token'");
if ($check && $check->num_rows == 0) {
    if ($conn->query("ALTER TABLE `users` ADD COLUMN `remember_token` VARCHAR(128) DEFAULT NULL AFTER `session_token`")) {
        echo "✅ Column 'remember_token' added to 'users' table successfully.";
    } else {
        echo "❌ Error: " . $conn->error;
    }
} else {
    echo "ℹ️ Column 'remember_token' already exists.";
}
?>