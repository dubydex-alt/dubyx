<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';
$page_title = 'Courses';
$page_description = 'Browse all courses available on ' . $settings['app_name'];

// Filters
$cat = isset($_GET['cat']) ? (int) $_GET['cat'] : 0;
$sort = $_GET['sort'] ?? 'latest';
$search = trim($_GET['q'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

// Build query
$where = "WHERE c.status = 'active' AND c.deleted_at IS NULL";
$params = [];
$types = "";

if ($cat > 0) {
    $where .= " AND c.category_id = ?";
    $params[] = $cat;
    $types .= "i";
}
if ($search !== '') {
    $where .= " AND c.title LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

$order = "ORDER BY c.created_at DESC";
if ($sort === 'price_low')
    $order = "ORDER BY c.price ASC";
if ($sort === 'price_high')
    $order = "ORDER BY c.price DESC";

// Count
$count_sql = "SELECT COUNT(*) as total FROM courses c $where";
$stmt = $conn->prepare($count_sql);
if (!empty($types))
    $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();
$total_pages = ceil($total / $limit);

// Fetch courses
$sql = "SELECT c.id, c.title, c.mrp, c.price, c.image, cat.name as category_name FROM courses c LEFT JOIN categories cat ON c.category_id = cat.id $where $order LIMIT ? OFFSET ?";
$params[] = $limit;
$types .= "i";
$params[] = $offset;
$types .= "i";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$courses = $stmt->get_result();
$stmt->close();

// Fetch categories for filter
$categories = $conn->query("SELECT id, name FROM categories ORDER BY name");

include 'common/header.php';
?>

<main class="p-4">
    <!-- Search -->
    <form action="/course.php" method="GET" class="relative mb-4">
        <input type="text" name="q" value="<?php echo clean($search); ?>" placeholder="Search courses..."
            class="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 text-gray-900 focus:outline-none focus:border-primary">
        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
        <?php if ($cat > 0): ?><input type="hidden" name="cat" value="<?php echo $cat; ?>"><?php endif; ?>
    </form>

    <!-- Filters -->
    <div class="flex gap-3 mb-4">
        <select onchange="applyFilter()" id="filter-cat"
            class="flex-1 px-3 py-2 bg-white border border-gray-200 text-gray-700 text-sm focus:outline-none">
            <option value="0">All Categories</option>
            <?php while ($c = $categories->fetch_assoc()): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo $cat == $c['id'] ? 'selected' : ''; ?>>
                    <?php echo clean($c['name']); ?></option>
            <?php endwhile; ?>
        </select>
        <select onchange="applyFilter()" id="filter-sort"
            class="flex-1 px-3 py-2 bg-white border border-gray-200 text-gray-700 text-sm focus:outline-none">
            <option value="latest" <?php echo $sort === 'latest' ? 'selected' : ''; ?>>Latest</option>
            <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low</option>
            <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High</option>
        </select>
    </div>

    <!-- Results Count -->
    <p class="text-gray-500 text-sm mb-3"><?php echo $total; ?> course<?php echo $total !== 1 ? 's' : ''; ?> found</p>

    <!-- Course Grid -->
    <?php if ($courses->num_rows > 0): ?>
        <div class="grid grid-cols-2 gap-3" id="course-grid">
            <?php while ($c = $courses->fetch_assoc()):
                $discount = $c['mrp'] > 0 ? round((($c['mrp'] - $c['price']) / $c['mrp']) * 100) : 0;
                ?>
                <a href="/course_detail.php?id=<?php echo $c['id']; ?>" class="bg-white shadow-sm">
                    <div class="relative">
                        <img src="/uploads/courses/<?php echo clean($c['image']); ?>" alt="<?php echo clean($c['title']); ?>"
                            class="w-full aspect-video object-cover" loading="lazy">
                        <?php if ($discount > 0): ?>
                            <span
                                class="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-0.5 font-bold"><?php echo $discount; ?>%
                                OFF</span>
                        <?php endif; ?>
                    </div>
                    <div class="p-3">
                        <h3 class="text-sm font-semibold text-gray-900 line-clamp-2 mb-1"><?php echo clean($c['title']); ?></h3>
                        <?php if ($c['category_name']): ?>
                            <p class="text-xs text-gray-400 mb-2"><?php echo clean($c['category_name']); ?></p>
                        <?php endif; ?>
                        <div class="flex items-center gap-2">
                            <span class="text-primary font-bold text-sm">&#8377;<?php echo number_format($c['price']); ?></span>
                            <?php if ($c['mrp'] > $c['price']): ?>
                                <span
                                    class="text-gray-400 text-xs line-through">&#8377;<?php echo number_format($c['mrp']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="flex items-center justify-center gap-2 mt-6">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&cat=<?php echo $cat; ?>&sort=<?php echo $sort; ?>&q=<?php echo urlencode($search); ?>"
                        class="px-4 py-2 bg-white border text-gray-700 text-sm">Prev</a>
                <?php endif; ?>
                <span class="px-4 py-2 bg-primary text-white text-sm"><?php echo $page; ?> / <?php echo $total_pages; ?></span>
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&cat=<?php echo $cat; ?>&sort=<?php echo $sort; ?>&q=<?php echo urlencode($search); ?>"
                        class="px-4 py-2 bg-white border text-gray-700 text-sm">Next</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="text-center py-12">
            <i class="fas fa-book-open text-4xl text-gray-300 mb-4"></i>
            <p class="text-gray-500">No courses found.</p>
        </div>
    <?php endif; ?>
</main>

<script>
    function applyFilter() {
        const cat = document.getElementById('filter-cat').value;
        const sort = document.getElementById('filter-sort').value;
        window.location.href = '/course.php?cat=' + cat + '&sort=' + sort;
    }
</script>

<?php include 'common/bottom.php'; ?>