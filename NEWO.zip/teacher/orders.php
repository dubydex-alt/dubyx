<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
$page_title = 'My Orders';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher_features = $_SESSION['teacher_features'] ?? [];

if (!in_array('orders', $teacher_features)) {
    die("Access Denied: Orders management feature is disabled for your account.");
}

include 'common/header.php';

// Pagination
$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filter by status
$status_filter = isset($_GET['status']) ? clean($_GET['status']) : '';
$where = "c.teacher_id = $teacher_id";
if ($status_filter && in_array($status_filter, ['success', 'failed', 'pending', 'refunded'])) {
    $where .= " AND o.status = '" . $conn->real_escape_string($status_filter) . "'";
}

$total_query = $conn->query("SELECT COUNT(*) as c FROM orders o JOIN courses c ON o.course_id = c.id WHERE $where");
$total = $total_query ? $total_query->fetch_assoc()['c'] : 0;
$total_pages = ceil($total / $limit);

$orders = $conn->query("SELECT o.*, u.name as user_name, u.email as user_email, c.title as course_title 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN courses c ON o.course_id = c.id 
    WHERE $where 
    ORDER BY o.created_at DESC 
    LIMIT $limit OFFSET $offset");
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">My Orders</h2>

    <!-- Filter -->
    <div class="flex gap-2 mb-4 overflow-x-auto pb-2">
        <a href="/teacher/orders.php"
            class="px-4 py-2 text-sm font-medium whitespace-nowrap <?php echo !$status_filter ? 'bg-primary text-white' : 'bg-white text-gray-700'; ?>">All</a>
        <a href="/teacher/orders.php?status=success"
            class="px-4 py-2 text-sm font-medium whitespace-nowrap <?php echo $status_filter === 'success' ? 'bg-green-600 text-white' : 'bg-white text-gray-700'; ?>">Success</a>
        <a href="/teacher/orders.php?status=pending"
            class="px-4 py-2 text-sm font-medium whitespace-nowrap <?php echo $status_filter === 'pending' ? 'bg-yellow-600 text-white' : 'bg-white text-gray-700'; ?>">Pending</a>
        <a href="/teacher/orders.php?status=failed"
            class="px-4 py-2 text-sm font-medium whitespace-nowrap <?php echo $status_filter === 'failed' ? 'bg-red-600 text-white' : 'bg-white text-gray-700'; ?>">Failed</a>
        <a href="/teacher/orders.php?status=refunded"
            class="px-4 py-2 text-sm font-medium whitespace-nowrap <?php echo $status_filter === 'refunded' ? 'bg-gray-600 text-white' : 'bg-white text-gray-700'; ?>">Refunded</a>
    </div>

    <!-- Orders List -->
    <div class="space-y-3">
        <?php if ($orders && $orders->num_rows > 0): ?>
            <?php while ($o = $orders->fetch_assoc()): ?>
                <div class="bg-white p-4 shadow-sm">
                    <div class="flex items-start justify-between mb-2">
                        <div>
                            <p class="font-semibold text-gray-900 text-sm">
                                <?php echo clean($o['user_name']); ?>
                            </p>
                            <p class="text-xs text-gray-500">
                                <?php echo clean($o['user_email']); ?>
                            </p>
                        </div>
                        <?php
                        $status_colors = [
                            'success' => 'bg-green-100 text-green-700',
                            'failed' => 'bg-red-100 text-red-700',
                            'pending' => 'bg-yellow-100 text-yellow-700',
                            'refunded' => 'bg-gray-100 text-gray-700'
                        ];
                        $sc = $status_colors[$o['status']] ?? 'bg-gray-100 text-gray-700';
                        ?>
                        <span class="px-2 py-1 text-xs font-medium <?php echo $sc; ?>">
                            <?php echo ucfirst($o['status']); ?>
                        </span>
                    </div>
                    <p class="text-sm text-gray-700 mb-2">
                        <?php echo clean($o['course_title']); ?>
                    </p>
                    <div class="flex items-center justify-between text-xs text-gray-500">
                        <span>&#8377;
                            <?php echo number_format($o['amount']); ?>
                        </span>
                        <span>
                            <?php echo date('d M Y, H:i', strtotime($o['created_at'])); ?>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="bg-white p-8 text-center border-2 border-dashed border-gray-200">
                <i class="fas fa-shopping-cart text-4xl text-gray-200 mb-2"></i>
                <p class="text-gray-500 text-sm">No orders found relating to your courses.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-center gap-2 mt-6">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $status_filter; ?>"
                    class="px-3 py-2 bg-white text-gray-700 text-sm shadow-sm">Prev</a>
            <?php endif; ?>
            <span class="px-3 py-2 text-sm text-gray-500">Page
                <?php echo $page; ?> of
                <?php echo $total_pages; ?>
            </span>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $status_filter; ?>"
                    class="px-3 py-2 bg-white text-gray-700 text-sm shadow-sm">Next</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'common/bottom.php'; ?>