<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'My Support Tickets';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];

// AJAX Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'];
    if ($action === 'close') {
        $id = (int) ($_POST['id'] ?? 0);
        // Teachers can close their own tickets or their students' tickets
        $conn->query("UPDATE tickets SET status = 'closed' WHERE id = $id AND (teacher_id = $teacher_id OR (user_id = $teacher_id AND user_type = 'teacher'))");
        echo json_encode(['success' => true]);
        exit;
    }
    if ($action === 'pending') {
        $id = (int) ($_POST['id'] ?? 0);
        $conn->query("UPDATE tickets SET status = 'pending' WHERE id = $id AND (teacher_id = $teacher_id OR (user_id = $teacher_id AND user_type = 'teacher'))");
        echo json_encode(['success' => true]);
        exit;
    }
}

include 'common/header.php';

$offset = (int) ($_GET['offset'] ?? 0);
$limit = 10;

$tickets = $conn->query("SELECT t.*, u.name as user_name 
                         FROM tickets t 
                         LEFT JOIN users u ON t.user_id = u.id AND t.user_type = 'student'
                         WHERE t.teacher_id = $teacher_id OR (t.user_id = $teacher_id AND t.user_type = 'teacher')
                         ORDER BY t.created_at DESC LIMIT $limit OFFSET $offset");

// Check if there are more
$total_check = $conn->query("SELECT COUNT(id) as total FROM tickets WHERE teacher_id = $teacher_id OR (user_id = $teacher_id AND user_type = 'teacher')")->fetch_assoc();
$has_more = ($offset + $limit) < $total_check['total'];
?>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-bold text-gray-900">Support Tickets</h2>
            <p class="text-xs text-gray-500">Tickets from you and your students.</p>
        </div>
        <button onclick="openModal()" class="bg-primary text-white px-4 py-2 rounded text-sm font-medium">
            <i class="fas fa-plus mr-1"></i>New Ticket
        </button>
    </div>

    <div class="space-y-4">
        <?php if ($tickets->num_rows === 0): ?>
            <div class="bg-white p-12 text-center rounded-xl border-2 border-dashed text-gray-400">
                <i class="fas fa-ticket-alt text-5xl mb-4 opacity-20"></i>
                <p class="font-bold">No tickets raised yet.</p>
            </div>
        <?php else:
            while ($t = $tickets->fetch_assoc()): ?>
                <div class="bg-white rounded-xl shadow-sm border p-5">
                    <div class="flex items-start justify-between mb-4">
                        <div class="flex gap-4">
                            <div
                                class="w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center text-primary border border-gray-100">
                                <i class="fas fa-ticket-alt text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-bold text-gray-900">
                                    <?php echo clean($t['subject']); ?>
                                </h3>
                                <div class="flex items-center gap-2 mt-1">
                                    <span
                                        class="text-[10px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded <?php echo $t['user_type'] === 'teacher' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'; ?>">
                                        <?php echo $t['user_type']; ?>
                                    </span>
                                    <span class="text-xs text-gray-500 font-medium">
                                        From:
                                        <?php echo clean($t['user_name'] ?: 'You'); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <span
                                class="px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest 
                                <?php echo $t['status'] === 'open' ? 'bg-green-100 text-green-600' : ($t['status'] === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'); ?>">
                                <?php echo $t['status']; ?>
                            </span>
                            <div class="flex items-center gap-2">
                                <?php if ($t['status'] === 'open'): ?>
                                    <button onclick="ticketAction(<?php echo $t['id']; ?>, 'pending')"
                                        class="text-[10px] font-black uppercase text-yellow-600 hover:underline">
                                        Pending
                                    </button>
                                <?php endif; ?>
                                <?php if ($t['status'] !== 'closed'): ?>
                                    <button onclick="ticketAction(<?php echo $t['id']; ?>, 'close')"
                                        class="text-[10px] font-black uppercase text-primary hover:underline">
                                        Close
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div
                        class="bg-gray-50 p-4 rounded-xl border border-gray-100 italic text-sm text-gray-600 leading-relaxed mb-4">
                        "
                        <?php echo nl2br(clean($t['message'])); ?>"
                    </div>

                    <div
                        class="flex items-center justify-between text-[10px] text-gray-400 font-bold uppercase tracking-widest border-t pt-4">
                        <span>Ticket ID: #
                            <?php echo $t['id']; ?>
                        </span>
                        <span>Date:
                            <?php echo date('d M Y - h:i A', strtotime($t['created_at'])); ?>
                        </span>
                    </div>
                </div>
            <?php endwhile;
        endif; ?>
        <?php if ($has_more): ?>
            <div class="text-center mt-8">
                <a href="?offset=<?php echo $offset + $limit; ?>" class="text-primary font-bold text-sm hover:underline">
                    Load More Tickets <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- New Ticket Modal -->
<div id="new-ticket-modal" class="fixed inset-0 bg-black/50 z-[9999] hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl p-8 shadow-2xl">
        <div class="flex items-center justify-between mb-8">
            <h3 class="font-black text-gray-900 text-xl tracking-tight">Raise a Ticket</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form onsubmit="handleTicketSubmit(event)" class="space-y-5">
            <div>
                <label
                    class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Subject</label>
                <input type="text" id="t-subject" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl">
            </div>
            <div>
                <label
                    class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Message</label>
                <textarea id="t-message" rows="4" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl"></textarea>
            </div>
            <button type="submit" id="t-btn"
                class="w-full bg-primary text-white py-5 font-black rounded-2xl shadow-xl shadow-primary/25 uppercase tracking-widest transition-all hover:scale-[1.02]">Submit
                Ticket</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function openModal() { document.getElementById('new-ticket-modal').classList.remove('hidden'); }
    function closeModal() { document.getElementById('new-ticket-modal').classList.add('hidden'); }

    function ticketAction(id, action) {
        if (!confirm('Mark this ticket as ' + action + '?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action);
        data.append('id', id);

        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => { if (res.success) location.reload(); });
    }

    function handleTicketSubmit(e) {
        e.preventDefault();
        const btn = document.getElementById('t-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Submitting...';

        const data = new FormData();
        data.append('action', 'raise_ticket');
        data.append('csrf_token', csrfToken);
        data.append('subject', document.getElementById('t-subject').value);
        data.append('message', document.getElementById('t-message').value);

        fetch('/help.php', { method: 'POST', body: data })
            .then(r => r.text())
            .then(() => {
                location.reload();
            });
    }
</script>

<?php include 'common/bottom.php'; ?>