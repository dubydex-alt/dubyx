<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
$page_title = 'My Students';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher_features = $_SESSION['teacher_features'] ?? [];

if (!in_array('students', $teacher_features)) {
    die("Access Denied: Student management feature is disabled for your account.");
}

// Handle AJAX actions (e.g., blocking a student)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    // Verify ownership: Student must belong to this teacher
    $check = $conn->prepare("SELECT id FROM users WHERE id = ? AND teacher_id = ?");
    $check->bind_param("ii", $id, $teacher_id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Access denied.']);
        exit;
    }

    if ($action === 'block') {
        $conn->query("UPDATE users SET status = 'blocked' WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Student blocked.']);
        exit;
    }
    if ($action === 'unblock') {
        $conn->query("UPDATE users SET status = 'active' WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Student activated.']);
        exit;
    }

    if ($action === 'get_student_access') {
        $courses = $conn->query("SELECT id, title FROM courses WHERE teacher_id = $teacher_id AND deleted_at IS NULL ORDER BY title ASC");
        $access = [];
        while ($c = $courses->fetch_assoc()) {
            $check = $conn->query("SELECT status FROM orders WHERE user_id = $id AND course_id = {$c['id']} AND status = 'success' LIMIT 1");
            $c['has_access'] = ($check && $check->num_rows > 0);
            $access[] = $c;
        }
        echo json_encode(['success' => true, 'access' => $access]);
        exit;
    }

    if ($action === 'grant_access') {
        $course_id = (int) ($_POST['course_id'] ?? 0);
        $c_check = $conn->query("SELECT id FROM courses WHERE id = $course_id AND teacher_id = $teacher_id");
        if ($c_check->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid course.']);
            exit;
        }
        $stmt = $conn->prepare("INSERT INTO orders (user_id, course_id, amount, status, razorpay_order_id, created_at) VALUES (?, ?, 0, 'success', ?, NOW()) ON DUPLICATE KEY UPDATE status = 'success', razorpay_order_id = VALUES(razorpay_order_id), created_at = NOW()");
        $manual_id = "MANUAL_GRANT_" . $teacher_id . "_" . time();
        $stmt->bind_param("iis", $id, $course_id, $manual_id);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => true, 'message' => 'Access granted.']);
        exit;
    }

    if ($action === 'revoke_access') {
        $course_id = (int) ($_POST['course_id'] ?? 0);
        $conn->query("UPDATE orders SET status = 'refunded' WHERE user_id = $id AND course_id = $course_id AND razorpay_order_id LIKE 'MANUAL_GRANT_%'");
        echo json_encode(['success' => true, 'message' => 'Access revoked.']);
        exit;
    }
}

$students = $conn->query("SELECT * FROM users WHERE teacher_id = $teacher_id AND deleted_at IS NULL ORDER BY name ASC");

include 'common/header.php';
?>

<main class="p-4">
    <div class="mb-4">
        <h2 class="text-lg font-bold text-gray-900">My Students</h2>
        <p class="text-xs text-gray-500">List of students who signed up with your Teacher ID.</p>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="bg-white shadow-sm overflow-x-auto">
        <table class="w-full text-left text-sm">
            <thead class="bg-gray-50 text-gray-600 font-medium border-b">
                <tr>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Email/Phone</th>
                    <th class="px-4 py-3">Joined</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php if ($students && $students->num_rows > 0): ?>
                    <?php while ($s = $students->fetch_assoc()): ?>
                        <tr>
                            <td class="px-4 py-3">
                                <div class="flex items-center">
                                    <div
                                        class="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-2 font-bold">
                                        <?php echo strtoupper(substr($s['name'], 0, 1)); ?>
                                    </div>
                                    <span class="font-medium text-gray-900">
                                        <?php echo clean($s['name']); ?>
                                    </span>
                                </div>
                            </td>
                            <td class="px-4 py-3">
                                <p class="text-gray-900">
                                    <?php echo clean($s['email']); ?>
                                </p>
                                <p class="text-[10px] text-gray-500">
                                    <?php echo clean($s['phone']); ?>
                                </p>
                            </td>
                            <td class="px-4 py-3 text-gray-600">
                                <?php echo date('d M Y', strtotime($s['created_at'])); ?>
                            </td>
                            <td class="px-4 py-3">
                                <span
                                    class="px-2 py-1 rounded-full text-[10px] font-bold <?php echo $s['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                    <?php echo strtoupper($s['status']); ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-right flex items-center justify-end gap-3">
                                <button
                                    onclick="openAccessModal(<?php echo $s['id']; ?>, '<?php echo addslashes(clean($s['name'])); ?>')"
                                    class="text-primary hover:text-primary-dark text-xs font-semibold">Access</button>
                                <?php if ($s['status'] === 'active'): ?>
                                    <button onclick="studentAction(<?php echo $s['id']; ?>, 'block')"
                                        class="text-orange-500 hover:text-orange-700 text-xs font-semibold">Block</button>
                                <?php else: ?>
                                    <button onclick="studentAction(<?php echo $s['id']; ?>, 'unblock')"
                                        class="text-green-500 hover:text-green-700 text-xs font-semibold">Unblock</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="px-4 py-8 text-center text-gray-500">No students yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<!-- Access Management Modal -->
<div id="access-modal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        <div class="p-4 border-b flex items-center justify-between">
            <h3 class="font-bold text-gray-900" id="access-modal-title">Course Access</h3>
            <button onclick="closeAccessModal()" class="text-gray-400 hover:text-gray-600"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <div id="access-list" class="flex-1 overflow-y-auto p-4 space-y-3">
            <!-- Courses load here -->
            <div class="py-10 text-center text-gray-500">
                <i class="fas fa-spinner fa-spin text-2xl mb-2"></i>
                <p>Loading course access...</p>
            </div>
        </div>
        <div class="p-4 bg-gray-50 border-t text-right">
            <button onclick="closeAccessModal()"
                class="px-4 py-2 text-sm font-medium text-gray-700 border bg-white hover:bg-gray-50 rounded">Close</button>
        </div>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';
    let currentStudentId = null;

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function openAccessModal(studentId, studentName) {
        currentStudentId = studentId;
        document.getElementById('access-modal-title').textContent = 'Access: ' + studentName;
        document.getElementById('access-modal').classList.remove('hidden');
        loadAccessList();
    }

    function closeAccessModal() {
        document.getElementById('access-modal').classList.add('hidden');
    }

    function loadAccessList() {
        const list = document.getElementById('access-list');
        list.innerHTML = '<div class="py-10 text-center text-gray-500"><i class="fas fa-spinner fa-spin text-2xl mb-2"></i><p>Loading course access...</p></div>';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'get_student_access');
        data.append('id', currentStudentId);

        fetch('/teacher/students.php', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    if (res.access.length === 0) {
                        list.innerHTML = '<p class="text-center py-4 text-gray-500">You haven\'t added any courses yet.</p>';
                        return;
                    }
                    let html = '';
                    res.access.forEach(c => {
                        html += `
                            <div class="flex items-center justify-between p-3 border rounded">
                                <span class="text-sm font-medium text-gray-800">${c.title}</span>
                                ${c.has_access ?
                                `<button onclick="toggleAccess(${c.id}, 'revoke')" class="px-3 py-1 bg-red-100 text-red-700 text-[10px] font-bold rounded uppercase">Revoke</button>` :
                                `<button onclick="toggleAccess(${c.id}, 'grant')" class="px-3 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded uppercase">Grant Access</button>`
                            }
                            </div>
                        `;
                    });
                    list.innerHTML = html;
                } else {
                    list.innerHTML = `<p class="text-red-500 text-sm text-center py-4">${res.message}</p>`;
                }
            })
            .catch(() => {
                list.innerHTML = '<p class="text-red-500 text-sm text-center py-4">Error loading data.</p>';
            });
    }

    function toggleAccess(courseId, action) {
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action === 'grant' ? 'grant_access' : 'revoke_access');
        data.append('id', currentStudentId);
        data.append('course_id', courseId);

        fetch('/teacher/students.php', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    loadAccessList();
                } else {
                    alert(res.message);
                }
            });
    }

    function studentAction(id, action) {
        if (!confirm('Are you sure you want to ' + action + ' this student?')) return;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action);
        data.append('id', id);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/teacher/students.php', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                showAlert(res.message, res.success ? 'success' : 'error');
                if (res.success) setTimeout(() => location.reload(), 500);
            } catch (e) { showAlert('Error processing request.', 'error'); }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>