<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$live_id = (int) ($_GET['live_id'] ?? 0);

if ($live_id <= 0) {
    header('Location: /teacher/courses.php');
    exit;
}

// Fetch live session details
$stmt = $conn->prepare("SELECT ls.*, c.id as course_id, c.title as course_title 
                        FROM live_sessions ls 
                        JOIN courses c ON ls.course_id = c.id 
                        WHERE ls.id = ? AND ls.teacher_id = ?");
$teacher_id = $_SESSION['teacher_id'];
$stmt->bind_param("ii", $live_id, $teacher_id);
$stmt->execute();
$video = $stmt->get_result()->fetch_assoc();
$stmt->close();

$teacher_features = $_SESSION['teacher_features'] ?? [];
$is_live_chat_enabled = in_array('live_chat', $teacher_features);

if (!$video) {
    header('Location: /teacher/courses.php');
    exit;
}

$video['type'] = 'youtube'; // Live always YouTube in this implementation
$video['chapter_title'] = 'Live Session';
$course_id = $video['course_id'];

// Layout classes based on chat visibility
$player_cols = $is_live_chat_enabled ? 'lg:col-span-2' : 'lg:col-span-3 max-w-5xl mx-auto';
$chat_cols = $is_live_chat_enabled ? 'lg:col-span-1' : 'hidden';

// Extract YouTube ID for Plyr
$yt_id = '';
if (preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $video['url'], $matches)) {
    $yt_id = $matches[1];
}

$page_title = "Moderating: " . $video['title'];
include 'common/header.php';
?>

<!-- Plyr CSS -->
<link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css" />

<style>
    .plyr--youtube.plyr--video .plyr__video-wrapper iframe {
        top: -50%;
        height: 200%;
    }

    .plyr--full-ui.plyr--video .plyr__control--overlaid {
        background: var(--primary-color, #0284c7);
    }

    .plyr--full-ui.plyr--video .plyr__control:hover {
        background: var(--primary-color, #0284c7);
    }

    .player-container {
        position: relative;
    }

    .yt-mask-top {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 60px;
        z-index: 10;
        background: rgba(0, 0, 0, 0.1);
        pointer-events: none;
    }

    .yt-mask-bottom {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 50px;
        z-index: 10;
        background: transparent;
        pointer-events: none;
    }

    #chat-box::-webkit-scrollbar {
        width: 4px;
    }

    #chat-box::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 10px;
    }

    #sending-indicator {
        height: 2px;
        width: 0%;
        background: #0284c7;
        transition: width 0.3s ease;
    }

    /* Teacher Highlighted Comment */
    .comment-teacher {
        background: #f0f9ff !important;
        border: 1px solid #bae6fd !important;
        align-self: flex-end !important;
    }

    .comment-teacher .user-label {
        color: #0369a1 !important;
    }
</style>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="mb-4">
        <a href="/teacher/live.php?course_id=<?php echo $course_id; ?>" class="text-primary text-sm font-medium">
            <i class="fas fa-arrow-left mr-1"></i> Back to Live Center
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Player Area -->
        <div class="<?php echo $player_cols; ?> space-y-6">
            <div class="player-container shadow-2xl rounded-2xl overflow-hidden bg-black border border-gray-200">
                <div class="yt-mask-top"></div>
                <div id="player" data-plyr-provider="youtube" data-plyr-embed-id="<?php echo $yt_id; ?>"></div>
                <div class="yt-mask-bottom"></div>
            </div>

            <div class="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm relative overflow-hidden">
                <div class="absolute top-0 right-0 p-4">
                    <span
                        class="px-3 py-1 bg-red-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full animate-pulse flex items-center gap-1">
                        <span class="w-1.5 h-1.5 bg-white rounded-full"></span> LIVE
                    </span>
                </div>
                <div class="flex items-center gap-2 text-[10px] font-black text-red-600 uppercase tracking-widest mb-2">
                    <i class="fas fa-satellite-dish animate-pulse"></i> Live Moderation Mode
                </div>
                <h1 class="text-2xl font-bold text-gray-900 tracking-tight">
                    <?php echo clean($video['title']); ?>
                </h1>
                <div class="flex items-center justify-between mt-4">
                    <p class="text-gray-500 text-sm">
                        Course: <strong><?php echo clean($video['course_title']); ?></strong>
                    </p>
                    <button onclick="openTicketModal()" class="text-primary text-xs font-bold hover:underline">
                        <i class="fas fa-ticket-alt mr-1"></i> Problem? Raise Ticket
                    </button>
                </div>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="<?php echo $chat_cols; ?>">
            <div
                class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[calc(100vh-140px)] sticky top-20">
                <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                    <h3 class="font-black text-gray-900 text-sm flex items-center gap-2">
                        <i class="fas fa-comments text-primary"></i> LIVE CHAT
                    </h3>
                    <div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                        Moderator Panel
                    </div>
                </div>

                <div id="chat-box" class="flex-1 overflow-y-auto p-6 space-y-4 bg-white flex flex-col">
                    <div class="text-center text-gray-400 text-xs py-20 italic">
                        Initializing chat...
                    </div>
                </div>

                <div id="sending-indicator"></div>
                <div class="p-4 bg-gray-50 border-t border-gray-200">
                    <form id="chat-form" class="flex gap-2" data-no-loader>
                        <input type="text" id="chat-input" placeholder="Post as Teacher..." required
                            class="flex-1 bg-white border border-gray-300 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-primary">
                        <button type="submit" id="chat-send-btn"
                            class="bg-primary text-white p-2 w-10 h-10 rounded-xl flex items-center justify-center hover:bg-primary-dark transition-colors">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php if ($is_live_chat_enabled): ?>
    <script>
        let lastCommentId = 0;
        let firstCommentId = 0;
        let isLoadingOlder = false;
        let hasMoreOlder = true;
        const liveId = <?php echo $live_id; ?>;
        const chatBox = document.getElementById('chat-box');
        const chatForm = document.getElementById('chat-form');
        const chatInput = document.getElementById('chat-input');
        const sendingIndicator = document.getElementById('sending-indicator');

        function createCommentEl(c, isOptimistic = false) {
            const div = document.createElement('div');
            let classes = 'rounded-2xl px-4 py-2 max-w-[90%] self-start border flex flex-col transition-all ';

            if (c.is_teacher) {
                classes += 'bg-blue-50 border-blue-100 comment-teacher ';
            } else {
                classes += 'bg-gray-50 border-gray-100 ';
            }

            if (isOptimistic) classes += 'opacity-50 ';
            div.className = classes;

            if (isOptimistic) div.id = 'optimistic-' + Date.now();

            let blockBtn = '';
            if (!c.is_teacher && c.user_id) {
                const btnClass = c.is_blocked ? 'text-green-600' : 'text-red-600';
                const btnText = c.is_blocked ? 'Unblock' : 'Block';
                blockBtn = `<button onclick="toggleBlock(this, ${c.user_id}, ${!c.is_blocked})" class="ml-2 text-[8px] font-black uppercase tracking-widest ${btnClass} hover:underline transition-colors">
                ${btnText}
            </button>`;
            }

            div.innerHTML = `
            <div class="flex items-center justify-between gap-4 mb-1">
                <div class="flex items-center gap-2">
                    <span class="text-[10px] font-black ${c.is_teacher ? 'text-blue-700' : 'text-primary'} uppercase user-label">${c.user}</span>
                    <span class="text-[8px] text-gray-400">${c.time}</span>
                </div>
                ${blockBtn}
            </div>
            <p class="text-sm text-gray-700 leading-relaxed">${c.message}</p>
        `;
            return div;
        }

        function toggleBlock(btn, uid, block) {
            // Instant visual feedback
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            btn.disabled = true;

            const data = new FormData();
            data.append('action', 'block');
            data.append('live_id', liveId);
            data.append('user_id', uid);
            data.append('block', block);

            fetch('/api/comments.php', { method: 'POST', body: data })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        const newBlockStatus = block;
                        btn.textContent = newBlockStatus ? 'Unblock' : 'Block';
                        btn.className = `ml-2 text-[8px] font-black uppercase tracking-widest ${newBlockStatus ? 'text-green-600' : 'text-red-600'} hover:underline transition-colors`;
                        btn.onclick = () => toggleBlock(btn, uid, !newBlockStatus);
                        btn.disabled = false;
                    } else {
                        alert(res.message);
                        location.reload();
                    }
                });
        }

        function fetchComments() {
            fetch(`/api/comments.php?action=fetch&live_id=${liveId}&last_id=${lastCommentId}`)
                .then(r => r.json())
                .then(res => {
                    if (res.success && res.comments.length > 0) {
                        const wasAtBottom = chatBox.scrollHeight - chatBox.scrollTop <= chatBox.clientHeight + 50;

                        res.comments.forEach(c => {
                            const opt = document.querySelector(`[data-msg="${btoa(c.message)}"]`);
                            if (opt) opt.remove();

                            chatBox.appendChild(createCommentEl(c));
                            lastCommentId = c.id;
                            if (firstCommentId === 0) firstCommentId = c.id;
                        });

                        if (wasAtBottom) chatBox.scrollTop = chatBox.scrollHeight;
                    }
                });
        }

        function loadOlderComments() {
            if (isLoadingOlder || !hasMoreOlder || firstCommentId === 0) return;
            isLoadingOlder = true;
            const oldHeight = chatBox.scrollHeight;
            fetch(`/api/comments.php?action=load_older&live_id=${liveId}&before_id=${firstCommentId}`)
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        if (res.comments.length === 0) {
                            hasMoreOlder = false;
                        } else {
                            res.comments.reverse().forEach(c => {
                                chatBox.prepend(createCommentEl(c));
                                firstCommentId = c.id;
                            });
                            chatBox.scrollTop = chatBox.scrollHeight - oldHeight;
                        }
                    }
                    isLoadingOlder = false;
                });
        }

        chatBox.onscroll = () => { if (chatBox.scrollTop === 0) loadOlderComments(); };

        chatForm.onsubmit = (e) => {
            e.preventDefault();
            const msg = chatInput.value.trim();
            if (!msg) return;

            const tempC = { user: 'You', message: msg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), is_teacher: true };
            const tempEl = createCommentEl(tempC, true);
            tempEl.setAttribute('data-msg', btoa(msg));
            chatBox.appendChild(tempEl);
            chatBox.scrollTop = chatBox.scrollHeight;

            sendingIndicator.style.width = '30%';

            const data = new FormData();
            data.append('action', 'post');
            data.append('live_id', liveId);
            data.append('message', msg);

            chatInput.value = '';
            fetch('/api/comments.php', { method: 'POST', body: data })
                .then(r => r.json())
                .then(res => {
                    sendingIndicator.style.width = '100%';
                    setTimeout(() => sendingIndicator.style.width = '0%', 500);
                    if (!res.success) {
                        alert(res.message);
                        tempEl.remove();
                    }
                    fetchComments();
                });
        };

        fetchComments();
        setInterval(fetchComments, 2000);
    </script>
<?php endif; ?>

<!-- Ticket Modal -->
<div id="ticket-modal" class="fixed inset-0 bg-black/50 z-[9999] hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl p-8 shadow-2xl transform transition-all">
        <div class="flex items-center justify-between mb-8">
            <h3 class="font-black text-gray-900 text-xl tracking-tight">Raise a Ticket</h3>
            <button onclick="closeTicketModal()" class="text-gray-400 hover:text-gray-600"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form onsubmit="handleTicketSubmit(event)" class="space-y-5">
            <div>
                <label
                    class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Subject</label>
                <input type="text" id="t-subject" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl">
            </div>
            <div>
                <label
                    class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Message</label>
                <textarea id="t-message" rows="4" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl"></textarea>
            </div>
            <button type="submit" id="t-btn"
                class="w-full bg-primary text-white py-5 font-black rounded-2xl shadow-xl shadow-primary/25 uppercase tracking-widest">Submit
                Ticket</button>
        </form>
    </div>
</div>

<script>
    function openTicketModal() { document.getElementById('ticket-modal').classList.remove('hidden'); }
    function closeTicketModal() { document.getElementById('ticket-modal').classList.add('hidden'); }

    function handleTicketSubmit(e) {
        e.preventDefault();
        const btn = document.getElementById('t-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Submitting...';

        const data = new FormData();
        data.append('action', 'raise_ticket');
        data.append('csrf_token', '<?php echo csrf_token(); ?>');
        data.append('subject', document.getElementById('t-subject').value);
        data.append('message', document.getElementById('t-message').value);

        fetch('/help.php', { method: 'POST', body: data })
            .then(r => r.text())
            .then(() => {
                alert('Ticket raised successfully!');
                closeTicketModal();
                btn.disabled = false;
                btn.innerHTML = 'Submit Ticket';
                document.getElementById('t-subject').value = '';
                document.getElementById('t-message').value = '';
            });
    }
</script>

<!-- Plyr JS -->
<script src="https://cdn.plyr.io/3.7.8/plyr.polyfilled.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        if (document.getElementById('player')) {
            new Plyr('#player', {
                controls: ['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'],
                youtube: { noCookie: true, rel: 0, showinfo: 0, iv_load_policy: 3, modestbranding: 1, autoplay: 1 }
            });
        }
    });
</script>

<?php include 'common/bottom.php'; ?>