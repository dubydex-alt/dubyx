</div>
</div>

<footer class="bg-white border-t py-4 lg:ml-64">
    <div class="px-4 text-center text-sm text-gray-500">
        &copy;
        <?php echo date('Y'); ?>
        <?php echo clean($settings['app_name']); ?>. All rights reserved.
    </div>
</footer>

</body>

</html>