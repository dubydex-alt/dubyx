<?php
if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

// Refresh features from DB to handle admin updates without relog
$teacher_id = $_SESSION['teacher_id'];
$t_stmt = $conn->prepare("SELECT features, logo FROM teachers WHERE id = ?");
$t_stmt->bind_param("i", $teacher_id);
$t_stmt->execute();
$t_res = $t_stmt->get_result()->fetch_assoc();
$t_stmt->close();

if ($t_res) {
    $_SESSION['teacher_features'] = json_decode($t_res['features'] ?? '[]', true);
    $_SESSION['teacher_logo'] = $t_res['logo'];
}

$teacher_features = $_SESSION['teacher_features'] ?? [];
$teacher_logo = $_SESSION['teacher_logo'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo $page_title; ?> - Teacher Panel
    </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { primary: '#0284C7', 'primary-dark': '#0369A1' } } } }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .sidebar-active {
            background: #0284C7;
            color: white;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen">

    <header class="bg-white shadow-sm border-b sticky top-0 z-40">
        <div class="flex items-center justify-between px-4 py-3">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebar()" class="text-gray-500 lg:hidden focus:outline-none">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div class="flex items-center gap-2">
                    <?php if ($teacher_logo): ?>
                        <img src="/<?php echo $teacher_logo; ?>" class="h-8 w-8 object-cover">
                    <?php else: ?>
                        <i class="fas fa-chalkboard-teacher text-primary text-xl"></i>
                    <?php endif; ?>
                    <h1 class="font-bold text-gray-900 hidden sm:block">Teacher Panel</h1>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-sm text-gray-600 hidden md:block">Welcome, <strong>
                        <?php echo clean($_SESSION['teacher_name']); ?>
                    </strong></span>
                <a href="/logout.php" class="text-red-500 text-sm font-medium hover:underline">Logout</a>
            </div>
        </div>
    </header>

    <div class="flex">
        <?php include 'sidebar.php'; ?>
        <div class="flex-1 lg:ml-64 min-h-[calc(100vh-60px)]">