<?php
$current = basename($_SERVER['PHP_SELF']);
$teacher_features = $_SESSION['teacher_features'] ?? [];

$links = [
    ['index.php', 'fas fa-chart-line', 'Dashboard', 'always'],
    ['courses.php', 'fas fa-book', 'My Courses', 'courses'],
    ['students.php', 'fas fa-users', 'My Students', 'students'],
    ['orders.php', 'fas fa-shopping-cart', 'My Orders', 'orders'],
    ['banners.php', 'fas fa-images', 'My Banners', 'banners'],
    ['notifications.php', 'fas fa-bell', 'Notifications', 'notifications'],
    ['live.php', 'fas fa-satellite-dish', 'Live Sessions', 'live_sessions'],
    ['community.php', 'fas fa-comments', 'Community Manager', 'community'],
    ['tickets.php', 'fas fa-ticket-alt', 'Tickets', 'always'],
    ['settings.php', 'fas fa-cog', 'Settings', 'always'],
];
?>
<nav id="teacher-sidebar"
    class="fixed top-0 left-0 h-full w-64 bg-gray-900 z-50 transform -translate-x-full lg:translate-x-0 transition-transform duration-300">
    <div class="p-4 border-b border-gray-700 flex items-center justify-between lg:block">
        <div>
            <h2 class="text-white font-bold text-lg">
                <?php echo clean($settings['app_name']); ?>
            </h2>
            <p class="text-gray-400 text-xs">Teacher Dashboard</p>
        </div>
        <button onclick="toggleSidebar()" class="text-gray-400 lg:hidden">
            <i class="fas fa-times text-xl"></i>
        </button>
    </div>
    <div class="py-2">
        <?php foreach ($links as $l):
            if ($l[3] !== 'always' && !in_array($l[3], $teacher_features))
                continue;
            $active = $current === $l[0] ? 'bg-primary text-white' : 'text-gray-300 hover:bg-gray-800';
            ?>
            <a href="/teacher/<?php echo $l[0]; ?>"
                class="flex items-center gap-3 px-4 py-3 text-sm <?php echo $active; ?>">
                <i class="<?php echo $l[1]; ?> w-5 text-center"></i>
                <span>
                    <?php echo $l[2]; ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>
</nav>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('teacher-sidebar');
        sidebar.classList.toggle('-translate-x-full');
    }
</script>