<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
$page_title = 'Manage Live Sessions';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher_features = $_SESSION['teacher_features'] ?? [];

if (!in_array('live_sessions', $teacher_features)) {
    die("Access Denied: Live Sessions feature is disabled for your account.");
}

$course_id = (int) ($_GET['course_id'] ?? 0);

if ($course_id <= 0) {
    header('Location: /teacher/courses.php');
    exit;
}

// Verify ownership
$course_check = $conn->prepare("SELECT title FROM courses WHERE id = ? AND teacher_id = ?");
$course_check->bind_param("ii", $course_id, $teacher_id);
$course_check->execute();
$course = $course_check->get_result()->fetch_assoc();

if (!$course) {
    header('Location: /teacher/courses.php');
    exit;
}

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $status = $_POST['status'] ?? 'upcoming';
        $scheduled_at = $_POST['scheduled_at'] ?? null;

        if (empty($title) || empty($url)) {
            echo json_encode(['success' => false, 'message' => 'Title and URL are required.']);
            exit;
        }

        if ($id === 0) {
            $stmt = $conn->prepare("INSERT INTO live_sessions (course_id, teacher_id, title, url, status, scheduled_at) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iissss", $course_id, $teacher_id, $title, $url, $status, $scheduled_at);
        } else {
            // Verify ownership of session
            $s_check = $conn->prepare("SELECT id FROM live_sessions WHERE id = ? AND course_id = ? AND teacher_id = ?");
            $s_check->bind_param("iii", $id, $course_id, $teacher_id);
            $s_check->execute();
            if ($s_check->get_result()->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => 'Access denied.']);
                exit;
            }
            $stmt = $conn->prepare("UPDATE live_sessions SET title = ?, url = ?, status = ?, scheduled_at = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $title, $url, $status, $scheduled_at, $id);
        }
        $stmt->execute();
        $stmt->close();

        if ($status === 'ended' && $id > 0) {
            $conn->query("DELETE FROM live_comments WHERE live_id = $id");
            $conn->query("DELETE FROM live_blocks WHERE live_id = $id");
        }

        echo json_encode(['success' => true, 'message' => 'Live session saved!']);
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $conn->query("DELETE FROM live_sessions WHERE id = $id AND course_id = $course_id AND teacher_id = $teacher_id");
        echo json_encode(['success' => true]);
        exit;
    }
}

include 'common/header.php';
?>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="mb-4">
        <a href="/teacher/courses.php" class="text-primary text-sm font-medium"><i
                class="fas fa-arrow-left mr-1"></i>Back to Courses</a>
    </div>

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
            <h1 class="text-xl font-bold text-gray-900">
                <?php echo clean($course['title']); ?>
            </h1>
            <p class="text-xs text-red-600 font-black uppercase tracking-widest animate-pulse"><i
                    class="fas fa-satellite-dish mr-1"></i> Teacher Live Center</p>
        </div>
        <button onclick="openModal()"
            class="bg-primary text-white px-5 py-2.5 text-sm font-bold flex items-center justify-center gap-2 rounded shadow-lg shadow-primary/20">
            <i class="fas fa-plus"></i> Go Live / Schedule
        </button>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php
        $sessions = $conn->query("SELECT * FROM live_sessions WHERE course_id = $course_id AND teacher_id = $teacher_id ORDER BY scheduled_at DESC, id DESC");
        if ($sessions->num_rows === 0): ?>
            <div class="col-span-full bg-white border-2 border-dashed rounded-2xl p-20 text-center text-gray-400">
                <i class="fas fa-video-slash text-5xl mb-4 opacity-20"></i>
                <p class="font-bold">You haven't added any live sessions yet.</p>
                <p class="text-xs mt-2">Click the button above to start your first live stream.</p>
            </div>
        <?php else:
            while ($s = $sessions->fetch_assoc()): ?>
                <div
                    class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 group hover:border-primary transition-all">
                    <div class="flex items-center justify-between mb-4">
                        <span
                            class="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest
                            <?php echo $s['status'] === 'live' ? 'bg-red-500 text-white animate-pulse' : ($s['status'] === 'upcoming' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'); ?>">
                            <?php echo $s['status']; ?>
                        </span>
                        <div class="flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity items-center">
                            <?php if ($s['status'] === 'live'): ?>
                                <a href="/teacher/play.php?live_id=<?php echo $s['id']; ?>" target="_blank"
                                    class="text-xs font-black text-red-600 uppercase tracking-widest hover:underline mr-2">
                                    <i class="fas fa-play mr-1"></i> Play
                                </a>
                            <?php endif; ?>
                            <button onclick='openModal(<?php echo json_encode($s); ?>)'
                                class="text-gray-400 hover:text-primary"><i class="fas fa-edit"></i></button>
                            <button onclick="deleteSession(<?php echo $s['id']; ?>)" class="text-gray-400 hover:text-red-500"><i
                                    class="fas fa-trash-alt"></i></button>
                        </div>
                    </div>
                    <h3 class="font-bold text-gray-900 mb-2">
                        <?php echo clean($s['title']); ?>
                    </h3>
                    <div
                        class="flex items-center gap-2 text-[10px] text-gray-500 font-bold bg-gray-50 p-2.5 rounded-xl border border-gray-100 mb-4 truncate italic">
                        <i class="fas fa-link text-primary/50"></i>
                        <?php echo clean($s['url']); ?>
                    </div>
                    <div class="flex items-center gap-2 text-[10px] text-gray-600 font-black tracking-widest uppercase">
                        <i class="fas fa-clock text-gray-400"></i>
                        <?php echo $s['scheduled_at'] ? date('D, d M - h:i A', strtotime($s['scheduled_at'])) : 'Unscheduled'; ?>
                    </div>
                </div>
            <?php endwhile;
        endif; ?>
    </div>
</main>

<!-- Modal -->
<div id="modal" class="fixed inset-0 bg-black/50 z-[9999] hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl p-8 shadow-2xl">
        <div class="flex items-center justify-between mb-8">
            <h3 class="font-black text-gray-900 text-xl tracking-tight" id="modal-title">Go Live</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 transition-colors"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form id="live-form" class="space-y-5">
            <input type="hidden" id="s-id" value="0">
            <div>
                <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Live
                    Title</label>
                <input type="text" id="s-title" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 text-sm rounded-2xl transition-all"
                    placeholder="e.g. Weekly Doubts Session">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Stream
                    Link (YouTube)</label>
                <input type="url" id="s-url" required
                    class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 text-sm rounded-2xl transition-all"
                    placeholder="https://youtube.com/live/...">
            </div>
            <div class="grid grid-cols-2 gap-5">
                <div>
                    <label
                        class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Status</label>
                    <select id="s-status"
                        class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl transition-all">
                        <option value="upcoming">Upcoming</option>
                        <option value="live">Live Now</option>
                        <option value="ended">Ended</option>
                    </select>
                </div>
                <div>
                    <label
                        class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Time</label>
                    <input type="datetime-local" id="s-time"
                        class="w-full px-5 py-4 border border-gray-200 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm rounded-2xl transition-all">
                </div>
            </div>
            <button type="submit" id="submit-btn"
                class="w-full bg-primary text-white py-5 font-black rounded-2xl shadow-xl shadow-primary/25 transition-all hover:scale-[1.02] active:scale-[0.98] mt-4 uppercase tracking-widest">Publish
                Live Session</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function openModal(s = null) {
        document.getElementById('s-id').value = s ? s.id : 0;
        document.getElementById('s-title').value = s ? s.title : '';
        document.getElementById('s-url').value = s ? s.url : '';
        document.getElementById('s-status').value = s ? s.status : 'upcoming';
        document.getElementById('s-time').value = s ? s.scheduled_at.replace(' ', 'T') : '';
        document.getElementById('modal-title').textContent = s ? 'Edit Live Session' : 'Setup Live Stream';
        document.getElementById('modal').classList.remove('hidden');
    }

    function closeModal() { document.getElementById('modal').classList.add('hidden'); }

    document.getElementById('live-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('submit-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Publishing...';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'save');
        data.append('id', document.getElementById('s-id').value);
        data.append('title', document.getElementById('s-title').value);
        data.append('url', document.getElementById('s-url').value);
        data.append('status', document.getElementById('s-status').value);
        data.append('scheduled_at', document.getElementById('s-time').value);

        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json()).then(res => { if (res.success) location.reload(); });
    });

    function deleteSession(id) {
        if (!confirm('Cancel this live session?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);
        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json()).then(res => { if (res.success) location.reload(); });
    }
</script>

<?php include 'common/bottom.php'; ?>