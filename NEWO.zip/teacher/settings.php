<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Settings';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];

// Get current settings
$stmt = $conn->prepare("SELECT settings FROM teachers WHERE id = ?");
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$current_settings = json_decode($row['settings'] ?? '{}', true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $new_settings = [
        'disable_student_groups' => isset($_POST['disable_student_groups']) ? true : false
    ];
    $json_settings = json_encode($new_settings);

    $stmt = $conn->prepare("UPDATE teachers SET settings = ? WHERE id = ?");
    $stmt->bind_param("si", $json_settings, $teacher_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Settings updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
    exit;
}

include 'common/header.php';
?>

<main class="p-4 md:p-6">
    <div class="max-w-2xl mx-auto">
        <h2 class="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <i class="fas fa-cog text-primary"></i> Teacher Settings
        </h2>

        <div id="alert" class="hidden mb-6 p-4 rounded-xl text-sm font-medium transition-all"></div>

        <form id="settings-form" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

            <!-- Community Controls -->
            <div class="bg-white p-6 shadow-sm border border-gray-100 rounded-2xl">
                <h3 class="text-sm font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <i class="fas fa-users text-xs"></i> Community & Discussion
                </h3>

                <label
                    class="flex items-center justify-between p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition-all border border-transparent hover:border-blue-100 group">
                    <div class="flex items-center gap-4">
                        <div
                            class="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-blue-600 shadow-sm border border-blue-50">
                            <i class="fas fa-comment-slash"></i>
                        </div>
                        <div>
                            <p class="text-sm font-bold text-gray-900">Disable Student Group Creation</p>
                            <p class="text-xs text-gray-500">Students won't be able to start new topics, only reply to
                                yours.</p>
                        </div>
                    </div>
                    <div class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="disable_student_groups" class="sr-only peer" <?php echo ($current_settings['disable_student_groups'] ?? false) ? 'checked' : ''; ?>>
                        <div
                            class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600">
                        </div>
                    </div>
                </label>
            </div>

            <button type="submit" id="save-btn"
                class="w-full bg-primary text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 hover:shadow-blue-200 transition-all active:scale-[0.98]">
                Save Changes
            </button>
        </form>
    </div>
</main>

<script>
    document.getElementById('settings-form').onsubmit = function (e) {
        e.preventDefault();
        const btn = document.getElementById('save-btn');
        const alert = document.getElementById('alert');
        const originalText = btn.innerText;

        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin mr-2"></i>Saving...';

        const data = new FormData(this);
        fetch('settings.php', {
            method: 'POST',
            body: data
        })
            .then(res => res.json())
            .then(data => {
                btn.disabled = false;
                btn.innerText = originalText;

                alert.classList.remove('hidden', 'bg-green-100', 'text-green-800', 'bg-red-100', 'text-red-800');
                if (data.success) {
                    alert.classList.add('bg-green-100', 'text-green-800');
                    alert.innerHTML = `<i class="fas fa-check-circle mr-2"></i> ${data.message}`;
                } else {
                    alert.classList.add('bg-red-100', 'text-red-800');
                    alert.innerHTML = `<i class="fas fa-exclamation-circle mr-2"></i> ${data.message}`;
                }
            })
            .catch(() => {
                btn.disabled = false;
                btn.innerText = originalText;
                alert.classList.remove('hidden');
                alert.classList.add('bg-red-100', 'text-red-800');
                alert.innerHTML = '<i class="fas fa-exclamation-circle mr-2"></i> Network error. Please try again.';
            });
    };
</script>

<?php include 'common/bottom.php'; ?>