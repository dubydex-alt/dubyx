<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Send Notifications';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $msg = 'Invalid request';
        $msg_type = 'error';
    } else {
        $title = clean($_POST['title']);
        $message = clean($_POST['message']);
        $target = clean($_POST['target']); // 'all' or 'course_ID'

        if ($title && $message) {
            if ($target === 'all') {
                $users = $conn->query("SELECT id FROM users WHERE teacher_id = $teacher_id AND deleted_at IS NULL AND status = 'active'");
                $count = 0;
                while ($u = $users->fetch_assoc()) {
                    send_notification($conn, $u['id'], $title, $message);
                    $count++;
                }
                $msg = "Notification sent to all ($count) students.";
                $msg_type = 'success';
            } elseif (strpos($target, 'course_') === 0) {
                $course_id = (int) str_replace('course_', '', $target);
                // Find users who bought this course and belong to this teacher
                $users = $conn->query("SELECT u.id FROM users u JOIN orders o ON u.id = o.user_id WHERE u.teacher_id = $teacher_id AND o.course_id = $course_id AND o.status = 'success' AND u.deleted_at IS NULL");
                $count = 0;
                while ($u = $users->fetch_assoc()) {
                    send_notification($conn, $u['id'], $title, $message);
                    $count++;
                }
                $msg = "Notification sent to $count students of selected course.";
                $msg_type = 'success';
            }
        } else {
            $msg = 'Title and message are required.';
            $msg_type = 'error';
        }
    }
}

$my_courses = $conn->query("SELECT id, title FROM courses WHERE teacher_id = $teacher_id AND deleted_at IS NULL AND status = 'active' ORDER BY title");

include 'common/header.php';
?>

<main class="p-4">
    <h2 class="text-xl font-bold text-gray-900 mb-6 font-display">Send Notification</h2>

    <?php if ($msg): ?>
        <div
            class="p-4 mb-6 rounded-xl text-sm flex items-center gap-3 <?php echo $msg_type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'; ?>">
            <i class="fas <?php echo $msg_type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <p>
                <?php echo $msg; ?>
            </p>
        </div>
    <?php endif; ?>

    <div class="bg-white shadow-sm p-6 rounded-xl border border-gray-100 max-w-2xl mx-auto">
        <form method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="send">

            <div>
                <label class="block text-sm font-bold text-gray-700 mb-1 px-1">Target Audience</label>
                <select name="target"
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary">
                    <option value="all">All My Students</option>
                    <optgroup label="Course Specific Students">
                        <?php while ($c = $my_courses->fetch_assoc()): ?>
                            <option value="course_<?php echo $c['id']; ?>">
                                <?php echo clean($c['title']); ?>
                            </option>
                        <?php endwhile; ?>
                    </optgroup>
                </select>
                <p class="text-[10px] text-gray-400 mt-1 px-1">Students will receive both a push notification and an
                    in-app message.</p>
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-700 mb-1 px-1">Notification Title</label>
                <input type="text" name="title" required placeholder="e.g. New Content Available!"
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary">
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-700 mb-1 px-1">Message Content</label>
                <textarea name="message" rows="4" required placeholder="Describe your announcement..."
                    class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-primary"></textarea>
            </div>

            <button type="submit"
                class="w-full bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 mt-6">
                <i class="fas fa-paper-plane"></i> Send Push Notification
            </button>
        </form>
    </div>
</main>

<?php include 'common/bottom.php'; ?>