<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Community Support';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
include 'common/header.php';
?>

<div class="max-w-4xl mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-10 text-center">
        <h1 class="text-3xl font-black text-gray-900 mb-2">Community Support</h1>
        <p class="text-gray-500 font-medium">Answer student doubts and manage the community.</p>
    </div>

    <!-- Official Post Section -->
    <div class="bg-white rounded-[2rem] shadow-xl shadow-indigo-100/50 p-6 mb-10 border border-indigo-50">
        <div id="post-alert" class="hidden mb-4 p-4 rounded-2xl text-sm font-bold"></div>
        <form id="doubt-form" class="space-y-4" data-no-loader>
            <input type="hidden" name="action" value="post">
            <input type="hidden" name="parent_id" value="0">
            <div class="relative">
                <textarea name="message" required
                    class="w-full bg-gray-50 border-none rounded-3xl px-6 py-5 text-gray-900 placeholder:text-gray-400 focus:ring-2 focus:ring-indigo-500 min-h-[120px] transition-all"
                    placeholder="Post an announcement or answer common doubts..."></textarea>
                <div class="absolute right-4 bottom-4">
                    <button type="submit" id="post-btn"
                        class="bg-indigo-600 text-white font-black px-8 py-3 rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
                        Post Announcement
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Doubt Feed -->
    <div id="doubt-feed" class="space-y-8">
        <!-- Feed loaded via AJAX -->
    </div>

    <!-- Load More -->
    <div id="load-more-container" class="mt-12 text-center hidden">
        <button id="load-more-btn"
            class="bg-white border-2 border-indigo-50 text-indigo-600 font-bold px-10 py-4 rounded-[2rem] hover:bg-indigo-50 transition-all flex items-center gap-3 mx-auto">
            <span>Load More</span>
            <i class="fas fa-chevron-down text-xs"></i>
        </button>
    </div>

    <div id="initial-loader" class="py-20 text-center">
        <div class="inline-block w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin">
        </div>
    </div>
</div>

<!-- Templates -->
<template id="doubt-template">
    <div
        class="doubt-card bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm transition-all hover:shadow-md">
        <div class="flex items-start justify-between mb-6">
            <div class="flex items-center gap-4">
                <div
                    class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-xl author-avatar">
                    T
                </div>
                <div>
                    <h3 class="font-black text-gray-900 mb-0.5 author-name">Name</h3>
                    <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest post-time">Time</p>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <button
                    class="block-btn hidden bg-red-50 text-red-600 text-[9px] font-black uppercase px-3 py-1.5 rounded-full tracking-widest hover:bg-red-600 hover:text-white transition-all">
                    Block User
                </button>
                <div
                    class="is-teacher-badge hidden bg-indigo-600 text-white text-[9px] font-black uppercase px-3 py-1.5 rounded-full tracking-widest">
                    Instructor
                </div>
            </div>
        </div>

        <div class="text-gray-700 leading-relaxed mb-8 doubt-message whitespace-pre-wrap">
            Message
        </div>

        <hr class="border-gray-50 mb-6">

        <!-- Replies Section -->
        <div class="replies-container space-y-4 mb-6"></div>

        <!-- Reply Form -->
        <form class="reply-form flex gap-3 items-center" data-no-loader>
            <input type="hidden" name="action" value="post">
            <input type="hidden" name="parent_id" class="parent-id-input">
            <input type="text" name="message" required
                class="flex-1 bg-gray-50 border-none rounded-2xl px-5 py-3 text-sm focus:ring-1 focus:ring-indigo-200 transition-all"
                placeholder="Write an official response...">
            <button type="submit"
                class="w-10 h-10 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all flex items-center justify-center">
                <i class="fas fa-paper-plane fa-sm"></i>
            </button>
        </form>
    </div>
</template>

<template id="reply-template">
    <div class="reply-item flex gap-4 p-4 rounded-3xl transition-all border border-transparent">
        <div
            class="w-8 h-8 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center font-bold text-xs reply-avatar">
            R
        </div>
        <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between mb-1">
                <div class="flex items-center gap-2">
                    <span class="font-bold text-gray-900 text-sm reply-author">Author</span>
                    <span
                        class="reply-teacher-badge hidden bg-indigo-100 text-indigo-600 text-[8px] font-black px-2 py-0.5 rounded-full uppercase">Support</span>
                    <span class="text-[9px] text-gray-400 font-bold uppercase reply-time">Time</span>
                </div>
                <button
                    class="reply-block-btn hidden text-[8px] font-black text-red-400 uppercase tracking-tighter hover:text-red-600">
                    Block
                </button>
            </div>
            <p class="text-sm text-gray-600 reply-message">Comment</p>
        </div>
    </div>
</template>

<style>
    body {
        background-color: #f8fafc;
    }

    .reply-item.teacher-highlight {
        background-color: #eef2ff;
        border-color: #e0e7ff;
    }
</style>

<script>
    const doubtFeed = document.getElementById('doubt-feed');
    const doubtTemplate = document.getElementById('doubt-template');
    const replyTemplate = document.getElementById('reply-template');
    const loadMoreBtn = document.getElementById('load-more-btn');
    const loadMoreContainer = document.getElementById('load-more-container');
    const initialLoader = document.getElementById('initial-loader');

    let offset = 0;
    let isLoading = false;

    fetchDoubts();

    function fetchDoubts(append = false) {
        if (isLoading) return;
        isLoading = true;

        fetch(`/api/forum.php?action=fetch&parent_id=0&offset=${offset}`)
            .then(res => res.json())
            .then(data => {
                initialLoader.classList.add('hidden');
                if (data.success) {
                    if (!append) doubtFeed.innerHTML = '';

                    data.posts.forEach(post => {
                        doubtFeed.appendChild(createDoubtCard(post));
                    });

                    offset += data.posts.length;
                    if (data.posts.length === 10) {
                        loadMoreContainer.classList.remove('hidden');
                    } else {
                        loadMoreContainer.classList.add('hidden');
                    }
                }
                isLoading = false;
            })
            .catch(() => { isLoading = false; });
    }

    function createDoubtCard(post) {
        const clone = doubtTemplate.content.cloneNode(true);
        const card = clone.querySelector('.doubt-card');

        card.querySelector('.author-name').innerText = post.author;
        card.querySelector('.author-avatar').innerText = post.author.charAt(0).toUpperCase();
        card.querySelector('.post-time').innerText = post.created_at;
        card.querySelector('.doubt-message').innerText = post.message;
        card.querySelector('.parent-id-input').value = post.id;

        if (post.is_teacher) {
            card.querySelector('.is-teacher-badge').classList.remove('hidden');
            card.querySelector('.author-avatar').classList.replace('bg-indigo-50', 'bg-indigo-600');
            card.querySelector('.author-avatar').classList.replace('text-indigo-600', 'text-white');
        } else {
            // Moderation for students
            const bBtn = card.querySelector('.block-btn');
            bBtn.classList.remove('hidden');
            bBtn.innerText = post.forum_blocked == 1 ? 'Unblock' : 'Block Student';
            bBtn.onclick = () => toggleBlock(post.user_id, bBtn);
        }

        const repliesContainer = card.querySelector('.replies-container');
        fetchReplies(post.id, repliesContainer);

        const form = card.querySelector('.reply-form');
        form.onsubmit = function (e) {
            e.preventDefault();
            const btn = form.querySelector('button');
            const msgInput = form.querySelector('input[name="message"]');
            const msg = msgInput.value.trim();
            if (!msg) return;

            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

            const formData = new FormData(form);
            fetch('/api/forum.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(resData => {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-paper-plane fa-sm"></i>';
                    if (resData.success) {
                        msgInput.value = '';
                        repliesContainer.appendChild(createReplyItem(resData.post));
                    }
                });
        };

        return card;
    }

    function fetchReplies(doubtId, container) {
        fetch(`/api/forum.php?action=fetch&parent_id=${doubtId}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    container.innerHTML = '';
                    data.posts.forEach(reply => {
                        container.appendChild(createReplyItem(reply));
                    });
                }
            });
    }

    function createReplyItem(reply) {
        const clone = replyTemplate.content.cloneNode(true);
        const item = clone.querySelector('.reply-item');

        item.querySelector('.reply-author').innerText = reply.author;
        item.querySelector('.reply-avatar').innerText = reply.author.charAt(0).toUpperCase();
        item.querySelector('.reply-time').innerText = reply.created_at;
        item.querySelector('.reply-message').innerText = reply.message;

        if (reply.is_teacher) {
            item.classList.add('teacher-highlight');
            item.querySelector('.reply-teacher-badge').classList.remove('hidden');
            item.querySelector('.reply-avatar').classList.replace('bg-gray-50', 'bg-indigo-600');
            item.querySelector('.reply-avatar').classList.replace('text-gray-400', 'text-white');
        } else {
            const bBtn = item.querySelector('.reply-block-btn');
            bBtn.classList.remove('hidden');
            bBtn.innerText = reply.forum_blocked == 1 ? 'Unblock' : 'Block';
            bBtn.onclick = () => toggleBlock(reply.user_id, bBtn);
        }

        return item;
    }

    function toggleBlock(userId, btn) {
        const originalText = btn.innerText;
        btn.disabled = true;
        btn.innerText = '...';

        const formData = new FormData();
        formData.append('action', 'toggle_block');
        formData.append('target_user_id', userId);

        fetch('/api/forum.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    btn.innerText = data.blocked ? 'Unblock' : (btn.classList.contains('reply-block-btn') ? 'Block' : 'Block Student');
                    if (data.blocked) {
                        btn.classList.replace('text-red-400', 'text-green-600');
                        btn.classList.replace('bg-red-50', 'bg-green-50');
                        btn.classList.replace('text-red-600', 'text-green-600');
                    } else {
                        btn.classList.replace('text-green-600', 'text-red-400');
                        btn.classList.replace('bg-green-50', 'bg-red-50');
                        btn.classList.replace('text-green-600', 'text-red-600');
                    }
                } else {
                    btn.innerText = originalText;
                    alert(data.message);
                }
            });
    }

    document.getElementById('doubt-form').onsubmit = function (e) {
        e.preventDefault();
        const btn = document.getElementById('post-btn');
        const alert = document.getElementById('post-alert');
        const msg = this.message.value.trim();
        if (!msg) return;

        btn.disabled = true;
        btn.innerHTML = 'Posting...';

        const data = new FormData(this);
        fetch('/api/forum.php', { method: 'POST', body: data })
            .then(res => res.json())
            .then(resData => {
                btn.disabled = false;
                btn.innerHTML = 'Post Announcement';

                if (resData.success) {
                    this.reset();
                    doubtFeed.prepend(createDoubtCard(resData.post));
                    alert.className = "mb-4 p-4 rounded-2xl text-sm font-bold bg-green-50 text-green-700 block";
                    alert.innerText = "Announcement posted!";
                    setTimeout(() => alert.classList.add('hidden'), 3000);
                } else {
                    alert.className = "mb-4 p-4 rounded-2xl text-sm font-bold bg-red-50 text-red-700 block";
                    alert.innerText = resData.message;
                    setTimeout(() => alert.classList.add('hidden'), 3000);
                }
            });
    };

    loadMoreBtn.onclick = () => fetchDoubts(true);
</script>

<?php include 'common/bottom.php'; ?>