<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Dashboard';
require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['teacher_id'])) {
    header('Location: /login_teacher.php');
    exit;
}

$teacher_id = $_SESSION['teacher_id'];

// Get simple stats
$total_students = $conn->query("SELECT COUNT(*) as count FROM users WHERE teacher_id = $teacher_id AND deleted_at IS NULL")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders o JOIN users u ON o.user_id = u.id WHERE u.teacher_id = $teacher_id AND o.status = 'success'")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(o.amount) as total FROM orders o JOIN users u ON o.user_id = u.id WHERE u.teacher_id = $teacher_id AND o.status = 'success'")->fetch_assoc()['total'] ?? 0;

include 'common/header.php';
?>

<main class="p-4 md:p-6">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div class="bg-white p-6 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-blue-100 text-blue-600 flex items-center justify-center rounded-full">
                <i class="fas fa-users text-xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-500 font-medium tracking-tight">Total Students</p>
                <p class="text-2xl font-bold text-gray-900">
                    <?php echo number_format($total_students); ?>
                </p>
            </div>
        </div>
        <div class="bg-white p-6 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-green-100 text-green-600 flex items-center justify-center rounded-full">
                <i class="fas fa-shopping-cart text-xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-500 font-medium tracking-tight">Successful Orders</p>
                <p class="text-2xl font-bold text-gray-900">
                    <?php echo number_format($total_orders); ?>
                </p>
            </div>
        </div>
        <div class="bg-white p-6 shadow-sm flex items-center gap-4">
            <div class="w-12 h-12 bg-orange-100 text-orange-600 flex items-center justify-center rounded-full">
                <i class="fas fa-indian-rupee-sign text-xl"></i>
            </div>
            <div>
                <p class="text-sm text-gray-500 font-medium tracking-tight">My Revenue</p>
                <p class="text-2xl font-bold text-gray-900">₹
                    <?php echo number_format($total_revenue, 2); ?>
                </p>
            </div>
        </div>
    </div>

    <div class="bg-white shadow-sm p-6 mb-6">
        <h3 class="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
        <div class="flex flex-wrap gap-3">
            <?php if (in_array('courses', $teacher_features)): ?>
                <a href="/teacher/courses.php"
                    class="px-4 py-2 bg-primary text-white text-sm font-medium hover:bg-primary-dark transition">Manage
                    Courses</a>
            <?php endif; ?>
            <?php if (in_array('notifications', $teacher_features)): ?>
                <a href="/teacher/notifications.php"
                    class="px-4 py-2 border border-primary text-primary text-sm font-medium hover:bg-blue-50 transition">Send
                    Notification</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Students -->
        <div class="bg-white shadow-sm">
            <div class="p-4 border-b flex items-center justify-between">
                <h3 class="font-bold text-gray-900">Recent Students</h3>
                <a href="/teacher/students.php" class="text-xs text-primary font-medium hover:underline">View All</a>
            </div>
            <div class="p-4">
                <?php
                $recent_students = $conn->query("SELECT * FROM users WHERE teacher_id = $teacher_id AND deleted_at IS NULL ORDER BY id DESC LIMIT 5");
                if ($recent_students && $recent_students->num_rows > 0):
                    while ($s = $recent_students->fetch_assoc()): ?>
                        <div class="flex items-center justify-between py-2 border-b last:border-0">
                            <div class="flex items-center gap-3">
                                <div
                                    class="w-8 h-8 bg-gray-100 text-gray-600 flex items-center justify-center rounded-full text-xs font-bold">
                                    <?php echo strtoupper(substr($s['name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-900">
                                        <?php echo clean($s['name']); ?>
                                    </p>
                                    <p class="text-[10px] text-gray-500">
                                        <?php echo date('d M Y', strtotime($s['created_at'])); ?>
                                    </p>
                                </div>
                            </div>
                            <span
                                class="text-xs <?php echo $s['status'] === 'active' ? 'text-green-600' : 'text-red-600'; ?> font-bold">
                                <?php echo ucfirst($s['status']); ?>
                            </span>
                        </div>
                    <?php endwhile;
                else: ?>
                    <p class="text-center text-gray-500 py-4 text-sm">No students yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="bg-white shadow-sm">
            <div class="p-4 border-b flex items-center justify-between">
                <h3 class="font-bold text-gray-900">Recent Orders</h3>
                <a href="/teacher/orders.php" class="text-xs text-primary font-medium hover:underline">View All</a>
            </div>
            <div class="p-4">
                <?php
                $recent_orders = $conn->query("SELECT o.*, u.name as student_name, c.title as course_title FROM orders o JOIN users u ON o.user_id = u.id JOIN courses c ON o.course_id = c.id WHERE u.teacher_id = $teacher_id AND o.status = 'success' ORDER BY o.id DESC LIMIT 5");
                if ($recent_orders && $recent_orders->num_rows > 0):
                    while ($o = $recent_orders->fetch_assoc()): ?>
                        <div class="flex items-center justify-between py-2 border-b last:border-0">
                            <div>
                                <p class="text-sm font-medium text-gray-900">
                                    <?php echo clean($o['course_title']); ?>
                                </p>
                                <p class="text-[10px] text-gray-500">By
                                    <?php echo clean($o['student_name']); ?> on
                                    <?php echo date('d M Y', strtotime($o['created_at'])); ?>
                                </p>
                            </div>
                            <p class="font-bold text-sm text-green-600">₹
                                <?php echo number_format($o['amount']); ?>
                            </p>
                        </div>
                    <?php endwhile;
                else: ?>
                    <p class="text-center text-gray-500 py-4 text-sm">No orders yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<?php include 'common/bottom.php'; ?>