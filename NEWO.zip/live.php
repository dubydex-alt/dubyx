<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
$page_title = 'Live Sessions';
require_once __DIR__ . '/common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user's purchased course IDs
$purchased_query = $conn->query("SELECT course_id FROM orders WHERE user_id = $user_id AND status = 'success'");
$course_ids = [];
while ($row = $purchased_query->fetch_assoc()) {
    $course_ids[] = $row['course_id'];
}

include 'common/header.php';
?>

<main class="min-h-screen bg-gray-50 pb-20">
    <div class="px-4 py-8 max-w-lg mx-auto">
        <div class="mb-8">
            <h1 class="text-2xl font-black text-gray-900 tracking-tight">Live Hub</h1>
            <p class="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Exclusive Sessions for you</p>
        </div>

        <?php if (empty($course_ids)): ?>
            <div
                class="bg-white rounded-3xl p-12 text-center border-2 border-dashed border-gray-100 flex flex-col items-center">
                <div class="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-gray-300 mb-4 text-2xl">
                    <i class="fas fa-video-slash"></i>
                </div>
                <h3 class="font-bold text-gray-900 mb-2">No Courses Enrolled</h3>
                <p class="text-sm text-gray-400 mb-6">Enroll in a course to access exclusive live sessions and upcoming
                    streams.</p>
                <a href="/course.php"
                    class="bg-primary text-white px-8 py-3 rounded-2xl text-sm font-black uppercase tracking-widest shadow-lg shadow-primary/25">Browse
                    Courses</a>
            </div>
        <?php else:
            $ids_str = implode(',', $course_ids);

            // Get Live Sessions
            $live_sessions = $conn->query("SELECT ls.*, c.title as course_title, c.image as course_image 
                                         FROM live_sessions ls 
                                         JOIN courses c ON ls.course_id = c.id 
                                         WHERE ls.course_id IN ($ids_str) AND ls.status = 'live'
                                         ORDER BY ls.created_at DESC");

            // Get Upcoming Sessions
            $upcoming_sessions = $conn->query("SELECT ls.*, c.title as course_title, c.image as course_image 
                                             FROM live_sessions ls 
                                             JOIN courses c ON ls.course_id = c.id 
                                             WHERE ls.course_id IN ($ids_str) AND ls.status = 'upcoming'
                                             ORDER BY ls.scheduled_at ASC");
            ?>

            <!-- Live Now Section -->
            <section class="mb-10">
                <h2 class="text-[10px] font-black text-red-600 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <span class="w-2 h-2 bg-red-600 rounded-full animate-ping"></span> Live Now
                </h2>
                <div class="space-y-4">
                    <?php if ($live_sessions->num_rows === 0): ?>
                        <div class="bg-white/50 border border-dashed border-gray-200 rounded-3xl p-6 text-center">
                            <p class="text-xs text-gray-400 font-medium italic">No active streams at the moment.</p>
                        </div>
                    <?php else:
                        while ($ls = $live_sessions->fetch_assoc()): ?>
                            <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden group">
                                <div class="relative">
                                    <img src="/uploads/courses/<?php echo clean($ls['course_image']); ?>"
                                        class="w-full h-40 object-cover opacity-80 group-hover:opacity-100 transition-opacity">
                                    <div
                                        class="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest animate-pulse">
                                        Live
                                    </div>
                                    <div
                                        class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-5">
                                        <p class="text-[9px] font-bold text-white/80 uppercase tracking-widest mb-1">
                                            <?php echo clean($ls['course_title']); ?>
                                        </p>
                                        <h3 class="text-lg font-black text-white leading-tight">
                                            <?php echo clean($ls['title']); ?>
                                        </h3>
                                    </div>
                                </div>
                                <div class="p-5 flex items-center justify-between">
                                    <div class="flex flex-col">
                                        <span class="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Ongoing
                                            Stream</span>
                                        <span class="text-xs text-gray-600 font-bold">Join the discussion now</span>
                                    </div>
                                    <a href="/play.php?live_id=<?php echo $ls['id']; ?>"
                                        class="bg-primary text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all">Join
                                        Session</a>
                                </div>
                            </div>
                        <?php endwhile;
                    endif; ?>
                </div>
            </section>

            <!-- Upcoming Section -->
            <section>
                <h2 class="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                    <i class="fas fa-calendar-alt"></i> Upcoming Streams
                </h2>
                <div class="space-y-3">
                    <?php if ($upcoming_sessions->num_rows === 0): ?>
                        <div class="bg-white/50 border border-dashed border-gray-200 rounded-3xl p-6 text-center">
                            <p class="text-xs text-gray-400 font-medium italic">No upcoming sessions scheduled.</p>
                        </div>
                    <?php else:
                        while ($us = $upcoming_sessions->fetch_assoc()): ?>
                            <div
                                class="bg-white rounded-2xl p-4 border border-gray-100 flex items-center justify-between group hover:border-primary/50 transition-all">
                                <div class="flex items-center gap-4">
                                    <div
                                        class="w-12 h-12 rounded-2xl bg-gray-50 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                                        <i class="fas fa-clock"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-bold text-gray-900 text-sm">
                                            <?php echo clean($us['title']); ?>
                                        </h4>
                                        <div class="flex items-center gap-3">
                                            <p class="text-[10px] font-black text-primary uppercase tracking-widest">
                                                <?php echo clean($us['course_title']); ?>
                                            </p>
                                            <span class="w-1 h-1 bg-gray-300 rounded-full"></span>
                                            <p class="text-[10px] font-bold text-gray-400">
                                                <?php echo date('d M, h:i A', strtotime($us['scheduled_at'])); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <button class="text-gray-300 group-hover:text-primary transition-colors"><i
                                        class="fas fa-bell"></i></button>
                            </div>
                        <?php endwhile;
                    endif; ?>
                </div>
            </section>

        <?php endif; ?>
    </div>
</main>

<?php include 'common/bottom.php'; ?>