<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$page_title = 'My Courses';
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT c.id, c.title, c.image, o.id as order_id, o.created_at as purchase_date, o.invoice_number FROM orders o JOIN courses c ON o.course_id = c.id WHERE o.user_id = ? AND o.status = 'success' ORDER BY o.created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$courses = $stmt->get_result();
$stmt->close();

include 'common/header.php';
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">My Courses</h2>

    <?php if ($courses->num_rows > 0): ?>
        <div class="space-y-3">
            <?php while ($c = $courses->fetch_assoc()): ?>
                <div class="bg-white shadow-sm flex overflow-hidden">
                    <img src="/uploads/courses/<?php echo clean($c['image']); ?>" alt="<?php echo clean($c['title']); ?>"
                        class="w-28 h-20 object-cover flex-shrink-0" loading="lazy">
                    <div class="flex-1 p-3 flex flex-col justify-between">
                        <h3 class="text-sm font-semibold text-gray-900 line-clamp-2"><?php echo clean($c['title']); ?></h3>
                        <div class="flex items-center justify-between mt-2">
                            <a href="/watch.php?course_id=<?php echo $c['id']; ?>"
                                class="bg-primary text-white text-xs px-4 py-1.5 font-medium">
                                <i class="fas fa-play mr-1"></i>Start
                            </a>
                            <?php if ($c['invoice_number']): ?>
                                <a href="/invoice.php?order_id=<?php echo $c['order_id']; ?>" class="text-gray-400 text-xs"
                                    title="Download Invoice">
                                    <i class="fas fa-download"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-16">
            <i class="fas fa-graduation-cap text-5xl text-gray-300 mb-4"></i>
            <p class="text-gray-500 mb-4">You haven't purchased any courses yet.</p>
            <a href="/course.php" class="inline-block bg-primary text-white px-6 py-3 font-semibold">Browse Courses</a>
        </div>
    <?php endif; ?>
</main>

<?php include 'common/bottom.php'; ?>