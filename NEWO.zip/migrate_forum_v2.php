<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting migration...\n";

// Add forum_blocked to users table if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'forum_blocked'");
if ($check_column->num_rows == 0) {
    if ($conn->query("ALTER TABLE users ADD COLUMN forum_blocked TINYINT(1) DEFAULT 0 AFTER status")) {
        echo "Column 'forum_blocked' added to 'users' table.\n";
    } else {
        echo "Error adding 'forum_blocked' column: " . $conn->error . "\n";
    }
} else {
    echo "Column 'forum_blocked' already exists in 'users' table.\n";
}

echo "Migration finished.\n";
?>