<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

$sql = "ALTER TABLE tickets MODIFY COLUMN status ENUM('open', 'pending', 'closed') DEFAULT 'open'";

if ($conn->query($sql)) {
    echo "Table 'tickets' updated successfully to include 'pending' status.";
} else {
    echo "Error updating table: " . $conn->error;
}
?>