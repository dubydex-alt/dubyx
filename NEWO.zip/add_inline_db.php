<?php
/**
 * add_inline_db.php
 * Run once — adds inline $conn to every PHP file that uses common/config.php
 */

$inline = '$conn = new mysqli(\'sql301.infinityfree.com\', \'if0_41158662\', \'D2UQHHFoBdbafCp\', \'if0_41158662_backendxtra9\');' . "\n";

$patterns = [
    "require_once 'common/config.php';",
    "require_once __DIR__ . '/../common/config.php';",
    "require_once '../common/config.php';",
];

$dirs = [
    __DIR__ . '/',
    __DIR__ . '/admin/',
    __DIR__ . '/teacher/',
    __DIR__ . '/api/',
];

$updated = [];
$skipped = [];

foreach ($dirs as $dir) {
    foreach (glob($dir . '*.php') as $file) {
        if (basename($file) === basename(__FILE__))
            continue; // skip self

        $content = file_get_contents($file);
        $changed = false;

        foreach ($patterns as $pattern) {
            if (strpos($content, $pattern) !== false) {
                // Only add if $conn inline not already there right before it
                $replacement = $inline . $pattern;
                // Avoid double-adding
                if (strpos($content, $inline . $pattern) === false) {
                    $content = str_replace($pattern, $replacement, $content);
                    $changed = true;
                }
                break;
            }
        }

        if ($changed) {
            file_put_contents($file, $content);
            $updated[] = str_replace(__DIR__ . '/', '', $file);
        } else {
            $skipped[] = str_replace(__DIR__ . '/', '', $file);
        }
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Inline DB Updater</title>
    <style>
        body {
            font-family: monospace;
            background: #0f172a;
            color: #e2e8f0;
            padding: 30px;
        }

        h2 {
            color: #38bdf8;
        }

        h3 {
            color: #94a3b8;
            margin-top: 20px;
        }

        .ok {
            color: #34d399;
        }

        .skip {
            color: #6b7280;
        }
    </style>
</head>

<body>
    <h2>Inline DB Credential Injector</h2>
    <h3>✅ Updated (
        <?= count($updated) ?> files)
    </h3>
    <?php foreach ($updated as $f): ?>
        <div class="ok">✔
            <?= htmlspecialchars($f) ?>
        </div>
    <?php endforeach; ?>
    <h3>⏭ Already OK / Skipped (
        <?= count($skipped) ?> files)
    </h3>
    <?php foreach ($skipped as $f): ?>
        <div class="skip">–
            <?= htmlspecialchars($f) ?>
        </div>
    <?php endforeach; ?>
    <p style="margin-top:20px;color:#fcd34d;">⚠️ Done! You can now delete this file from the server.</p>
</body>

</html>