<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Dashboard';
require_once __DIR__ . '/../common/config.php';
include 'common/header.php';

// Stats
$total_users = $conn->query("SELECT COUNT(*) as c FROM users WHERE deleted_at IS NULL")->fetch_assoc()['c'];
$total_teachers = $conn->query("SELECT COUNT(*) as c FROM teachers")->fetch_assoc()['c'];
$total_revenue = $conn->query("SELECT COALESCE(SUM(amount), 0) as c FROM orders WHERE status = 'success'")->fetch_assoc()['c'];
$active_courses = $conn->query("SELECT COUNT(*) as c FROM courses WHERE status = 'active' AND deleted_at IS NULL")->fetch_assoc()['c'];
$total_purchases = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status = 'success'")->fetch_assoc()['c'];

// Recent 5 purchases
$recent = $conn->query("SELECT o.*, u.name as user_name, c.title as course_title FROM orders o JOIN users u ON o.user_id = u.id JOIN courses c ON o.course_id = c.id WHERE o.status = 'success' ORDER BY o.created_at DESC LIMIT 5");

// Top 5 selling courses
$top_courses = $conn->query("SELECT c.title, COUNT(o.id) as sales, SUM(o.amount) as revenue FROM courses c JOIN orders o ON c.id = o.course_id WHERE o.status = 'success' GROUP BY c.id ORDER BY sales DESC LIMIT 5");

// Monthly revenue (last 6 months)
$monthly = $conn->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as revenue FROM orders WHERE status = 'success' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY month ORDER BY month");
$chart_labels = [];
$chart_data = [];
while ($m = $monthly->fetch_assoc()) {
    $chart_labels[] = date('M Y', strtotime($m['month'] . '-01'));
    $chart_data[] = (float) $m['revenue'];
}
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">Dashboard</h2>

    <!-- Stats Grid -->
    <div class="grid grid-cols-2 gap-3 mb-6">
        <div class="bg-white p-4 shadow-sm">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($total_users); ?></p>
                    <p class="text-xs text-gray-500">Total Users</p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 shadow-sm">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-orange-100 text-orange-600 flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($total_teachers); ?></p>
                    <p class="text-xs text-gray-500">Teachers</p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 shadow-sm">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-green-100 text-green-600 flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-rupee-sign"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($total_revenue); ?></p>
                    <p class="text-xs text-gray-500">Revenue</p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 shadow-sm">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-book"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($active_courses); ?></p>
                    <p class="text-xs text-gray-500">Courses</p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 shadow-sm">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-orange-100 text-orange-600 flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($total_purchases); ?></p>
                    <p class="text-xs text-gray-500">Purchases</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="flex gap-3 mb-6">
        <a href="/admin/course.php" class="flex-1 bg-primary text-white text-center py-3 font-semibold text-sm">
            <i class="fas fa-plus mr-1"></i>Add Course
        </a>
        <a href="/admin/banner.php" class="flex-1 bg-gray-800 text-white text-center py-3 font-semibold text-sm">
            <i class="fas fa-plus mr-1"></i>Add Banner
        </a>
    </div>

    <!-- Revenue Chart -->
    <?php if (!empty($chart_data)): ?>
        <div class="bg-white p-4 shadow-sm mb-6">
            <h3 class="font-bold text-gray-900 mb-3">Monthly Revenue</h3>
            <canvas id="revenueChart" width="400" height="200"></canvas>
        </div>
        <script>
            (function () {
                const canvas = document.getElementById('revenueChart');
                const ctx = canvas.getContext('2d');
                const labels = <?php echo json_encode($chart_labels); ?>;
                const data = <?php echo json_encode($chart_data); ?>;
                const maxVal = Math.max(...data, 1);
                const w = canvas.width = canvas.offsetWidth * 2;
                const h = canvas.height = 300;
                ctx.scale(1, 1);

                const padding = { top: 20, right: 20, bottom: 60, left: 60 };
                const chartW = w - padding.left - padding.right;
                const chartH = h - padding.top - padding.bottom;
                const barWidth = chartW / data.length * 0.6;
                const gap = chartW / data.length;

                // Grid lines
                ctx.strokeStyle = '#E5E7EB';
                ctx.lineWidth = 1;
                for (let i = 0; i <= 4; i++) {
                    const y = padding.top + (chartH / 4) * i;
                    ctx.beginPath();
                    ctx.moveTo(padding.left, y);
                    ctx.lineTo(w - padding.right, y);
                    ctx.stroke();
                    ctx.fillStyle = '#9CA3AF';
                    ctx.font = '18px sans-serif';
                    ctx.textAlign = 'right';
                    ctx.fillText('₹' + Math.round(maxVal - (maxVal / 4) * i).toLocaleString(), padding.left - 8, y + 5);
                }

                // Bars
                data.forEach((val, i) => {
                    const barH = (val / maxVal) * chartH;
                    const x = padding.left + i * gap + (gap - barWidth) / 2;
                    const y = padding.top + chartH - barH;

                    ctx.fillStyle = '#0284C7';
                    ctx.fillRect(x, y, barWidth, barH);

                    // Label
                    ctx.fillStyle = '#6B7280';
                    ctx.font = '16px sans-serif';
                    ctx.textAlign = 'center';
                    ctx.save();
                    ctx.translate(x + barWidth / 2, h - padding.bottom + 20);
                    ctx.rotate(-0.4);
                    ctx.fillText(labels[i], 0, 0);
                    ctx.restore();
                });
            })();
        </script>
    <?php endif; ?>

    <!-- Recent Purchases -->
    <?php if ($recent && $recent->num_rows > 0): ?>
        <div class="bg-white shadow-sm mb-6">
            <div class="p-4 border-b">
                <h3 class="font-bold text-gray-900">Recent Purchases</h3>
            </div>
            <div class="divide-y">
                <?php while ($r = $recent->fetch_assoc()): ?>
                    <div class="p-4 flex items-center justify-between">
                        <div>
                            <p class="font-medium text-gray-900 text-sm"><?php echo clean($r['user_name']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo clean($r['course_title']); ?></p>
                        </div>
                        <div class="text-right">
                            <p class="font-bold text-primary text-sm">&#8377;<?php echo number_format($r['amount']); ?></p>
                            <p class="text-xs text-gray-400"><?php echo date('d M', strtotime($r['created_at'])); ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Top Courses -->
    <?php if ($top_courses && $top_courses->num_rows > 0): ?>
        <div class="bg-white shadow-sm">
            <div class="p-4 border-b">
                <h3 class="font-bold text-gray-900">Top Selling Courses</h3>
            </div>
            <div class="divide-y">
                <?php $rank = 1;
                while ($tc = $top_courses->fetch_assoc()): ?>
                    <div class="p-4 flex items-center gap-3">
                        <span
                            class="w-8 h-8 bg-gray-100 text-gray-600 flex items-center justify-center font-bold text-sm flex-shrink-0"><?php echo $rank++; ?></span>
                        <div class="flex-1">
                            <p class="font-medium text-gray-900 text-sm"><?php echo clean($tc['title']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo $tc['sales']; ?> sales &bull;
                                &#8377;<?php echo number_format($tc['revenue']); ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php include 'common/bottom.php'; ?>