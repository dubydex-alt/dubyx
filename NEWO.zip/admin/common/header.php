<?php
if (!isset($conn)) require_once __DIR__ . '/../../common/config.php';
if (!isset($_SESSION['admin_id']) && basename($_SERVER['PHP_SELF']) !== 'login.php') {
    header('Location: /admin/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0284C7">
    <title><?php echo isset($page_title) ? $page_title . ' - Admin' : 'Admin Panel'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { primary: '#0284C7', 'primary-dark': '#0369A1' } } } }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { -webkit-tap-highlight-color: transparent; }
        ::-webkit-scrollbar { display: none; }
        body { scrollbar-width: none; }
    </style>
</head>
<body class="bg-gray-100 text-gray-900 min-h-screen">

<!-- Admin Header -->
<header class="fixed top-0 left-0 right-0 z-50 bg-gray-900 text-white">
    <div class="flex items-center justify-between px-4 h-14">
        <button onclick="toggleAdminSidebar()" class="w-10 h-10 flex items-center justify-center">
            <i class="fas fa-bars text-lg"></i>
        </button>
        <h1 class="text-lg font-bold">Admin Panel</h1>
        <a href="/admin/login.php?logout=1" class="w-10 h-10 flex items-center justify-center" title="Logout">
            <i class="fas fa-sign-out-alt text-lg"></i>
        </a>
    </div>
</header>
<div class="h-14"></div>

<!-- Sidebar Overlay -->
<div id="admin-overlay" class="fixed inset-0 bg-black/50 z-50 hidden" onclick="toggleAdminSidebar()"></div>

<!-- Admin Sidebar -->
<?php include __DIR__ . '/sidebar.php'; ?>

<script>
function toggleAdminSidebar() {
    document.getElementById('admin-sidebar').classList.toggle('-translate-x-full');
    document.getElementById('admin-overlay').classList.toggle('hidden');
}
</script>
