<nav id="admin-sidebar"
    class="fixed top-0 left-0 h-full w-64 bg-gray-900 z-50 transform -translate-x-full transition-transform duration-300">
    <div class="p-4 border-b border-gray-700">
        <h2 class="text-white font-bold text-lg"><?php echo clean($settings['app_name']); ?></h2>
        <p class="text-gray-400 text-xs">Admin Dashboard</p>
    </div>
    <div class="py-2">
        <?php
        $current = basename($_SERVER['PHP_SELF']);
        $links = [
            ['index.php', 'fas fa-chart-line', 'Dashboard'],
            ['banner.php', 'fas fa-images', 'Banners'],
            ['course.php', 'fas fa-book', 'Courses'],
            ['users.php', 'fas fa-users', 'Users'],
            ['teachers.php', 'fas fa-chalkboard-teacher', 'Teachers'],
            ['orders.php', 'fas fa-shopping-cart', 'Orders'],
            ['payments.php', 'fas fa-credit-card', 'Payments'],
            ['tickets.php', 'fas fa-ticket-alt', 'Tickets'],
            ['settings.php', 'fas fa-cog', 'Settings'],
        ];
        foreach ($links as $l):
            $active = $current === $l[0] ? 'bg-primary text-white' : 'text-gray-300 hover:bg-gray-800';
            ?>
            <a href="/admin/<?php echo $l[0]; ?>" class="flex items-center gap-3 px-4 py-3 text-sm <?php echo $active; ?>">
                <i class="<?php echo $l[1]; ?> w-5 text-center"></i>
                <span><?php echo $l[2]; ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</nav>