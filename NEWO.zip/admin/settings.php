<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Settings';
require_once __DIR__ . '/../common/config.php';
include 'common/header.php';

$msg = '';
$msg_type = '';

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $msg = 'Invalid request';
        $msg_type = 'error';
    } else {
        $action = $_POST['action'];

        if ($action === 'update_settings') {
            $app_name = clean($_POST['app_name']);
            $razorpay_key = clean($_POST['razorpay_key']);
            $razorpay_secret = clean($_POST['razorpay_secret']);
            $support_email = clean($_POST['support_email']);
            $support_phone = clean($_POST['support_phone']);
            $onesignal_app_id = clean($_POST['onesignal_app_id']);
            $onesignal_rest_key = clean($_POST['onesignal_rest_key']);
            $community_name = clean($_POST['community_name']);
            $community_welcome = clean($_POST['community_welcome']);

            $stmt = $conn->prepare("UPDATE settings SET app_name=?, razorpay_key=?, razorpay_secret=?, support_email=?, support_phone=?, onesignal_app_id=?, onesignal_rest_key=?, community_name=?, community_welcome=? WHERE id=1");
            $stmt->bind_param("sssssssss", $app_name, $razorpay_key, $razorpay_secret, $support_email, $support_phone, $onesignal_app_id, $onesignal_rest_key, $community_name, $community_welcome);
            if ($stmt->execute()) {
                $settings = get_settings($conn);
                $msg = 'Settings updated successfully';
                $msg_type = 'success';
                log_activity($conn, $_SESSION['admin_id'] ?? 0, 'Updated app settings');
            } else {
                $msg = 'Failed to update settings';
                $msg_type = 'error';
            }
            $stmt->close();
        }

        if ($action === 'change_password') {
            $current = $_POST['current_password'];
            $new_pass = $_POST['new_password'];
            $confirm = $_POST['confirm_password'];

            if ($new_pass !== $confirm) {
                $msg = 'Passwords do not match';
                $msg_type = 'error';
            } elseif (strlen($new_pass) < 6) {
                $msg = 'Password must be at least 6 characters';
                $msg_type = 'error';
            } else {
                $admin_id = $_SESSION['admin_id'];
                $admin = $conn->query("SELECT password FROM admin WHERE id = $admin_id")->fetch_assoc();
                if ($admin && password_verify($current, $admin['password'])) {
                    $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE admin SET password=? WHERE id=?");
                    $stmt->bind_param("si", $hashed, $admin_id);
                    $stmt->execute();
                    $stmt->close();
                    $msg = 'Password changed successfully';
                    $msg_type = 'success';
                    log_activity($conn, $admin_id, 'Changed admin password');
                } else {
                    $msg = 'Current password is incorrect';
                    $msg_type = 'error';
                }
            }
        }

        // Manage Categories
        if ($action === 'add_category') {
            $name = clean($_POST['category_name']);
            if ($name) {
                $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
                $stmt->bind_param("s", $name);
                $stmt->execute();
                $stmt->close();
                $msg = 'Category added';
                $msg_type = 'success';
            }
        }

        if ($action === 'delete_category') {
            $cat_id = (int) $_POST['category_id'];
            $conn->query("UPDATE courses SET category_id = NULL WHERE category_id = $cat_id");
            $conn->query("DELETE FROM categories WHERE id = $cat_id");
            $msg = 'Category deleted';
            $msg_type = 'success';
        }

        // Manage Coupons
        if ($action === 'add_coupon') {
            $code = strtoupper(clean($_POST['coupon_code']));
            $discount = (int) $_POST['discount_percent'];
            $expiry = clean($_POST['expiry_date']);
            if ($code && $discount > 0 && $discount <= 100 && $expiry) {
                $stmt = $conn->prepare("INSERT INTO coupons (code, discount_percent, expiry_date) VALUES (?, ?, ?)");
                $stmt->bind_param("sis", $code, $discount, $expiry);
                if ($stmt->execute()) {
                    $msg = 'Coupon created';
                    $msg_type = 'success';
                } else {
                    $msg = 'Coupon code already exists';
                    $msg_type = 'error';
                }
                $stmt->close();
            }
        }

        if ($action === 'delete_coupon') {
            $coupon_id = (int) $_POST['coupon_id'];
            $conn->query("DELETE FROM coupons WHERE id = $coupon_id");
            $msg = 'Coupon deleted';
            $msg_type = 'success';
        }

        // Send Notification
        if ($action === 'send_notification') {
            $title = clean($_POST['notif_title']);
            $message = clean($_POST['notif_message']);
            $target = clean($_POST['notif_target']);

            if ($title && $message) {
                if ($target === 'all') {
                    $users = $conn->query("SELECT id FROM users WHERE deleted_at IS NULL AND status = 'active'");
                    while ($u = $users->fetch_assoc()) {
                        send_notification($conn, $u['id'], $title, $message);
                    }
                    $msg = 'Notification sent to all users (Push + In-App)';
                } else {
                    $uid = (int) $target;
                    send_notification($conn, $uid, $title, $message);
                    $msg = 'Notification sent (Push + In-App)';
                }
                $msg_type = 'success';
            }
        }
    }
}

$categories = $conn->query("SELECT * FROM categories ORDER BY name");
$coupons = $conn->query("SELECT * FROM coupons ORDER BY id DESC");
$all_users = $conn->query("SELECT id, name, email FROM users WHERE deleted_at IS NULL ORDER BY name");
$settings = get_settings($conn); // Re-fetch to ensure it's available for the form
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">Settings</h2>

    <?php if ($msg): ?>
        <div
            class="p-3 mb-4 text-sm <?php echo $msg_type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'; ?>">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <!-- App Settings -->
    <div class="bg-white shadow-sm mb-4">
        <div class="p-4 border-b">
            <h3 class="font-bold text-gray-900"><i class="fas fa-cog mr-2 text-sky-600"></i>App Settings</h3>
        </div>
        <form method="POST" class="p-4 space-y-4">
            <input type="hidden" name="action" value="update_settings">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">App Name</label>
                <input type="text" name="app_name" value="<?php echo clean($settings['app_name']); ?>"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Razorpay Key ID</label>
                <input type="text" name="razorpay_key" value="<?php echo clean($settings['razorpay_key']); ?>"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Razorpay Secret</label>
                <input type="password" name="razorpay_secret" value="<?php echo clean($settings['razorpay_secret']); ?>"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
                <input type="email" name="support_email" value="<?php echo clean($settings['support_email']); ?>"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Support Phone</label>
                <input type="text" name="support_phone" value="<?php echo clean($settings['support_phone']); ?>"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">OneSignal App ID</label>
                    <input type="text" name="onesignal_app_id"
                        value="<?php echo clean($settings['onesignal_app_id'] ?? ''); ?>"
                        class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">OneSignal REST API Key</label>
                    <input type="password" name="onesignal_rest_key"
                        value="<?php echo clean($settings['onesignal_rest_key'] ?? ''); ?>"
                        class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
                </div>
            </div>

            <!-- Global Community Settings -->
            <div class="pt-4 border-t">
                <h4 class="text-sm font-black text-indigo-600 uppercase tracking-widest mb-4">Community Configuration
                </h4>
                <div class="grid grid-cols-1 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Community Hub Name</label>
                        <input type="text" name="community_name"
                            value="<?php echo clean($settings['community_name'] ?? 'Community Chat'); ?>"
                            class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-indigo-600"
                            required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Community Welcome Message</label>
                        <textarea name="community_welcome" rows="2"
                            class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-indigo-600"><?php echo clean($settings['community_welcome'] ?? 'Join a group and chat with fellow students in real-time.'); ?></textarea>
                    </div>
                </div>
            </div>
            <button type="submit" class="w-full bg-sky-600 text-white py-2.5 font-semibold text-sm">Save
                Settings</button>
        </form>
    </div>

    <!-- Change Admin Password -->
    <div class="bg-white shadow-sm mb-4">
        <div class="p-4 border-b">
            <h3 class="font-bold text-gray-900"><i class="fas fa-lock mr-2 text-sky-600"></i>Change Password</h3>
        </div>
        <form method="POST" class="p-4 space-y-4">
            <input type="hidden" name="action" value="change_password">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                <input type="password" name="current_password"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                <input type="password" name="new_password"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required minlength="6">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                <input type="password" name="confirm_password"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required>
            </div>
            <button type="submit" class="w-full bg-gray-800 text-white py-2.5 font-semibold text-sm">Change
                Password</button>
        </form>
    </div>

    <!-- Categories -->
    <div class="bg-white shadow-sm mb-4">
        <div class="p-4 border-b">
            <h3 class="font-bold text-gray-900"><i class="fas fa-tags mr-2 text-sky-600"></i>Categories</h3>
        </div>
        <form method="POST" class="p-4 flex gap-2">
            <input type="hidden" name="action" value="add_category">
            <?php echo csrf_field(); ?>
            <input type="text" name="category_name" placeholder="Category name"
                class="flex-1 border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                required>
            <button type="submit" class="bg-sky-600 text-white px-4 py-2 text-sm font-medium">Add</button>
        </form>
        <div class="divide-y">
            <?php while ($cat = $categories->fetch_assoc()): ?>
                <div class="px-4 py-3 flex items-center justify-between">
                    <span class="text-sm text-gray-700"><?php echo clean($cat['name']); ?></span>
                    <form method="POST" onsubmit="return confirm('Delete this category?')">
                        <input type="hidden" name="action" value="delete_category">
                        <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-red-500 text-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Coupons -->
    <div class="bg-white shadow-sm mb-4">
        <div class="p-4 border-b">
            <h3 class="font-bold text-gray-900"><i class="fas fa-ticket-alt mr-2 text-sky-600"></i>Coupons</h3>
        </div>
        <form method="POST" class="p-4 space-y-3">
            <input type="hidden" name="action" value="add_coupon">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-3">
                <input type="text" name="coupon_code" placeholder="Code (e.g. SAVE20)"
                    class="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600 uppercase"
                    required>
                <input type="number" name="discount_percent" placeholder="Discount %" min="1" max="100"
                    class="border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600" required>
            </div>
            <div class="flex gap-3">
                <input type="date" name="expiry_date"
                    class="flex-1 border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required>
                <button type="submit" class="bg-sky-600 text-white px-4 py-2 text-sm font-medium">Create</button>
            </div>
        </form>
        <div class="divide-y">
            <?php while ($cp = $coupons->fetch_assoc()):
                $expired = strtotime($cp['expiry_date']) < time();
                ?>
                <div class="px-4 py-3 flex items-center justify-between">
                    <div>
                        <span
                            class="font-mono font-bold text-sm <?php echo $expired ? 'text-gray-400 line-through' : 'text-gray-900'; ?>"><?php echo clean($cp['code']); ?></span>
                        <span class="text-xs text-gray-500 ml-2"><?php echo $cp['discount_percent']; ?>% off</span>
                        <p class="text-xs text-gray-400">Expires:
                            <?php echo date('d M Y', strtotime($cp['expiry_date'])); ?>
                        </p>
                    </div>
                    <form method="POST" onsubmit="return confirm('Delete this coupon?')">
                        <input type="hidden" name="action" value="delete_coupon">
                        <input type="hidden" name="coupon_id" value="<?php echo $cp['id']; ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="text-red-500 text-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <!-- Send Notification -->
    <div class="bg-white shadow-sm mb-4">
        <div class="p-4 border-b">
            <h3 class="font-bold text-gray-900"><i class="fas fa-bell mr-2 text-sky-600"></i>Send Notification</h3>
        </div>
        <form method="POST" class="p-4 space-y-3">
            <input type="hidden" name="action" value="send_notification">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Target</label>
                <select name="notif_target"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600">
                    <option value="all">All Users</option>
                    <?php
                    $all_users->data_seek(0);
                    while ($u = $all_users->fetch_assoc()): ?>
                        <option value="<?php echo $u['id']; ?>"><?php echo clean($u['name']); ?>
                            (<?php echo clean($u['email']); ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input type="text" name="notif_title"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea name="notif_message" rows="3"
                    class="w-full border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                    required></textarea>
            </div>
            <button type="submit" class="w-full bg-sky-600 text-white py-2.5 font-semibold text-sm">Send
                Notification</button>
        </form>
    </div>
</main>

<?php include 'common/bottom.php'; ?>