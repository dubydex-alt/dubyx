<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Course Content';
require_once __DIR__ . '/../common/config.php';

$course_id = (int) ($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    header('Location: /admin/course.php');
    exit;
}

$course = $conn->query("SELECT title FROM courses WHERE id = $course_id")->fetch_assoc();
if (!$course) {
    header('Location: /admin/course.php');
    exit;
}

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    // Chapter (Folder) Actions
    if ($action === 'add' || $action === 'edit') {
        $id = (int) ($_POST['id'] ?? 0);
        $parent_id = (int) ($_POST['parent_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $sort_order = (int) ($_POST['sort_order'] ?? 0);

        if (empty($title)) {
            echo json_encode(['success' => false, 'message' => 'Title is required.']);
            exit;
        }

        if ($action === 'add') {
            $stmt = $conn->prepare("INSERT INTO chapters (course_id, parent_id, title, sort_order) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iisi", $course_id, $parent_id, $title, $sort_order);
        } else {
            $stmt = $conn->prepare("UPDATE chapters SET title = ?, sort_order = ? WHERE id = ? AND course_id = ?");
            $stmt->bind_param("siii", $title, $sort_order, $id, $course_id);
        }
        $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => true, 'message' => 'Folder saved!']);
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);

        // Recursive deletion helper
        function deleteChapterRecursive($conn, $ch_id)
        {
            // Delete videos in this chapter
            $conn->query("DELETE FROM videos WHERE chapter_id = $ch_id");

            // Find sub-chapters
            $subs = $conn->query("SELECT id FROM chapters WHERE parent_id = $ch_id");
            while ($sub = $subs->fetch_assoc()) {
                deleteChapterRecursive($conn, $sub['id']);
            }

            // Delete the chapter itself
            $conn->query("DELETE FROM chapters WHERE id = $ch_id");
        }

        deleteChapterRecursive($conn, $id);
        echo json_encode(['success' => true, 'message' => 'Folder and all contents deleted.']);
        exit;
    }

    // Item (Video/Link) Actions
    if ($action === 'add_link' || $action === 'edit_link') {
        $id = (int) ($_POST['id'] ?? 0);
        $chapter_id = (int) ($_POST['chapter_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $type = $_POST['type'] ?? 'youtube';
        $sort_order = (int) ($_POST['sort_order'] ?? 0);
        $is_test = (int) ($_POST['is_test'] ?? 0);
        $start_time = !empty($_POST['start_time']) ? $_POST['start_time'] : null;
        $end_time = !empty($_POST['end_time']) ? $_POST['end_time'] : null;

        if (empty($title) || empty($url)) {
            echo json_encode(['success' => false, 'message' => 'Title and URL are required.']);
            exit;
        }

        if ($action === 'add_link') {
            $stmt = $conn->prepare("INSERT INTO videos (chapter_id, title, type, url, sort_order, is_test, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isssiiss", $chapter_id, $title, $type, $url, $sort_order, $is_test, $start_time, $end_time);
        } else {
            $stmt = $conn->prepare("UPDATE videos SET title = ?, type = ?, url = ?, sort_order = ?, is_test = ?, start_time = ?, end_time = ? WHERE id = ?");
            $stmt->bind_param("sssiiiss", $title, $type, $url, $sort_order, $is_test, $start_time, $end_time, $id);
        }
        $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => true, 'message' => 'Link saved!']);
        exit;
    }

    if ($action === 'delete_link') {
        $id = (int) ($_POST['id'] ?? 0);
        $conn->query("DELETE FROM videos WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Item deleted.']);
        exit;
    }
}

// Function to render folder tree recursively
function renderFolderTree($conn, $course_id, $parent_id = 0, $depth = 0)
{
    $chapters = $conn->query("SELECT * FROM chapters WHERE course_id = $course_id AND parent_id = $parent_id ORDER BY sort_order, id");

    while ($ch = $chapters->fetch_assoc()) {
        $item_count = $conn->query("SELECT COUNT(*) as cnt FROM videos WHERE chapter_id = {$ch['id']}")->fetch_assoc()['cnt'];
        $sub_folder_count = $conn->query("SELECT COUNT(*) as cnt FROM chapters WHERE parent_id = {$ch['id']}")->fetch_assoc()['cnt'];
        ?>
        <div class="bg-white shadow-sm border rounded-lg overflow-hidden mb-2 ml-<?php echo $depth * 4; ?>"
            id="chapter-<?php echo $ch['id']; ?>">
            <!-- Folder Header -->
            <div class="px-4 py-3 bg-white flex items-center justify-between group">
                <div class="flex items-center gap-3 cursor-pointer flex-1" onclick="toggleFolder(<?php echo $ch['id']; ?>)">
                    <i class="fas fa-folder text-yellow-500 text-xl" id="icon-<?php echo $ch['id']; ?>"></i>
                    <div>
                        <h3 class="font-bold text-gray-900 text-sm"><?php echo clean($ch['title']); ?></h3>
                        <p class="text-[10px] text-gray-400 font-bold"><?php echo $item_count; ?> Videos |
                            <?php echo $sub_folder_count; ?> Folders
                        </p>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <button onclick="openLinkModal(<?php echo $ch['id']; ?>)"
                        class="text-[10px] bg-blue-50 text-blue-600 px-2 py-1 font-bold rounded hover:bg-blue-100 uppercase">+
                        Item</button>
                    <button onclick="openChapterModal(0, <?php echo $ch['id']; ?>)"
                        class="text-[10px] bg-yellow-50 text-yellow-600 px-2 py-1 font-bold rounded hover:bg-yellow-100 uppercase">+
                        Folder</button>
                    <div class="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity ml-2">
                        <button onclick='openChapterModal(<?php echo json_encode($ch); ?>)'
                            class="text-gray-400 hover:text-gray-600 text-sm"><i class="fas fa-edit"></i></button>
                        <button onclick="deleteChapter(<?php echo $ch['id']; ?>)"
                            class="text-red-300 hover:text-red-500 text-sm"><i class="fas fa-trash-alt"></i></button>
                    </div>
                    <i class="fas fa-chevron-down text-gray-300 text-xs transition-transform cursor-pointer"
                        id="arrow-<?php echo $ch['id']; ?>" onclick="toggleFolder(<?php echo $ch['id']; ?>, event)"></i>
                </div>
            </div>

            <!-- Items and Subfolders List -->
            <div id="items-<?php echo $ch['id']; ?>" class="hidden border-t bg-gray-50/30">
                <!-- Recursively render subfolders -->
                <div class="p-2 empty:hidden">
                    <?php renderFolderTree($conn, $course_id, $ch['id'], $depth + 0); // Nesting within the container ?>
                </div>

                <!-- Render files/videos in this folder -->
                <div class="divide-y divide-gray-100 border-t bg-gray-50/50">
                    <?php
                    $items = $conn->query("SELECT * FROM videos WHERE chapter_id = {$ch['id']} ORDER BY sort_order, id");
                    if ($items->num_rows === 0 && $sub_folder_count === 0): ?>
                        <div class="p-4 text-center text-gray-400 text-xs italic">Folder is empty</div>
                    <?php endif; ?>

                    <?php while ($v = $items->fetch_assoc()): ?>
                        <div class="px-4 py-3 pl-8 flex items-center justify-between hover:bg-white group"
                            id="video-<?php echo $v['id']; ?>">
                            <div class="flex items-center gap-3">
                                <?php if ($v['type'] === 'youtube'): ?>
                                    <i class="fas fa-video text-primary text-lg"></i>
                                <?php else: ?>
                                    <i class="fas fa-file-alt text-gray-500 text-lg"></i>
                                <?php endif; ?>
                                <div>
                                    <h4 class="text-sm text-gray-700 font-medium">
                                        <?php echo clean($v['title']); ?>
                                        <?php if ($v['is_test']): ?>
                                            <span
                                                class="ml-2 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter bg-red-100 text-red-600 border border-red-200">EXAM
                                                MODE</span>
                                        <?php endif; ?>
                                    </h4>
                                    <p class="text-[10px] text-gray-400 truncate max-w-[200px]">
                                        <?php echo $v['is_test'] && $v['start_time'] ? date('d M, h:i A', strtotime($v['start_time'])) . ' - ' . date('h:i A', strtotime($v['end_time'])) : clean($v['url']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onclick='openLinkModal(<?php echo $ch['id']; ?>, <?php echo json_encode($v); ?>)'
                                    class="text-gray-400 hover:text-gray-600 text-xs"><i class="fas fa-pencil-alt"></i>
                                    Edit</button>
                                <button onclick="deleteLink(<?php echo $v['id']; ?>)"
                                    class="text-red-300 hover:text-red-500 text-xs"><i class="fas fa-times"></i></button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

include 'common/header.php';
?>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="mb-4">
        <a href="/admin/course.php" class="text-primary text-sm font-medium"><i class="fas fa-arrow-left mr-1"></i>Back
            to Courses</a>
    </div>

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
            <h1 class="text-xl font-bold text-gray-900"><?php echo clean($course['title']); ?></h1>
            <p class="text-xs text-gray-500 tracking-wider font-bold uppercase">Multi-Level Content Manager</p>
        </div>
        <div class="flex gap-2">
            <button onclick="openChapterModal(0, 0)"
                class="flex-1 md:flex-none bg-primary text-white px-5 py-2.5 text-sm font-bold flex items-center justify-center gap-2 rounded shadow-sm">
                <i class="fas fa-folder-plus"></i> New Top Folder
            </button>
        </div>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <!-- File Manager Tree -->
    <div class="space-y-4">
        <?php
        $top_count = $conn->query("SELECT COUNT(*) as cnt FROM chapters WHERE course_id = $course_id AND parent_id = 0")->fetch_assoc()['cnt'];
        if ($top_count == 0): ?>
            <div class="bg-white border-2 border-dashed rounded-xl p-16 text-center text-gray-400">
                <i class="fas fa-folder-tree text-5xl mb-4 opacity-20"></i>
                <p class="font-bold">No folders here yet.</p>
                <p class="text-sm mt-1">Start by creating a root folder to organize your lessons.</p>
            </div>
        <?php else:
            renderFolderTree($conn, $course_id, 0);
        endif; ?>
    </div>
</main>

<!-- Chapter (Folder) Modal -->
<div id="ch-modal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-xl p-6 shadow-2xl">
        <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900 text-lg" id="ch-modal-title">New Folder</h3>
            <button onclick="document.getElementById('ch-modal').classList.add('hidden')"
                class="text-gray-400 hover:text-gray-600 transition-colors"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form id="ch-form" class="space-y-5">
            <input type="hidden" id="ch-id" value="0">
            <input type="hidden" id="ch-parent-id" value="0">
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Folder
                    Name</label>
                <input type="text" id="ch-title" required
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all"
                    placeholder="e.g. Theoretical Concepts">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Display
                    Order</label>
                <input type="number" id="ch-order" value="0"
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
            </div>
            <button type="submit" id="btn-ch"
                class="w-full bg-primary text-white py-3.5 font-bold rounded-lg shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5">Save
                Folder</button>
        </form>
    </div>
</div>

<!-- Link (Item) Modal -->
<div id="link-modal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-xl p-6 shadow-2xl">
        <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900 text-lg" id="v-modal-title">Add Content Link</h3>
            <button onclick="closeLinkModal()" class="text-gray-400 hover:text-gray-600 transition-colors"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form id="v-form" class="space-y-5">
            <input type="hidden" id="v-id" value="0">
            <input type="hidden" id="v-ch-id" value="0">
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Source
                    Type</label>
                <select id="v-type" onchange="checkExamType()"
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
                    <option value="youtube">YouTube Video</option>
                    <option value="gdrive">Google Drive File</option>
                    <option value="test" selected>Test / Google Form</option>
                </select>
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Lesson
                    Title</label>
                <input type="text" id="v-title" required placeholder="e.g. Masterclass Introduction"
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Resource
                    URL</label>
                <input type="url" id="v-url" required placeholder="https://..."
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Display
                    Order</label>
                <input type="number" id="v-order" value="0"
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
            </div>

            <!-- Exam Mode Section -->
            <div class="pt-2 border-t border-gray-100 mt-2">
                <label id="exam-toggle-wrap" class="flex items-center gap-2 cursor-pointer mb-3">
                    <input type="checkbox" id="v-is-test" onchange="toggleTestFields()"
                        class="rounded border-gray-300 text-primary focus:ring-primary">
                    <span class="text-[10px] font-black text-gray-700 uppercase tracking-widest">Enable Exam Mode (No
                        Cheating)</span>
                </label>

                <div id="test-fields" class="hidden space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label
                                class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Start
                                Time</label>
                            <input type="datetime-local" id="v-start-time"
                                class="w-full px-3 py-2 border border-gray-200 bg-gray-50 text-xs rounded-lg focus:outline-none focus:border-primary">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">End
                                Time</label>
                            <input type="datetime-local" id="v-end-time"
                                class="w-full px-3 py-2 border border-gray-200 bg-gray-50 text-xs rounded-lg focus:outline-none focus:border-primary">
                        </div>
                    </div>
                    <p class="text-[9px] text-gray-400 leading-tight italic">Students won't be able to switch tabs,
                        right-click, or copy content during this window.</p>
                </div>
            </div>
            <button type="submit" id="btn-v"
                class="w-full bg-primary text-white py-3.5 font-bold rounded-lg shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5">Add
                to Folder</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center rounded-lg ' + (type === 'success' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-100 text-red-700 border border-red-200');
        el.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} mr-2"></i>${msg}`;
        el.classList.remove('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function toggleFolder(id, e) {
        if (e && e.target.closest('button')) return; // Don't toggle if button clicked
        const items = document.getElementById('items-' + id);
        const icon = document.getElementById('icon-' + id);
        const arrow = document.getElementById('arrow-' + id);

        const isHidden = items.classList.contains('hidden');
        if (isHidden) {
            items.classList.remove('hidden');
            icon.classList.replace('fa-folder', 'fa-folder-open');
            arrow.classList.add('rotate-180');
        } else {
            items.classList.add('hidden');
            icon.classList.replace('fa-folder-open', 'fa-folder');
            arrow.classList.remove('rotate-180');
        }
    }

    // Chapter/Folder Logic
    function openChapterModal(ch, parentId = 0) {
        if (typeof ch === 'object' && ch !== null) {
            document.getElementById('ch-id').value = ch.id;
            document.getElementById('ch-parent-id').value = ch.parent_id;
            document.getElementById('ch-title').value = ch.title;
            document.getElementById('ch-order').value = ch.sort_order;
            document.getElementById('ch-modal-title').textContent = 'Edit Folder';
        } else {
            document.getElementById('ch-id').value = 0;
            document.getElementById('ch-parent-id').value = parentId;
            document.getElementById('ch-title').value = '';
            document.getElementById('ch-order').value = 0;
            document.getElementById('ch-modal-title').textContent = parentId > 0 ? 'New Sub-Folder' : 'New Root Folder';
        }
        document.getElementById('ch-modal').classList.remove('hidden');
    }

    document.getElementById('ch-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btn-ch');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', document.getElementById('ch-id').value > 0 ? 'edit' : 'add');
        data.append('id', document.getElementById('ch-id').value);
        data.append('parent_id', document.getElementById('ch-parent-id').value);
        data.append('title', document.getElementById('ch-title').value);
        data.append('sort_order', document.getElementById('ch-order').value);

        fetch('/admin/chapter.php?course_id=<?php echo $course_id; ?>', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    location.reload();
                } else {
                    showAlert(res.message, 'error');
                    btn.disabled = false;
                    btn.textContent = 'Save Folder';
                }
            });
    });

    function deleteChapter(id) {
        if (!confirm('Warning: This will delete this folder and EVERYTHING inside it (subfolders and videos). Proceed?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);
        fetch('/admin/chapter.php?course_id=<?php echo $course_id; ?>', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => { if (res.success) location.reload(); });
    }

    // Link/Item Logic
    function checkExamType() {
        const type = document.getElementById('v-type').value;
        const examWrapper = document.getElementById('exam-toggle-wrap');
        const examCheckbox = document.getElementById('v-is-test');
        const testFields = document.getElementById('test-fields');

        if (type !== 'test') {
            examCheckbox.checked = false;
            examWrapper.classList.add('opacity-40', 'pointer-events-none');
            testFields.classList.add('hidden');
        } else {
            examWrapper.classList.remove('opacity-40', 'pointer-events-none');
        }
    }

    function openLinkModal(chId, v) {
        document.getElementById('v-ch-id').value = chId;
        document.getElementById('v-id').value = v ? v.id : 0;
        document.getElementById('v-title').value = v ? v.title : '';
        document.getElementById('v-url').value = v ? v.url : '';
        document.getElementById('v-type').value = v ? v.type : 'youtube';
        document.getElementById('v-order').value = v ? v.sort_order : 0;

        // Exam Mode Fields
        const isTest = document.getElementById('v-is-test');
        isTest.checked = v ? (parseInt(v.is_test) === 1) : false;

        // Format dates for datetime-local input (YYYY-MM-DDTHH:MM)
        const formatDT = (dt) => {
            if (!dt) return '';
            const d = new Date(dt);
            const z = n => ('0' + n).slice(-2);
            return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`;
        };

        document.getElementById('v-start-time').value = v ? formatDT(v.start_time) : '';
        document.getElementById('v-end-time').value = v ? v.end_time?.replace(' ', 'T') : '';
        checkExamType(); // Add this line
        toggleTestFields();
        document.getElementById('v-modal-title').textContent = v ? 'Edit Lesson' : 'Add Content Link';
        document.getElementById('link-modal').classList.remove('hidden');
    }

    function toggleTestFields() {
        const fields = document.getElementById('test-fields');
        const isChecked = document.getElementById('v-is-test').checked;
        fields.classList.toggle('hidden', !isChecked);
    }

    function closeLinkModal() {
        document.getElementById('link-modal').classList.add('hidden');
    }

    document.getElementById('v-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btn-v');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', document.getElementById('v-id').value > 0 ? 'edit_link' : 'add_link');
        data.append('id', document.getElementById('v-id').value);
        data.append('chapter_id', document.getElementById('v-ch-id').value);
        data.append('type', document.getElementById('v-type').value);
        data.append('title', document.getElementById('v-title').value);
        data.append('url', document.getElementById('v-url').value);
        data.append('sort_order', document.getElementById('v-order').value);
        data.append('is_test', document.getElementById('v-is-test').checked ? 1 : 0);
        data.append('start_time', document.getElementById('v-start-time').value.replace('T', ' '));
        data.append('end_time', document.getElementById('v-end-time').value.replace('T', ' '));

        fetch('/admin/chapter.php?course_id=<?php echo $course_id; ?>', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    location.reload();
                } else {
                    showAlert(res.message, 'error');
                    btn.disabled = false;
                    btn.textContent = 'Save Item';
                }
            });
    });

    function deleteLink(id) {
        if (!confirm('Delete this item?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete_link');
        data.append('id', id);
        fetch('/admin/chapter.php?course_id=<?php echo $course_id; ?>', { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => { if (res.success) document.getElementById('video-' + id).remove(); });
    }
</script>

<?php include 'common/bottom.php'; ?>