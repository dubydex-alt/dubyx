<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once __DIR__ . '/../common/config.php';

// Handle Action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'close') {
        $conn->query("UPDATE tickets SET status = 'closed' WHERE id = $id");
        echo json_encode(['success' => true]);
        exit;
    }
    if ($action === 'pending') {
        $conn->query("UPDATE tickets SET status = 'pending' WHERE id = $id");
        echo json_encode(['success' => true]);
        exit;
    }
    if ($action === 'delete') {
        $conn->query("DELETE FROM tickets WHERE id = $id");
        echo json_encode(['success' => true]);
        exit;
    }
}

$page_title = 'Support Tickets';
include 'common/header.php';

$offset = (int) ($_GET['offset'] ?? 0);
$limit = 10;

$tickets = $conn->query("SELECT t.*, u.name as user_name, tch.name as teacher_name 
                         FROM tickets t 
                         LEFT JOIN users u ON t.user_id = u.id AND t.user_type = 'student'
                         LEFT JOIN teachers tch ON (t.user_id = tch.id AND t.user_type = 'teacher') OR (t.teacher_id = tch.id)
                         ORDER BY t.status DESC, t.created_at DESC LIMIT $limit OFFSET $offset");

$total_check = $conn->query("SELECT COUNT(id) as total FROM tickets")->fetch_assoc();
$has_more = ($offset + $limit) < $total_check['total'];
?>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-bold text-gray-900">Support Tickets</h2>
        <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Admin View</p>
    </div>

    <div class="space-y-4">
        <?php if ($tickets->num_rows === 0): ?>
            <div class="bg-white p-12 text-center rounded-xl border-2 border-dashed text-gray-400">
                <i class="fas fa-ticket-alt text-5xl mb-4 opacity-20"></i>
                <p class="font-bold">No tickets found.</p>
            </div>
        <?php else:
            while ($t = $tickets->fetch_assoc()): ?>
                <div class="bg-white rounded-xl shadow-sm border p-5 group hover:border-primary transition-all">
                    <div class="flex items-start justify-between mb-4">
                        <div class="flex gap-4">
                            <div
                                class="w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center text-primary border border-gray-100">
                                <i class="fas fa-ticket-alt text-xl"></i>
                            </div>
                            <div>
                                <h3 class="font-bold text-gray-900">
                                    <?php echo clean($t['subject']); ?>
                                </h3>
                                <div class="flex items-center gap-2 mt-1">
                                    <span
                                        class="text-[10px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded <?php echo $t['user_type'] === 'teacher' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'; ?>">
                                        <?php echo $t['user_type']; ?>
                                    </span>
                                    <span class="text-xs text-gray-500 font-medium">
                                        By:
                                        <?php echo clean($t['user_name'] ?: $t['teacher_name'] ?: 'Unknown'); ?>
                                    </span>
                                    <?php if ($t['teacher_name'] && $t['user_type'] === 'student'): ?>
                                        <span class="text-xs text-gray-400">•</span>
                                        <span class="text-[10px] text-gray-400 font-bold uppercase">Teacher:
                                            <?php echo clean($t['teacher_name']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="flex items-center gap-3">
                            <span
                                class="px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest 
                                <?php echo $t['status'] === 'open' ? 'bg-green-100 text-green-600' : ($t['status'] === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'); ?>">
                                <?php echo $t['status']; ?>
                            </span>
                            <div class="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <?php if ($t['status'] === 'open'): ?>
                                    <button onclick="ticketAction(<?php echo $t['id']; ?>, 'pending')"
                                        class="p-2 text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors"
                                        title="Mark Pending">
                                        <i class="fas fa-clock"></i>
                                    </button>
                                <?php endif; ?>
                                <?php if ($t['status'] !== 'closed'): ?>
                                    <button onclick="ticketAction(<?php echo $t['id']; ?>, 'close')"
                                        class="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                                        title="Mark Closed">
                                        <i class="fas fa-check-circle"></i>
                                    </button>
                                <?php endif; ?>
                                <button onclick="ticketAction(<?php echo $t['id']; ?>, 'delete')"
                                    class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div
                        class="bg-gray-50 p-4 rounded-xl border border-gray-100 italic text-sm text-gray-600 leading-relaxed mb-4">
                        "
                        <?php echo nl2br(clean($t['message'])); ?>"
                    </div>

                    <div
                        class="flex items-center justify-between text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                        <span>Ticket ID: #
                            <?php echo $t['id']; ?>
                        </span>
                        <span>Raised on:
                            <?php echo date('d M Y - h:i A', strtotime($t['created_at'])); ?>
                        </span>
                    </div>
                </div>
            <?php endwhile;
        endif; ?>
        <?php if ($has_more): ?>
            <div class="text-center mt-8">
                <a href="?offset=<?php echo $offset + $limit; ?>" class="text-primary font-bold text-sm hover:underline">
                    Load More Tickets <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
        <?php endif; ?>
    </div>
</main>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';
    function ticketAction(id, action) {
        if (!confirm('Are you sure you want to ' + action + ' this ticket?')) return;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action);
        data.append('id', id);

        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json())
            .then(res => { if (res.success) location.reload(); });
    }
</script>

<?php include 'common/bottom.php'; ?>