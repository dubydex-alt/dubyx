<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Payments';
require_once __DIR__ . '/../common/config.php';
include 'common/header.php';

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$status_filter = isset($_GET['status']) ? clean($_GET['status']) : '';
$where = "o.razorpay_order_id IS NOT NULL AND o.razorpay_order_id != ''";
if ($status_filter && in_array($status_filter, ['success', 'failed'])) {
    $where .= " AND o.status = '" . $conn->real_escape_string($status_filter) . "'";
}

$total = $conn->query("SELECT COUNT(*) as c FROM orders o WHERE $where")->fetch_assoc()['c'];
$total_pages = ceil($total / $limit);

$payments = $conn->query("SELECT o.*, u.name as user_name, u.email as user_email, c.title as course_title 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN courses c ON o.course_id = c.id 
    WHERE $where 
    ORDER BY o.created_at DESC 
    LIMIT $limit OFFSET $offset");

// Summary
$total_success = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 'success'")->fetch_assoc()['total'];
$total_failed_count = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status = 'failed'")->fetch_assoc()['c'];
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">Payments</h2>

    <!-- Summary -->
    <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="bg-green-50 p-4">
            <p class="text-xs text-green-600 font-medium">Total Collected</p>
            <p class="text-xl font-bold text-green-700">&#8377;<?php echo number_format($total_success); ?></p>
        </div>
        <div class="bg-red-50 p-4">
            <p class="text-xs text-red-600 font-medium">Failed Payments</p>
            <p class="text-xl font-bold text-red-700"><?php echo number_format($total_failed_count); ?></p>
        </div>
    </div>

    <!-- Filter -->
    <div class="flex gap-2 mb-4">
        <a href="/admin/payments.php"
            class="px-4 py-2 text-sm font-medium <?php echo !$status_filter ? 'bg-sky-600 text-white' : 'bg-white text-gray-700'; ?>">All</a>
        <a href="/admin/payments.php?status=success"
            class="px-4 py-2 text-sm font-medium <?php echo $status_filter === 'success' ? 'bg-green-600 text-white' : 'bg-white text-gray-700'; ?>">Success</a>
        <a href="/admin/payments.php?status=failed"
            class="px-4 py-2 text-sm font-medium <?php echo $status_filter === 'failed' ? 'bg-red-600 text-white' : 'bg-white text-gray-700'; ?>">Failed</a>
    </div>

    <!-- Payments List -->
    <div class="space-y-3">
        <?php if ($payments && $payments->num_rows > 0): ?>
            <?php while ($p = $payments->fetch_assoc()): ?>
                <div class="bg-white p-4 shadow-sm">
                    <div class="flex items-start justify-between mb-2">
                        <div>
                            <p class="font-semibold text-gray-900 text-sm"><?php echo clean($p['user_name']); ?></p>
                            <p class="text-xs text-gray-500"><?php echo clean($p['course_title']); ?></p>
                        </div>
                        <span
                            class="text-lg font-bold <?php echo $p['status'] === 'success' ? 'text-green-600' : 'text-red-600'; ?>">
                            &#8377;<?php echo number_format($p['amount']); ?>
                        </span>
                    </div>
                    <div class="space-y-1 text-xs text-gray-500">
                        <?php if ($p['razorpay_order_id']): ?>
                            <p>Order ID: <?php echo clean($p['razorpay_order_id']); ?></p>
                        <?php endif; ?>
                        <?php if ($p['razorpay_payment_id']): ?>
                            <p>Payment ID: <?php echo clean($p['razorpay_payment_id']); ?></p>
                        <?php endif; ?>
                        <div class="flex items-center justify-between mt-2">
                            <span
                                class="px-2 py-0.5 text-xs font-medium <?php echo $p['status'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                <?php echo ucfirst($p['status']); ?>
                            </span>
                            <span><?php echo date('d M Y, H:i', strtotime($p['created_at'])); ?></span>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="bg-white p-8 text-center text-gray-500">
                <i class="fas fa-credit-card text-3xl mb-2"></i>
                <p>No payments found</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-center gap-2 mt-6">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&status=<?php echo $status_filter; ?>"
                    class="px-3 py-2 bg-white text-gray-700 text-sm shadow-sm">Prev</a>
            <?php endif; ?>
            <span class="px-3 py-2 text-sm text-gray-500">Page <?php echo $page; ?> of <?php echo $total_pages; ?></span>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?>&status=<?php echo $status_filter; ?>"
                    class="px-3 py-2 bg-white text-gray-700 text-sm shadow-sm">Next</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'common/bottom.php'; ?>