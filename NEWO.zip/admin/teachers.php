<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Manage Teachers';
require_once __DIR__ . '/../common/config.php';

// AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'block') {
        $conn->query("UPDATE teachers SET status = 'blocked' WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Teacher blocked.']);
        exit;
    }
    if ($action === 'unblock') {
        $conn->query("UPDATE teachers SET status = 'active' WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Teacher activated.']);
        exit;
    }
    if ($action === 'delete') {
        $conn->query("DELETE FROM teachers WHERE id = $id");
        echo json_encode(['success' => true, 'message' => 'Teacher deleted.']);
        exit;
    }
}

$teachers = $conn->query("SELECT * FROM teachers ORDER BY id DESC");

include 'common/header.php';
?>

<main class="p-4">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-gray-900">Manage Teachers</h2>
        <a href="/admin/add_teacher.php" class="bg-primary text-white px-4 py-2 rounded text-sm font-medium">
            <i class="fas fa-plus mr-1"></i>Add Teacher
        </a>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="bg-white shadow-sm overflow-x-auto">
        <table class="w-full text-left text-sm">
            <thead class="bg-gray-50 text-gray-600 font-medium border-b">
                <tr>
                    <th class="px-4 py-3">ID</th>
                    <th class="px-4 py-3">Teacher</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php if ($teachers && $teachers->num_rows > 0): ?>
                    <?php while ($t = $teachers->fetch_assoc()): ?>
                        <tr>
                            <td class="px-4 py-3 font-medium text-gray-900"><?php echo clean($t['teacher_id_str']); ?></td>
                            <td class="px-4 py-3">
                                <div class="flex items-center">
                                    <?php if ($t['logo']): ?>
                                        <img src="/<?php echo $t['logo']; ?>"
                                            class="w-8 h-8 rounded-full bg-gray-100 mr-2 object-cover">
                                    <?php else: ?>
                                        <div
                                            class="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-2">
                                            <?php echo strtoupper(substr($t['name'], 0, 1)); ?>
                                        </div>
                                    <?php endif; ?>
                                    <span><?php echo clean($t['name']); ?></span>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-gray-600"><?php echo clean($t['email']); ?></td>
                            <td class="px-4 py-3">
                                <span
                                    class="px-2 py-1 rounded-full text-xs font-bold <?php echo $t['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                                    <?php echo ucfirst($t['status']); ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-right space-x-2">
                                <a href="/admin/add_teacher.php?id=<?php echo $t['id']; ?>"
                                    class="text-blue-600 hover:text-blue-800" title="Edit Controls">
                                    <i class="fas fa-cog"></i>
                                </a>
                                <?php if ($t['status'] === 'active'): ?>
                                    <button onclick="teacherAction(<?php echo $t['id']; ?>, 'block')"
                                        class="text-orange-500 hover:text-orange-700" title="Block">
                                        <i class="fas fa-ban"></i>
                                    </button>
                                <?php else: ?>
                                    <button onclick="teacherAction(<?php echo $t['id']; ?>, 'unblock')"
                                        class="text-green-500 hover:text-green-700" title="Unblock">
                                        <i class="fas fa-check"></i>
                                    </button>
                                <?php endif; ?>
                                <button onclick="teacherAction(<?php echo $t['id']; ?>, 'delete')"
                                    class="text-red-500 hover:text-red-700" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="px-4 py-8 text-center text-gray-500">No teachers found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';
    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function teacherAction(id, action) {
        if (!confirm('Are you sure you want to ' + action + ' this teacher?')) return;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action);
        data.append('id', id);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/teachers.php', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                showAlert(res.message, res.success ? 'success' : 'error');
                if (res.success) setTimeout(() => location.reload(), 500);
            } catch (e) { showAlert('Error processing request.', 'error'); }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>