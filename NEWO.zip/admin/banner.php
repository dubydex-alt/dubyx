<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Banners';
require_once __DIR__ . '/../common/config.php';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id = (int) ($_POST['id'] ?? 0);
        $link = trim($_POST['link'] ?? '');
        $teacher_id = ($_POST['teacher_id'] === 'global' || $_POST['teacher_id'] === '') ? null : (int) $_POST['teacher_id'];

        if ($action === 'add' && empty($_FILES['image']['name'])) {
            echo json_encode(['success' => false, 'message' => 'Image is required.']);
            exit;
        }

        $image_name = '';
        if (!empty($_FILES['image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid image format.']);
                exit;
            }
            $image_name = 'banner_' . time() . '.' . $ext;
            $dest = __DIR__ . '/../uploads/banners/' . $image_name;
            compress_image($_FILES['image']['tmp_name'], $dest);
        }

        try {
            if ($action === 'add') {
                $stmt = $conn->prepare("INSERT INTO banners (image, link, teacher_id) VALUES (?, ?, ?)");
                $stmt->bind_param("ssi", $image_name, $link, $teacher_id);
            } else {
                if ($image_name) {
                    $stmt = $conn->prepare("UPDATE banners SET image = ?, link = ?, teacher_id = ? WHERE id = ?");
                    $stmt->bind_param("ssii", $image_name, $link, $teacher_id, $id);
                } else {
                    $stmt = $conn->prepare("UPDATE banners SET link = ?, teacher_id = ? WHERE id = ?");
                    $stmt->bind_param("sii", $link, $teacher_id, $id);
                }
            }
            if (!$stmt->execute()) {
                throw new Exception($stmt->error);
            }
            $stmt->close();
            log_activity($conn, null, "Admin " . ($action === 'add' ? 'added' : 'updated') . " banner");
            echo json_encode(['success' => true, 'message' => 'Banner saved!']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'DB Error: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        soft_delete($conn, 'banners', $id);
        log_activity($conn, null, "Admin deleted banner #$id");
        echo json_encode(['success' => true, 'message' => 'Banner deleted.']);
        exit;
    }
}

$banners = $conn->query("SELECT b.*, t.name as teacher_name FROM banners b LEFT JOIN teachers t ON b.teacher_id = t.id WHERE b.deleted_at IS NULL ORDER BY b.id DESC");
$teachers_list = $conn->query("SELECT id, name, teacher_id_str FROM teachers WHERE status = 'active' ORDER BY name");
$teachers_arr = [];
while ($t = $teachers_list->fetch_assoc())
    $teachers_arr[] = $t;
include 'common/header.php';
?>

<main class="p-4">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-gray-900">Banners</h2>
        <button onclick="openBannerModal()" class="bg-primary text-white px-4 py-2 text-sm font-medium">
            <i class="fas fa-plus mr-1"></i>Add
        </button>
    </div>

    <!-- Alert -->
    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <!-- Banner List -->
    <div class="space-y-3">
        <?php while ($b = $banners->fetch_assoc()): ?>
            <div class="bg-white shadow-sm" id="banner-<?php echo $b['id']; ?>">
                <img src="/uploads/banners/<?php echo clean($b['image']); ?>" alt="Banner"
                    class="w-full aspect-video object-cover">
                <div class="p-3 flex items-center justify-between">
                    <span class="text-xs text-gray-500 truncate flex-1"><?php echo clean($b['link'] ?: 'No link'); ?></span>
                    <span
                        class="text-[10px] text-primary font-bold ml-2 uppercase whitespace-nowrap"><?php echo $b['teacher_name'] ? 'Teacher: ' . clean($b['teacher_name']) : 'Global'; ?></span>
                    <div class="flex gap-2 ml-2">
                        <button
                            onclick="openBannerModal(<?php echo $b['id']; ?>, '<?php echo addslashes($b['link']); ?>', '<?php echo $b['teacher_id']; ?>')"
                            class="text-primary text-sm"><i class="fas fa-edit"></i></button>
                        <button onclick="deleteBanner(<?php echo $b['id']; ?>)" class="text-red-500 text-sm"><i
                                class="fas fa-trash"></i></button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<!-- Modal -->
<div id="banner-modal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-end justify-center">
    <div class="bg-white w-full max-w-lg p-6 animate-slide-up">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-bold text-gray-900" id="modal-title">Add Banner</h3>
            <button onclick="closeBannerModal()" class="text-gray-400"><i class="fas fa-times text-xl"></i></button>
        </div>
        <form id="banner-form" class="space-y-4">
            <input type="hidden" id="b-id" value="0">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Banner Image (16:9)</label>
                <input type="file" id="b-image" accept="image/*"
                    class="w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:bg-primary file:text-white file:border-0 file:font-medium file:text-sm">
                <div id="b-preview" class="mt-2 hidden">
                    <img src="" class="w-full aspect-video object-cover" id="b-preview-img">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Link (optional)</label>
                <input type="url" id="b-link"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                    placeholder="https://...">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Assign to Teacher</label>
                <select id="b-teacher"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                    <option value="global">Global (Show to All)</option>
                    <?php foreach ($teachers_arr as $t): ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo clean($t['name']); ?>
                            (<?php echo $t['teacher_id_str']; ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" id="btn-save" class="w-full bg-primary text-white py-3 font-semibold">Save
                Banner</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function openBannerModal(id, link, teacher_id) {
        document.getElementById('b-id').value = id || 0;
        document.getElementById('b-link').value = link || '';
        document.getElementById('b-teacher').value = teacher_id || 'global';
        document.getElementById('modal-title').textContent = id ? 'Edit Banner' : 'Add Banner';
        document.getElementById('b-preview').classList.add('hidden');
        document.getElementById('b-image').value = '';
        document.getElementById('banner-modal').classList.remove('hidden');
    }

    function closeBannerModal() {
        document.getElementById('banner-modal').classList.add('hidden');
    }

    document.getElementById('b-image').addEventListener('change', function (e) {
        if (e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = function (ev) {
                document.getElementById('b-preview-img').src = ev.target.result;
                document.getElementById('b-preview').classList.remove('hidden');
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    document.getElementById('banner-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btn-save');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        btn.disabled = true;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', document.getElementById('b-id').value > 0 ? 'edit' : 'add');
        data.append('id', document.getElementById('b-id').value);
        data.append('link', document.getElementById('b-link').value);
        data.append('teacher_id', document.getElementById('b-teacher').value);
        if (document.getElementById('b-image').files[0]) {
            data.append('image', document.getElementById('b-image').files[0]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/banner.php', true);
        xhr.onload = function () {
            btn.innerHTML = 'Save Banner';
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    closeBannerModal();
                    showAlert(res.message, 'success');
                    setTimeout(() => location.reload(), 500);
                } else {
                    showAlert(res.message, 'error');
                }
            } catch (e) { showAlert('Error occurred.', 'error'); }
        };
        xhr.send(data);
    });

    function deleteBanner(id) {
        if (!confirm('Delete this banner?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/banner.php', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    document.getElementById('banner-' + id).remove();
                    showAlert(res.message, 'success');
                }
            } catch (e) { }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>