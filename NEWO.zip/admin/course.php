<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Courses';
require_once __DIR__ . '/../common/config.php';

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $mrp = (float) ($_POST['mrp'] ?? 0);
        $price = (float) ($_POST['price'] ?? 0);
        $description = trim($_POST['description'] ?? '');
        $meta_description = trim($_POST['meta_description'] ?? '');
        $category_id = (int) ($_POST['category_id'] ?? 0);
        $teacher_id = ($_POST['teacher_id'] === 'global' || $_POST['teacher_id'] === '') ? null : (int) $_POST['teacher_id'];

        if (empty($title) || $price <= 0) {
            echo json_encode(['success' => false, 'message' => 'Title and price are required.']);
            exit;
        }

        $image_name = '';
        if (!empty($_FILES['image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid image format.']);
                exit;
            }
            $image_name = 'course_' . time() . '.' . $ext;
            $dest = __DIR__ . '/../uploads/courses/' . $image_name;
            compress_image($_FILES['image']['tmp_name'], $dest);
        }

        try {
            if ($action === 'add') {
                if (empty($image_name)) {
                    echo json_encode(['success' => false, 'message' => 'Course image is required.']);
                    exit;
                }
                $stmt = $conn->prepare("INSERT INTO courses (title, mrp, price, description, meta_description, image, category_id, teacher_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sddsssii", $title, $mrp, $price, $description, $meta_description, $image_name, $category_id, $teacher_id);
            } else {
                if ($image_name) {
                    $stmt = $conn->prepare("UPDATE courses SET title = ?, mrp = ?, price = ?, description = ?, meta_description = ?, image = ?, category_id = ?, teacher_id = ? WHERE id = ?");
                    $stmt->bind_param("sddsssiii", $title, $mrp, $price, $description, $meta_description, $image_name, $category_id, $teacher_id, $id);
                } else {
                    $stmt = $conn->prepare("UPDATE courses SET title = ?, mrp = ?, price = ?, description = ?, meta_description = ?, category_id = ?, teacher_id = ? WHERE id = ?");
                    $stmt->bind_param("sddssiii", $title, $mrp, $price, $description, $meta_description, $category_id, $teacher_id, $id);
                }
            }
            if (!$stmt->execute()) {
                throw new Exception($stmt->error);
            }
            $stmt->close();
            log_activity($conn, null, "Admin " . ($action === 'add' ? 'added' : 'updated') . " course: $title");
            echo json_encode(['success' => true, 'message' => 'Course saved!']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'DB Error: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        soft_delete($conn, 'courses', $id);
        log_activity($conn, null, "Admin deleted course #$id");
        echo json_encode(['success' => true, 'message' => 'Course deleted.']);
        exit;
    }
}

$courses = $conn->query("SELECT c.*, cat.name as category_name, t.name as teacher_name FROM courses c LEFT JOIN categories cat ON c.category_id = cat.id LEFT JOIN teachers t ON c.teacher_id = t.id WHERE c.deleted_at IS NULL ORDER BY c.id DESC");
$categories = $conn->query("SELECT id, name FROM categories ORDER BY name");
$teachers_list = $conn->query("SELECT id, name, teacher_id_str FROM teachers WHERE status = 'active' ORDER BY name");
$cats_arr = [];
while ($cat = $categories->fetch_assoc())
    $cats_arr[] = $cat;
$teachers_arr = [];
while ($t = $teachers_list->fetch_assoc())
    $teachers_arr[] = $t;

include 'common/header.php';
?>

<main class="p-4">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-gray-900">Courses</h2>
        <button onclick="openCourseModal()" class="bg-primary text-white px-4 py-2 text-sm font-medium">
            <i class="fas fa-plus mr-1"></i>Add
        </button>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="space-y-3">
        <?php while ($c = $courses->fetch_assoc()): ?>
            <div class="bg-white shadow-sm flex overflow-hidden" id="course-<?php echo $c['id']; ?>">
                <img src="/uploads/courses/<?php echo clean($c['image']); ?>" alt=""
                    class="w-24 h-20 object-cover flex-shrink-0">
                <div class="flex-1 p-3">
                    <h3 class="text-sm font-semibold text-gray-900 line-clamp-1"><?php echo clean($c['title']); ?></h3>
                    <p class="text-xs text-gray-500"><?php echo clean($c['category_name'] ?? 'No category'); ?> &bull;
                        &#8377;<?php echo number_format($c['price']); ?></p>
                    <p class="text-[10px] text-primary font-bold mt-1 uppercase">
                        <?php echo $c['teacher_name'] ? 'Teacher: ' . clean($c['teacher_name']) : 'Global (All Students)'; ?>
                    </p>
                    <div class="flex gap-3 mt-2">
                        <a href="/admin/chapter.php?course_id=<?php echo $c['id']; ?>"
                            class="text-xs text-primary font-medium"><i class="fas fa-list mr-1"></i>Chapters</a>
                        <a href="/admin/live.php?course_id=<?php echo $c['id']; ?>"
                            class="text-xs text-red-600 font-medium"><i class="fas fa-satellite-dish mr-1"></i>Live</a>
                        <button onclick='openCourseModal(<?php echo json_encode($c); ?>)' class="text-xs text-gray-600"><i
                                class="fas fa-edit mr-1"></i>Edit</button>
                        <button onclick="deleteCourse(<?php echo $c['id']; ?>)" class="text-xs text-red-500"><i
                                class="fas fa-trash mr-1"></i>Delete</button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<!-- Course Modal -->
<div id="course-modal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-end justify-center">
    <div class="bg-white w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
        <div class="flex items-center justify-between mb-4">
            <h3 class="font-bold text-gray-900" id="c-modal-title">Add Course</h3>
            <button onclick="closeCourseModal()" class="text-gray-400"><i class="fas fa-times text-xl"></i></button>
        </div>
        <form id="course-form" class="space-y-4">
            <input type="hidden" id="c-id" value="0">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input type="text" id="c-title" required
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select id="c-category"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                    <option value="0">Select Category</option>
                    <?php foreach ($cats_arr as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>"><?php echo clean($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Assign to Teacher</label>
                <select id="c-teacher"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                    <option value="global">Global (Show to All)</option>
                    <?php foreach ($teachers_arr as $t): ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo clean($t['name']); ?>
                            (<?php echo $t['teacher_id_str']; ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">MRP</label>
                    <input type="number" id="c-mrp" step="0.01"
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Price</label>
                    <input type="number" id="c-price" step="0.01" required
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea id="c-desc" rows="4"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"></textarea>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Meta Description (SEO)</label>
                <input type="text" id="c-meta" maxlength="300"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                    placeholder="Brief description for search engines">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Thumbnail (16:9)</label>
                <input type="file" id="c-image" accept="image/*"
                    class="w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:bg-primary file:text-white file:border-0 file:font-medium file:text-sm">
            </div>
            <button type="submit" id="btn-course" class="w-full bg-primary text-white py-3 font-semibold">Save
                Course</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function openCourseModal(course) {
        document.getElementById('c-id').value = course ? course.id : 0;
        document.getElementById('c-title').value = course ? course.title : '';
        document.getElementById('c-mrp').value = course ? course.mrp : '';
        document.getElementById('c-price').value = course ? course.price : '';
        document.getElementById('c-desc').value = course ? course.description : '';
        document.getElementById('c-meta').value = course ? (course.meta_description || '') : '';
        document.getElementById('c-category').value = course ? (course.category_id || 0) : 0;
        document.getElementById('c-teacher').value = (course && course.teacher_id) ? course.teacher_id : 'global';
        document.getElementById('c-modal-title').textContent = course ? 'Edit Course' : 'Add Course';
        document.getElementById('c-image').value = '';
        document.getElementById('course-modal').classList.remove('hidden');
    }

    function closeCourseModal() {
        document.getElementById('course-modal').classList.add('hidden');
    }

    document.getElementById('course-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btn-course');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        btn.disabled = true;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', document.getElementById('c-id').value > 0 ? 'edit' : 'add');
        data.append('id', document.getElementById('c-id').value);
        data.append('title', document.getElementById('c-title').value);
        data.append('mrp', document.getElementById('c-mrp').value);
        data.append('price', document.getElementById('c-price').value);
        data.append('description', document.getElementById('c-desc').value);
        data.append('meta_description', document.getElementById('c-meta').value);
        data.append('category_id', document.getElementById('c-category').value);
        data.append('teacher_id', document.getElementById('c-teacher').value);
        if (document.getElementById('c-image').files[0]) {
            data.append('image', document.getElementById('c-image').files[0]);
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/course.php', true);
        xhr.onload = function () {
            btn.innerHTML = 'Save Course';
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    closeCourseModal();
                    showAlert(res.message, 'success');
                    setTimeout(() => location.reload(), 500);
                } else {
                    showAlert(res.message, 'error');
                }
            } catch (e) { showAlert('Error occurred.', 'error'); }
        };
        xhr.send(data);
    });

    function deleteCourse(id) {
        if (!confirm('Delete this course?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/course.php', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    document.getElementById('course-' + id).remove();
                    showAlert(res.message, 'success');
                }
            } catch (e) { }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>