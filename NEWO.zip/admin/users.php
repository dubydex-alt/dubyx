<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Users';
require_once __DIR__ . '/../common/config.php';

// AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'block') {
        $conn->query("UPDATE users SET status = 'blocked' WHERE id = $id");
        log_activity($conn, null, "Admin blocked user #$id");
        echo json_encode(['success' => true, 'message' => 'User blocked.']);
        exit;
    }
    if ($action === 'unblock') {
        $conn->query("UPDATE users SET status = 'active' WHERE id = $id");
        log_activity($conn, null, "Admin unblocked user #$id");
        echo json_encode(['success' => true, 'message' => 'User unblocked.']);
        exit;
    }
    if ($action === 'delete') {
        soft_delete($conn, 'users', $id);
        log_activity($conn, null, "Admin deleted user #$id");
        echo json_encode(['success' => true, 'message' => 'User deleted.']);
        exit;
    }
}

// View user purchases
$view_user = (int) ($_GET['view'] ?? 0);

$users = $conn->query("SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id AND o.status = 'success') as purchases FROM users u WHERE u.deleted_at IS NULL ORDER BY u.id DESC");

include 'common/header.php';
?>

<main class="p-4">
    <h2 class="text-lg font-bold text-gray-900 mb-4">Users</h2>
    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <?php if ($view_user > 0):
        $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $view_user);
        $stmt->execute();
        $vu = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $purchases = $conn->query("SELECT o.*, c.title as course_title FROM orders o JOIN courses c ON o.course_id = c.id WHERE o.user_id = $view_user ORDER BY o.created_at DESC");
        ?>
        <div class="mb-4">
            <a href="/admin/users.php" class="text-primary text-sm"><i class="fas fa-arrow-left mr-1"></i>Back</a>
        </div>
        <div class="bg-white shadow-sm p-4 mb-4">
            <h3 class="font-bold text-gray-900 mb-2"><?php echo clean($vu['name']); ?></h3>
            <p class="text-sm text-gray-600"><?php echo clean($vu['email']); ?> &bull; <?php echo clean($vu['phone']); ?>
            </p>
            <p class="text-xs text-gray-400 mt-1">Joined: <?php echo date('d M Y', strtotime($vu['created_at'])); ?> &bull;
                Status: <span
                    class="font-bold <?php echo $vu['status'] === 'active' ? 'text-green-600' : 'text-red-600'; ?>"><?php echo $vu['status']; ?></span>
            </p>
        </div>
        <h3 class="font-bold text-gray-900 mb-2">Purchase History</h3>
        <div class="space-y-2">
            <?php while ($p = $purchases->fetch_assoc()): ?>
                <div class="bg-white shadow-sm p-3 flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-900"><?php echo clean($p['course_title']); ?></p>
                        <p class="text-xs text-gray-500"><?php echo date('d M Y', strtotime($p['created_at'])); ?></p>
                    </div>
                    <div class="text-right">
                        <p
                            class="font-bold text-sm <?php echo $p['status'] === 'success' ? 'text-green-600' : 'text-red-600'; ?>">
                            &#8377;<?php echo number_format($p['amount']); ?></p>
                        <p class="text-xs text-gray-400"><?php echo $p['status']; ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

    <?php else: ?>

        <div class="space-y-2">
            <?php while ($u = $users->fetch_assoc()): ?>
                <div class="bg-white shadow-sm p-4" id="user-<?php echo $u['id']; ?>">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="font-medium text-gray-900 text-sm"><?php echo clean($u['name']); ?></h3>
                            <p class="text-xs text-gray-500"><?php echo clean($u['email']); ?> &bull;
                                <?php echo $u['purchases']; ?> purchases</p>
                            <p class="text-xs mt-1">
                                <span
                                    class="<?php echo $u['status'] === 'active' ? 'text-green-600' : 'text-red-600'; ?> font-bold"><?php echo $u['status']; ?></span>
                            </p>
                        </div>
                        <div class="flex flex-col gap-1">
                            <a href="/admin/users.php?view=<?php echo $u['id']; ?>" class="text-xs text-primary"><i
                                    class="fas fa-eye"></i></a>
                            <?php if ($u['status'] === 'active'): ?>
                                <button onclick="userAction(<?php echo $u['id']; ?>, 'block')" class="text-xs text-orange-500"
                                    title="Block"><i class="fas fa-ban"></i></button>
                            <?php else: ?>
                                <button onclick="userAction(<?php echo $u['id']; ?>, 'unblock')" class="text-xs text-green-500"
                                    title="Unblock"><i class="fas fa-check"></i></button>
                            <?php endif; ?>
                            <button onclick="userAction(<?php echo $u['id']; ?>, 'delete')" class="text-xs text-red-500"
                                title="Delete"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
</main>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';
    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function userAction(id, action) {
        if (action === 'delete' && !confirm('Delete this user?')) return;
        if (action === 'block' && !confirm('Block this user?')) return;

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', action);
        data.append('id', id);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/users.php', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                showAlert(res.message, res.success ? 'success' : 'error');
                if (res.success) setTimeout(() => location.reload(), 500);
            } catch (e) { }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>