<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Add/Edit Teacher';
require_once __DIR__ . '/../common/config.php';

$id = (int) ($_GET['id'] ?? 0);
$teacher = null;
if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $teacher = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Features list
$available_features = [
    'courses' => 'Manage Courses',
    'students' => 'View own Students',
    'orders' => 'View own Orders',
    'banners' => 'Custom Banners',
    'notifications' => 'Send Notifications',
    'live_sessions' => 'Live Sessions Manager',
    'live_chat' => 'Live Chat',
    'community' => 'Community & Discussion'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $features = isset($_POST['features']) ? json_encode($_POST['features']) : '[]';

    if (empty($name) || empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Name and Email are required.']);
        exit;
    }

    // Logo Upload
    $logo_path = $teacher['logo'] ?? null;
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
        $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        $filename = 'uploads/teachers/logo_' . time() . '.' . $ext;
        if (!is_dir('../uploads/teachers'))
            mkdir('../uploads/teachers', 0755, true);
        if (move_uploaded_file($_FILES['logo']['tmp_name'], '../' . $filename)) {
            $logo_path = $filename;
        }
    }

    if ($id > 0) {
        // Update
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE teachers SET name = ?, email = ?, password = ?, features = ?, logo = ? WHERE id = ?");
            $stmt->bind_param("sssssi", $name, $email, $hashed, $features, $logo_path, $id);
        } else {
            $stmt = $conn->prepare("UPDATE teachers SET name = ?, email = ?, features = ?, logo = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $name, $email, $features, $logo_path, $id);
        }
    } else {
        // Insert (New Teacher)
        // Auto-generate ID: TCH + Random 5 digits
        $teacher_id_str = 'TCH' . mt_rand(10000, 99999);
        // Check if unique (extremely rare collision but still)
        $check = $conn->prepare("SELECT id FROM teachers WHERE teacher_id_str = ?");
        $check->bind_param("s", $teacher_id_str);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $teacher_id_str = 'TCH' . mt_rand(10000, 99999);
        }
        $check->close();

        // Pass defaults to 123456 if empty
        $pass_to_hash = !empty($password) ? $password : '123456';
        $hashed = password_hash($pass_to_hash, PASSWORD_DEFAULT);

        // QR Code data: Just the ID string
        $qr_data = $teacher_id_str;
        $qr_path = "https://api.qrserver.com/v1/create-qr-code/?data=" . $qr_data . "&size=200x200";

        $stmt = $conn->prepare("INSERT INTO teachers (teacher_id_str, name, email, password, qr_code, features, logo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $teacher_id_str, $name, $email, $hashed, $qr_path, $features, $logo_path);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Teacher saved successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }
    $stmt->close();
    exit;
}

include 'common/header.php';
$teacher_features = $teacher ? json_decode($teacher['features'] ?? '[]', true) : [];
?>

<main class="p-4">
    <div class="mb-4">
        <a href="/admin/teachers.php" class="text-primary text-sm"><i class="fas fa-arrow-left mr-1"></i>Back to
            Teachers</a>
    </div>

    <div class="bg-white shadow-sm p-6 max-w-2xl mx-auto">
        <h2 class="text-xl font-bold text-gray-900 mb-6">
            <?php echo $id > 0 ? 'Edit' : 'Add New'; ?> Teacher
        </h2>

        <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

        <form id="form-teacher" onsubmit="return handleTeacher(event)" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input type="text" name="name" required
                        value="<?php echo $teacher ? clean($teacher['name']) : ''; ?>"
                        class="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:border-primary"
                        placeholder="Teacher's Full Name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email / Username</label>
                    <input type="email" name="email" required
                        value="<?php echo $teacher ? clean($teacher['email']) : ''; ?>"
                        class="w-full px-3 py-2 border border-gray-300 focus:outline-none focus:border-primary"
                        placeholder="Email Address">
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Password
                    <?php echo $id > 0 ? '<span class="text-xs text-gray-400 font-normal">(Leave blank to keep current)</span>' : '<span class="text-xs text-gray-400 font-normal">(Default: 123456)</span>'; ?>
                </label>
                <input type="password" name="password" <?php echo $id > 0 ? '' : ''; ?> class="w-full px-3 py-2 border
                border-gray-300 focus:outline-none focus:border-primary" placeholder="Password">
            </div>

            <?php if ($id > 0 && $teacher['teacher_id_str']): ?>
                <div class="bg-gray-50 p-4 mb-4 flex items-center justify-between border">
                    <div>
                        <p class="text-xs text-gray-500 font-bold uppercase tracking-wider">Teacher ID</p>
                        <p class="text-lg font-mono font-bold text-primary">
                            <?php echo $teacher['teacher_id_str']; ?>
                        </p>
                    </div>
                    <div>
                        <img src="<?php echo $teacher['qr_code']; ?>" alt="QR Code" class="w-20 h-20 border">
                        <p class="text-[10px] text-center text-gray-400 mt-1">Scan to Join</p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Feature Control</label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <?php foreach ($available_features as $key => $label): ?>
                        <label
                            class="flex items-center space-x-2 bg-gray-50 p-2 border border-transparent hover:border-gray-200 rounded cursor-pointer">
                            <input type="checkbox" name="features[]" value="<?php echo $key; ?>" <?php echo in_array($key, $teacher_features) ? 'checked' : ''; ?> class="w-4 h-4 text-primary focus:ring-primary
                        border-gray-300 rounded">
                            <span class="text-sm text-gray-700">
                                <?php echo $label; ?>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-1">Teacher Logo / Branding</label>
                <?php if ($teacher && $teacher['logo']): ?>
                    <div class="mb-2">
                        <img src="/<?php echo $teacher['logo']; ?>" class="h-16 w-16 object-cover border">
                    </div>
                <?php endif; ?>
                <input type="file" name="logo" accept="image/*"
                    class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-primary-dark">
            </div>

            <button type="submit" id="btn-save"
                class="w-full bg-primary text-white py-3 font-semibold rounded hover:bg-primary-dark transition duration-200">
                <?php echo $id > 0 ? 'Update' : 'Add'; ?> Teacher
            </button>
        </form>
    </div>
</main>

<script>
    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function handleTeacher(e) {
        e.preventDefault();
        const form = document.getElementById('form-teacher');
        const btn = document.getElementById('btn-save');
        const originalText = btn.textContent;

        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        btn.disabled = true;

        const data = new FormData(form);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/add_teacher.php<?php echo $id > 0 ? "?id=" . $id : ""; ?>', true);
        xhr.onload = function () {
            btn.textContent = originalText;
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    showAlert(res.message, 'success');
                    setTimeout(() => window.location.href = '/admin/teachers.php', 1000);
                } else {
                    showAlert(res.message, 'error');
                }
            } catch (e) { showAlert('Error saving teacher data.', 'error'); }
        };
        xhr.onerror = function () {
            btn.textContent = originalText;
            btn.disabled = false;
            showAlert('Network error.', 'error');
        };
        xhr.send(data);
        return false;
    }
</script>

<?php include 'common/bottom.php'; ?>