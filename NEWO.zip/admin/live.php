<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Live Sessions';
require_once __DIR__ . '/../common/config.php';

$course_id = (int) ($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    header('Location: /admin/course.php');
    exit;
}

$course = $conn->query("SELECT title FROM courses WHERE id = $course_id")->fetch_assoc();
if (!$course) {
    header('Location: /admin/course.php');
    exit;
}

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $status = $_POST['status'] ?? 'upcoming';
        $scheduled_at = $_POST['scheduled_at'] ?? null;

        if (empty($title) || empty($url)) {
            echo json_encode(['success' => false, 'message' => 'Title and URL are required.']);
            exit;
        }

        if ($id === 0) {
            $stmt = $conn->prepare("INSERT INTO live_sessions (course_id, teacher_id, title, url, status, scheduled_at) VALUES (?, 0, ?, ?, ?, ?)");
            $stmt->bind_param("issss", $course_id, $title, $url, $status, $scheduled_at);
        } else {
            $stmt = $conn->prepare("UPDATE live_sessions SET title = ?, url = ?, status = ?, scheduled_at = ? WHERE id = ? AND course_id = ?");
            $stmt->bind_param("ssssii", $title, $url, $status, $scheduled_at, $id, $course_id);
        }
        $stmt->execute();
        $stmt->close();

        if ($status === 'ended') {
            $conn->query("DELETE FROM live_comments WHERE live_id = $id");
            $conn->query("DELETE FROM live_blocks WHERE live_id = $id");
        }

        echo json_encode(['success' => true, 'message' => 'Live session saved!']);
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $conn->query("DELETE FROM live_sessions WHERE id = $id AND course_id = $course_id");
        echo json_encode(['success' => true]);
        exit;
    }
}

include 'common/header.php';
?>

<main class="p-4 bg-gray-50 min-h-screen">
    <div class="mb-4">
        <a href="/admin/course.php" class="text-primary text-sm font-medium"><i class="fas fa-arrow-left mr-1"></i>Back
            to Courses</a>
    </div>

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
            <h1 class="text-xl font-bold text-gray-900">
                <?php echo clean($course['title']); ?>
            </h1>
            <p class="text-xs text-red-600 font-black uppercase tracking-widest"><i
                    class="fas fa-satellite-dish animate-pulse"></i> Live Sessions Manager</p>
        </div>
        <button onclick="openModal()"
            class="bg-primary text-white px-5 py-2.5 text-sm font-bold flex items-center justify-center gap-2 rounded shadow-lg shadow-primary/20">
            <i class="fas fa-plus"></i> New Live Session
        </button>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php
        $sessions = $conn->query("SELECT * FROM live_sessions WHERE course_id = $course_id ORDER BY scheduled_at DESC, id DESC");
        if ($sessions->num_rows === 0): ?>
            <div class="col-span-full bg-white border-2 border-dashed rounded-xl p-16 text-center text-gray-400">
                <i class="fas fa-video-slash text-5xl mb-4 opacity-20"></i>
                <p class="font-bold">No live sessions scheduled yet.</p>
            </div>
        <?php else:
            while ($s = $sessions->fetch_assoc()): ?>
                <div class="bg-white rounded-xl shadow-sm border p-5 group hover:border-primary transition-all">
                    <div class="flex items-center justify-between mb-3">
                        <span
                            class="px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest
                            <?php echo $s['status'] === 'live' ? 'bg-red-100 text-red-600' : ($s['status'] === 'upcoming' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'); ?>">
                            <?php echo $s['status']; ?>
                        </span>
                        <div class="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onclick='openModal(<?php echo json_encode($s); ?>)'
                                class="text-gray-400 hover:text-primary"><i class="fas fa-edit text-sm"></i></button>
                            <button onclick="deleteSession(<?php echo $s['id']; ?>)" class="text-gray-400 hover:text-red-600"><i
                                    class="fas fa-trash-alt text-sm"></i></button>
                        </div>
                    </div>
                    <h3 class="font-bold text-gray-900 mb-1">
                        <?php echo clean($s['title']); ?>
                    </h3>
                    <p class="text-xs text-gray-400 mb-4 truncate font-medium">
                        <?php echo clean($s['url']); ?>
                    </p>
                    <div class="flex items-center gap-2 text-[10px] text-gray-500 font-bold bg-gray-50 p-2 rounded-lg">
                        <i class="fas fa-calendar"></i>
                        <?php echo $s['scheduled_at'] ? date('D, d M Y - h:i A', strtotime($s['scheduled_at'])) : 'No time set'; ?>
                    </div>
                </div>
            <?php endwhile;
        endif; ?>
    </div>
</main>

<!-- Modal -->
<div id="modal" class="fixed inset-0 bg-black/50 z-[9999] hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl">
        <div class="flex items-center justify-between mb-6">
            <h3 class="font-bold text-gray-900 text-lg" id="modal-title">New Live Session</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 transition-colors"><i
                    class="fas fa-times text-xl"></i></button>
        </div>
        <form id="live-form" class="space-y-4">
            <input type="hidden" id="s-id" value="0">
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Session
                    Title</label>
                <input type="text" id="s-title" required
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all"
                    placeholder="e.g. Q&A Live Session #1">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">YouTube Live
                    URL</label>
                <input type="url" id="s-url" required
                    class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all"
                    placeholder="https://www.youtube.com/live/...">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label
                        class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Status</label>
                    <select id="s-status"
                        class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
                        <option value="upcoming">Upcoming</option>
                        <option value="live">Live Now</option>
                        <option value="ended">Ended</option>
                    </select>
                </div>
                <div>
                    <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Schedule
                        Time</label>
                    <input type="datetime-local" id="s-time"
                        class="w-full px-4 py-3 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all">
                </div>
            </div>
            <button type="submit" id="submit-btn"
                class="w-full bg-primary text-white py-3.5 font-bold rounded-xl shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5 mt-4">Save
                Session</button>
        </form>
    </div>
</div>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function openModal(s = null) {
        document.getElementById('s-id').value = s ? s.id : 0;
        document.getElementById('s-title').value = s ? s.title : '';
        document.getElementById('s-url').value = s ? s.url : '';
        document.getElementById('s-status').value = s ? s.status : 'upcoming';
        document.getElementById('s-time').value = s ? s.scheduled_at.replace(' ', 'T') : '';
        document.getElementById('modal-title').textContent = s ? 'Edit Live Session' : 'New Live Session';
        document.getElementById('modal').classList.remove('hidden');
    }

    function closeModal() { document.getElementById('modal').classList.add('hidden'); }

    document.getElementById('live-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('submit-btn');
        btn.disabled = true;
        btn.innerHTML = 'Saving...';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'save');
        data.append('id', document.getElementById('s-id').value);
        data.append('title', document.getElementById('s-title').value);
        data.append('url', document.getElementById('s-url').value);
        data.append('status', document.getElementById('s-status').value);
        data.append('scheduled_at', document.getElementById('s-time').value);

        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json()).then(res => { if (res.success) location.reload(); });
    });

    function deleteSession(id) {
        if (!confirm('Delete this session?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);
        fetch(window.location.href, { method: 'POST', body: data })
            .then(r => r.json()).then(res => { if (res.success) location.reload(); });
    }
</script>

<?php include 'common/bottom.php'; ?>