<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'Videos';
require_once __DIR__ . '/../common/config.php';

$chapter_id = (int) ($_GET['chapter_id'] ?? 0);
$course_id = (int) ($_GET['course_id'] ?? 0);
if ($chapter_id <= 0) {
    header('Location: /admin/course.php');
    exit;
}

$chapter = $conn->query("SELECT title FROM chapters WHERE id = $chapter_id")->fetch_assoc();
if (!$chapter) {
    header('Location: /admin/course.php');
    exit;
}

// Handle AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'upload') {
        $title = trim($_POST['title'] ?? '');
        $sort_order = (int) ($_POST['sort_order'] ?? 0);
        $type = $_POST['type'] ?? 'mp4';
        $item_url = trim($_POST['url'] ?? '');
        $is_test = (int) ($_POST['is_test'] ?? 0);
        $start_time = $_POST['start_time'] ?: null;
        $end_time = $_POST['end_time'] ?: null;

        if (empty($title)) {
            echo json_encode(['success' => false, 'message' => 'Title is required.']);
            exit;
        }

        $filename = '';
        if ($type === 'mp4') {
            if (empty($_FILES['video']['name'])) {
                echo json_encode(['success' => false, 'message' => 'Video file is required for MP4 type.']);
                exit;
            }
            $ext = strtolower(pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION));
            if ($ext !== 'mp4') {
                echo json_encode(['success' => false, 'message' => 'Only MP4 files are allowed.']);
                exit;
            }
            $filename = 'vid_' . $chapter_id . '_' . time() . '.mp4';
            $dest = __DIR__ . '/../uploads/videos/' . $filename;
            if (!move_uploaded_file($_FILES['video']['tmp_name'], $dest)) {
                echo json_encode(['success' => false, 'message' => 'Upload failed.']);
                exit;
            }
        }

        $stmt = $conn->prepare("INSERT INTO videos (chapter_id, title, filename, type, url, sort_order, is_test, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssiiss", $chapter_id, $title, $filename, $type, $item_url, $sort_order, $is_test, $start_time, $end_time);

        if ($stmt->execute()) {
            log_activity($conn, null, "Admin added $type item: $title");
            echo json_encode(['success' => true, 'message' => 'Item added!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        }
        $stmt->close();
        exit;
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $vid = $conn->query("SELECT filename FROM videos WHERE id = $id")->fetch_assoc();
        if ($vid) {
            @unlink(__DIR__ . '/../uploads/videos/' . $vid['filename']);
            $conn->query("DELETE FROM videos WHERE id = $id");
        }
        echo json_encode(['success' => true, 'message' => 'Video deleted.']);
        exit;
    }
}

$videos = $conn->query("SELECT * FROM videos WHERE chapter_id = $chapter_id ORDER BY sort_order, id");
include 'common/header.php';
?>

<main class="p-4">
    <div class="mb-4">
        <a href="/admin/chapter.php?course_id=<?php echo $course_id; ?>" class="text-primary text-sm"><i
                class="fas fa-arrow-left mr-1"></i>Back to Chapters</a>
    </div>

    <div class="flex items-center justify-between mb-4">
        <div>
            <h2 class="text-lg font-bold text-gray-900">Videos</h2>
            <p class="text-sm text-gray-500"><?php echo clean($chapter['title']); ?></p>
        </div>
    </div>

    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <div class="bg-white shadow-sm p-4 mb-4">
        <h3 class="font-bold text-gray-900 mb-3">Add Chapter Item</h3>
        <form id="upload-form" class="space-y-3">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Item Title</label>
                    <input type="text" id="v-title" required
                        class="w-full px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Item Type</label>
                    <select id="v-type" onchange="toggleTypeFields()"
                        class="w-full px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                        <option value="mp4">Video File (MP4)</option>
                        <option value="youtube">YouTube Link</option>
                        <option value="test">Test / Google Form</option>
                    </select>
                </div>
            </div>

            <div id="file-field">
                <label class="block text-sm font-medium text-gray-700 mb-1">MP4 File</label>
                <input type="file" id="v-file" accept="video/mp4"
                    class="w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:bg-primary file:text-white file:border-0 file:font-medium file:text-sm">
            </div>

            <div id="url-field" class="hidden">
                <label class="block text-sm font-medium text-gray-700 mb-1">URL (YouTube or Google Form)</label>
                <input type="url" id="v-url" placeholder="https://..."
                    class="w-full px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sort Order</label>
                    <input type="number" id="v-order" value="0"
                        class="w-full px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Exam Mode</label>
                    <select id="v-is-test" onchange="toggleExamFields()"
                        class="w-full px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
                        <option value="0">OFF</option>
                        <option value="1">ON (Secure Environment)</option>
                    </select>
                </div>
            </div>

            <!-- Exam Timing Fields -->
            <div id="exam-fields" class="hidden grid grid-cols-2 gap-4 p-3 bg-red-50 border border-red-100 rounded">
                <div>
                    <label class="block text-xs font-bold text-red-700 mb-1 uppercase">Start Time (IST)</label>
                    <input type="datetime-local" id="v-start" class="w-full px-3 py-2 border border-red-200 text-sm">
                </div>
                <div>
                    <label class="block text-xs font-bold text-red-700 mb-1 uppercase">End Time (IST)</label>
                    <input type="datetime-local" id="v-end" class="w-full px-3 py-2 border border-red-200 text-sm">
                </div>
            </div>

            <!-- Progress Bar -->
            <div id="progress-wrap" class="hidden">
                <div class="w-full bg-gray-200 h-3">
                    <div id="progress-bar" class="bg-primary h-3 transition-all duration-300" style="width: 0%"></div>
                </div>
                <p class="text-xs text-gray-500 mt-1"><span id="progress-text">0</span>% uploaded</p>
            </div>
            <button type="submit" id="btn-upload" class="w-full bg-primary text-white py-3 font-semibold">
                <i class="fas fa-plus mr-2"></i>Add Chapter Item
            </button>
        </form>
    </div>

    <!-- Video List -->
    <div class="space-y-2">
        <?php while ($v = $videos->fetch_assoc()): ?>
            <div class="bg-white shadow-sm p-4 flex items-center justify-between" id="video-<?php echo $v['id']; ?>">
                <div class="flex items-center gap-3">
                    <i class="fas fa-video text-primary"></i>
                    <div>
                        <h3 class="font-medium text-gray-900 text-sm">
                            <?php echo clean($v['title']); ?>
                            <?php if ($v['is_test']): ?>
                                <span
                                    class="ml-2 bg-red-100 text-red-700 text-[10px] px-2 py-0.5 rounded font-black uppercase">EXAM</span>
                            <?php endif; ?>
                        </h3>
                        <p class="text-xs text-gray-500">
                            Order: <?php echo $v['sort_order']; ?> &bull;
                            <?php echo strtoupper($v['type']); ?>
                            <?php if ($v['is_test']): ?>
                                &bull; <?php echo date('d M, h:i A', strtotime($v['start_time'])); ?> -
                                <?php echo date('h:i A', strtotime($v['end_time'])); ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <button onclick="deleteVideo(<?php echo $v['id']; ?>)" class="text-red-500 text-sm"><i
                        class="fas fa-trash"></i></button>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function toggleTypeFields() {
        const type = document.getElementById('v-type').value;
        document.getElementById('file-field').classList.toggle('hidden', type !== 'mp4');
        document.getElementById('url-field').classList.toggle('hidden', type === 'mp4');

        // Only allow Exam Mode for 'test' type
        const examModeSelect = document.getElementById('v-is-test');
        if (type !== 'test') {
            examModeSelect.value = '0';
            examModeSelect.disabled = true;
            document.getElementById('exam-fields').classList.add('hidden');
        } else {
            examModeSelect.disabled = false;
        }
    }

    function toggleExamFields() {
        const isTest = document.getElementById('v-is-test').value === '1';
        document.getElementById('exam-fields').classList.toggle('hidden', !isTest);
    }

    document.getElementById('upload-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const btn = document.getElementById('btn-upload');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';

        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'upload');
        data.append('title', document.getElementById('v-title').value);
        data.append('type', document.getElementById('v-type').value);
        data.append('url', document.getElementById('v-url').value);
        data.append('sort_order', document.getElementById('v-order').value);
        data.append('is_test', document.getElementById('v-is-test').value);
        data.append('start_time', document.getElementById('v-start').value);
        data.append('end_time', document.getElementById('v-end').value);

        if (document.getElementById('v-type').value === 'mp4') {
            data.append('video', document.getElementById('v-file').files[0]);
            document.getElementById('progress-wrap').classList.remove('hidden');
        }

        const xhr = new XMLHttpRequest();
        xhr.upload.addEventListener('progress', function (e) {
            if (e.lengthComputable && document.getElementById('v-type').value === 'mp4') {
                const pct = Math.round((e.loaded / e.total) * 100);
                document.getElementById('progress-bar').style.width = pct + '%';
                document.getElementById('progress-text').textContent = pct;
            }
        });
        xhr.open('POST', '/admin/video.php?chapter_id=<?php echo $chapter_id; ?>&course_id=<?php echo $course_id; ?>', true);
        xhr.onload = function () {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-upload mr-2"></i>Upload Video';
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    showAlert(res.message, 'success');
                    setTimeout(() => location.reload(), 500);
                } else { showAlert(res.message, 'error'); }
            } catch (e) { showAlert('Error.', 'error'); }
        };
        xhr.send(data);
    });

    function deleteVideo(id) {
        if (!confirm('Delete this video?')) return;
        const data = new FormData();
        data.append('csrf_token', csrfToken);
        data.append('action', 'delete');
        data.append('id', id);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/admin/video.php?chapter_id=<?php echo $chapter_id; ?>&course_id=<?php echo $course_id; ?>', true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    document.getElementById('video-' + id).remove();
                    showAlert(res.message, 'success');
                }
            } catch (e) { }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>