<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$course_id = (int) ($_GET['course_id'] ?? $_POST['course_id'] ?? 0);
if ($course_id <= 0) {
    header('Location: /course.php');
    exit;
}

// Check course exists
$stmt = $conn->prepare("SELECT id, title, price, mrp, image FROM courses WHERE id = ? AND status = 'active' AND deleted_at IS NULL");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$course) {
    header('Location: /course.php');
    exit;
}

// Check if already purchased
$stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND status = 'success'");
$stmt->bind_param("ii", $_SESSION['user_id'], $course_id);
$stmt->execute();
if ($stmt->get_result()->num_rows > 0) {
    header('Location: /mycourses.php');
    exit;
}
$stmt->close();

// AJAX: Validate coupon
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'validate_coupon') {
    header('Content-Type: application/json');
    $code = trim($_POST['coupon_code'] ?? '');
    if (empty($code)) {
        echo json_encode(['success' => false, 'message' => 'Enter a coupon code.']);
        exit;
    }
    $stmt = $conn->prepare("SELECT id, discount_percent FROM coupons WHERE code = ? AND status = 'active' AND expiry_date >= CURDATE()");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $coupon = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($coupon) {
        $discount_amount = round(($course['price'] * $coupon['discount_percent']) / 100, 2);
        $final_price = max(1, $course['price'] - $discount_amount);
        echo json_encode(['success' => true, 'discount_percent' => $coupon['discount_percent'], 'discount_amount' => $discount_amount, 'final_price' => $final_price]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired coupon.']);
    }
    exit;
}

// AJAX: Create Razorpay Order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_order') {
    header('Content-Type: application/json');

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $final_price = (float) $course['price'];
    $coupon_code = '';
    $discount_amount = 0;

    // Apply coupon if provided
    $coupon_input = trim($_POST['coupon_code'] ?? '');
    if (!empty($coupon_input)) {
        $stmt = $conn->prepare("SELECT id, discount_percent FROM coupons WHERE code = ? AND status = 'active' AND expiry_date >= CURDATE()");
        $stmt->bind_param("s", $coupon_input);
        $stmt->execute();
        $coupon = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($coupon) {
            $discount_amount = round(($course['price'] * $coupon['discount_percent']) / 100, 2);
            $final_price = max(1, $course['price'] - $discount_amount);
            $coupon_code = $coupon_input;
        }
    }

    $amount_paise = (int) ($final_price * 100);

    // Create Razorpay order via CURL
    $ch = curl_init('https://api.razorpay.com/v1/orders');
    curl_setopt($ch, CURLOPT_USERPWD, $settings['razorpay_key'] . ':' . $settings['razorpay_secret']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'amount' => $amount_paise,
        'currency' => 'INR',
        'receipt' => 'order_' . $_SESSION['user_id'] . '_' . $course_id . '_' . time()
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $rz_order = json_decode($response, true);

    if ($http_code === 200 && isset($rz_order['id'])) {
        // Store pending order
        $stmt = $conn->prepare("INSERT INTO orders (user_id, course_id, amount, status, razorpay_order_id, coupon_code, discount_amount) VALUES (?, ?, ?, 'pending', ?, ?, ?) ON DUPLICATE KEY UPDATE amount = ?, status = 'pending', razorpay_order_id = ?, coupon_code = ?, discount_amount = ?");
        $stmt->bind_param("iidssddssd", $_SESSION['user_id'], $course_id, $final_price, $rz_order['id'], $coupon_code, $discount_amount, $final_price, $rz_order['id'], $coupon_code, $discount_amount);
        $stmt->execute();
        $stmt->close();

        echo json_encode([
            'success' => true,
            'order_id' => $rz_order['id'],
            'amount' => $amount_paise,
            'key' => $settings['razorpay_key']
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create order. Please try again.']);
    }
    exit;
}

// AJAX: Verify Payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_payment') {
    header('Content-Type: application/json');

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $razorpay_order_id = $_POST['razorpay_order_id'] ?? '';
    $razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
    $razorpay_signature = $_POST['razorpay_signature'] ?? '';

    // Verify signature
    $expected = hash_hmac('sha256', $razorpay_order_id . '|' . $razorpay_payment_id, $settings['razorpay_secret']);

    if (hash_equals($expected, $razorpay_signature)) {
        // Generate invoice number
        $invoice_number = 'INV-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

        $stmt = $conn->prepare("UPDATE orders SET status = 'success', razorpay_payment_id = ?, razorpay_signature = ?, invoice_number = ? WHERE razorpay_order_id = ? AND user_id = ?");
        $stmt->bind_param("ssssi", $razorpay_payment_id, $razorpay_signature, $invoice_number, $razorpay_order_id, $_SESSION['user_id']);
        $stmt->execute();
        $stmt->close();

        log_activity($conn, $_SESSION['user_id'], "Purchased course ID: $course_id");
        echo json_encode(['success' => true, 'message' => 'Payment successful!']);
    } else {
        // Payment verification failed
        $stmt = $conn->prepare("UPDATE orders SET status = 'failed' WHERE razorpay_order_id = ? AND user_id = ?");
        $stmt->bind_param("si", $razorpay_order_id, $_SESSION['user_id']);
        $stmt->execute();
        $stmt->close();

        echo json_encode(['success' => false, 'message' => 'Payment verification failed.']);
    }
    exit;
}

$page_title = 'Buy - ' . $course['title'];
include 'common/header.php';
?>

<main class="p-4 max-w-lg mx-auto">
    <!-- Course Summary -->
    <div class="bg-white shadow-sm mb-4">
        <img src="/uploads/courses/<?php echo clean($course['image']); ?>" alt="<?php echo clean($course['title']); ?>"
            class="w-full aspect-video object-cover">
        <div class="p-4">
            <h1 class="font-bold text-lg text-gray-900 mb-2"><?php echo clean($course['title']); ?></h1>
            <div class="flex items-center gap-3">
                <span
                    class="text-xl font-bold text-primary">&#8377;<?php echo number_format($course['price']); ?></span>
                <?php if ($course['mrp'] > $course['price']): ?>
                    <span class="text-gray-400 line-through">&#8377;<?php echo number_format($course['mrp']); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Coupon -->
    <div class="bg-white shadow-sm p-4 mb-4">
        <h3 class="font-bold text-gray-900 mb-3">Have a coupon?</h3>
        <div class="flex gap-2">
            <input type="text" id="coupon-input" placeholder="Enter code"
                class="flex-1 px-4 py-2 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary text-sm">
            <button onclick="applyCoupon()" id="btn-coupon"
                class="bg-gray-800 text-white px-4 py-2 text-sm font-medium">Apply</button>
        </div>
        <div id="coupon-msg" class="hidden mt-2 text-sm"></div>
    </div>

    <!-- Price Summary -->
    <div class="bg-white shadow-sm p-4 mb-4">
        <h3 class="font-bold text-gray-900 mb-3">Order Summary</h3>
        <div class="space-y-2 text-sm">
            <div class="flex justify-between">
                <span class="text-gray-600">Course Price</span>
                <span class="text-gray-900">&#8377;<span
                        id="display-price"><?php echo number_format($course['price'], 2); ?></span></span>
            </div>
            <div class="flex justify-between hidden" id="discount-row">
                <span class="text-green-600">Discount</span>
                <span class="text-green-600">-&#8377;<span id="display-discount">0.00</span></span>
            </div>
            <div class="border-t pt-2 flex justify-between font-bold">
                <span class="text-gray-900">Total</span>
                <span class="text-primary">&#8377;<span
                        id="display-total"><?php echo number_format($course['price'], 2); ?></span></span>
            </div>
        </div>
    </div>

    <!-- Alert -->
    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <!-- Pay Button -->
    <button onclick="startPayment()" id="btn-pay" class="w-full bg-primary text-white py-4 font-bold text-lg">
        <i class="fas fa-lock mr-2"></i>Pay &#8377;<span
            id="btn-price"><?php echo number_format($course['price']); ?></span>
    </button>
</main>

<!-- Payment Status Popup -->
<div id="payment-popup" class="fixed inset-0 bg-black/60 items-center justify-center p-4"
    style="backdrop-filter:blur(4px); display:none; z-index:99999">
    <div class="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden transform transition-all"
        id="popup-box">
        <div class="p-8 text-center">
            <!-- Icon -->
            <div id="popup-icon" class="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-5"></div>
            <!-- Title -->
            <h3 id="popup-title" class="text-xl font-bold text-gray-900 mb-2"></h3>
            <!-- Message -->
            <p id="popup-message" class="text-sm text-gray-500 mb-6 leading-relaxed"></p>
            <!-- Buttons -->
            <div id="popup-buttons" class="space-y-3"></div>
        </div>
    </div>
</div>

<style>
    @keyframes popupIn {
        from {
            opacity: 0;
            transform: scale(0.85)
        }

        to {
            opacity: 1;
            transform: scale(1)
        }
    }

    @keyframes iconPulse {
        0% {
            transform: scale(0)
        }

        60% {
            transform: scale(1.15)
        }

        100% {
            transform: scale(1)
        }
    }

    #popup-box.active {
        animation: popupIn .3s ease-out
    }

    #popup-icon.active {
        animation: iconPulse .5s ease-out .15s both
    }
</style>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    const csrfToken = '<?php echo csrf_token(); ?>';
    const courseId = <?php echo $course_id; ?>;
    const userName = '<?php echo clean($_SESSION['user_name']); ?>';
    const userEmail = '<?php echo clean($_SESSION['user_email']); ?>';
    let couponCode = '';

    // ── Popup System ──
    function showPopup(type, title, message) {
        const popup = document.getElementById('payment-popup');
        const box = document.getElementById('popup-box');
        const icon = document.getElementById('popup-icon');
        const btnContainer = document.getElementById('popup-buttons');

        document.getElementById('popup-title').textContent = title;
        document.getElementById('popup-message').textContent = message;

        // Reset classes
        box.classList.remove('active');
        icon.classList.remove('active');
        icon.className = 'w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-5';

        if (type === 'success') {
            icon.classList.add('bg-green-100');
            icon.innerHTML = '<i class="fas fa-check-circle text-green-500 text-4xl"></i>';
            btnContainer.innerHTML = '<a href="/mycourses.php" class="block w-full bg-green-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-green-700 transition">Go to My Courses</a>';
        } else if (type === 'failed') {
            icon.classList.add('bg-red-100');
            icon.innerHTML = '<i class="fas fa-times-circle text-red-500 text-4xl"></i>';
            btnContainer.innerHTML =
                '<button onclick="closePopup(); startPayment();" class="w-full bg-primary text-white py-3 rounded-xl font-semibold text-sm hover:opacity-90 transition"><i class="fas fa-redo mr-2"></i>Retry Payment</button>' +
                '<button onclick="closePopup()" class="w-full text-gray-500 py-2 text-sm font-medium hover:text-gray-700 transition">Close</button>';
        } else if (type === 'cancelled') {
            icon.classList.add('bg-yellow-100');
            icon.innerHTML = '<i class="fas fa-exclamation-circle text-yellow-500 text-4xl"></i>';
            btnContainer.innerHTML =
                '<button onclick="closePopup(); startPayment();" class="w-full bg-primary text-white py-3 rounded-xl font-semibold text-sm hover:opacity-90 transition"><i class="fas fa-lock mr-2"></i>Try Again</button>' +
                '<a href="/course.php" class="block w-full text-gray-500 py-2 text-sm font-medium hover:text-gray-700 transition text-center">Browse Courses</a>';
        }

        // Hide global loader so it doesn't cover the popup
        var gl = document.getElementById('global-loader');
        if (gl) { gl.style.opacity = '0'; gl.style.visibility = 'hidden'; }

        popup.style.display = 'flex';
        // Trigger animations
        requestAnimationFrame(() => { box.classList.add('active'); icon.classList.add('active'); });
    }

    function closePopup() {
        const popup = document.getElementById('payment-popup');
        popup.style.display = 'none';
    }

    // Close popup on backdrop click
    document.getElementById('payment-popup').addEventListener('click', function (e) {
        if (e.target === this) closePopup();
    });

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
    }

    function resetPayBtn() {
        const btn = document.getElementById('btn-pay');
        btn.innerHTML = '<i class="fas fa-lock mr-2"></i>Pay &#8377;' + document.getElementById('btn-price').textContent;
        btn.disabled = false;
        btn.style.opacity = '1';
    }

    function applyCoupon() {
        const code = document.getElementById('coupon-input').value.trim();
        if (!code) return;

        const btn = document.getElementById('btn-coupon');
        btn.textContent = '...';
        btn.disabled = true;

        const data = new FormData();
        data.append('action', 'validate_coupon');
        data.append('coupon_code', code);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/buy.php?course_id=' + courseId, true);
        xhr.onload = function () {
            btn.textContent = 'Apply';
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                const msg = document.getElementById('coupon-msg');
                msg.classList.remove('hidden');
                if (res.success) {
                    msg.className = 'mt-2 text-sm text-green-600';
                    msg.textContent = res.discount_percent + '% discount applied!';
                    couponCode = code;
                    document.getElementById('discount-row').classList.remove('hidden');
                    document.getElementById('display-discount').textContent = res.discount_amount.toFixed(2);
                    document.getElementById('display-total').textContent = res.final_price.toFixed(2);
                    document.getElementById('btn-price').textContent = Math.round(res.final_price).toLocaleString();
                } else {
                    msg.className = 'mt-2 text-sm text-red-600';
                    msg.textContent = res.message;
                    couponCode = '';
                }
            } catch (e) { }
        };
        xhr.send(data);
    }

    function startPayment() {
        const btn = document.getElementById('btn-pay');
        btn.disabled = true;
        btn.style.opacity = '0.6';

        const data = new FormData();
        data.append('action', 'create_order');
        data.append('csrf_token', csrfToken);
        data.append('course_id', courseId);
        data.append('coupon_code', couponCode);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/buy.php?course_id=' + courseId, true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    openRazorpay(res);
                } else {
                    resetPayBtn();
                    showPopup('failed', 'Order Failed', res.message || 'Could not create payment order. Please try again.');
                }
            } catch (e) {
                resetPayBtn();
                showPopup('failed', 'Something Went Wrong', 'An unexpected error occurred. Please try again.');
            }
        };
        xhr.onerror = function () {
            resetPayBtn();
            showPopup('failed', 'Network Error', 'Please check your internet connection and try again.');
        };
        xhr.send(data);
    }

    function openRazorpay(orderData) {
        try {
            if (typeof Razorpay === 'undefined') {
                resetPayBtn();
                showPopup('failed', 'Payment Unavailable', 'Payment system could not load. Please refresh the page and try again.');
                return;
            }

            const options = {
                key: orderData.key,
                amount: orderData.amount,
                currency: 'INR',
                name: '<?php echo clean($settings['app_name']); ?>',
                description: '<?php echo clean($course['title']); ?>',
                order_id: orderData.order_id,
                prefill: { name: userName, email: userEmail },
                theme: { color: '#0284C7' },
                handler: function (response) {
                    verifyPayment(response);
                },
                modal: {
                    confirm_close: true,
                    ondismiss: function () {
                        try {
                            resetPayBtn();
                            showPopup('cancelled', 'Payment Cancelled', 'You closed the payment window. No amount has been charged. You can try again anytime.');
                        } catch (err) {
                            alert('Payment was cancelled.');
                            resetPayBtn();
                        }
                    }
                }
            };
            const rzp = new Razorpay(options);
            rzp.on('payment.failed', function (resp) {
                try {
                    resetPayBtn();
                    var errMsg = 'Your payment could not be processed. Please try again or use a different payment method.';
                    try { errMsg = resp.error.description || errMsg; } catch (e) { }
                    showPopup('failed', 'Payment Failed', errMsg);
                } catch (err) {
                    alert('Payment failed. Please try again.');
                    resetPayBtn();
                }
            });
            rzp.open();
            resetPayBtn();
        } catch (e) {
            resetPayBtn();
            showPopup('failed', 'Payment Error', 'Could not open payment window. Please refresh the page and try again.');
        }
    }

    function verifyPayment(response) {
        const btn = document.getElementById('btn-pay');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';

        const data = new FormData();
        data.append('action', 'verify_payment');
        data.append('csrf_token', csrfToken);
        data.append('razorpay_order_id', response.razorpay_order_id);
        data.append('razorpay_payment_id', response.razorpay_payment_id);
        data.append('razorpay_signature', response.razorpay_signature);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/buy.php?course_id=' + courseId, true);
        xhr.onload = function () {
            try {
                const res = JSON.parse(xhr.responseText);
                if (res.success) {
                    showPopup('success', 'Payment Successful!', 'Your course has been unlocked. You can start learning right away!');
                } else {
                    resetPayBtn();
                    showPopup('failed', 'Verification Failed', res.message || 'Payment verification failed. If money was deducted, it will be refunded automatically.');
                }
            } catch (e) {
                resetPayBtn();
                showPopup('failed', 'Verification Error', 'Could not verify your payment. Please contact support if money was deducted.');
            }
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>