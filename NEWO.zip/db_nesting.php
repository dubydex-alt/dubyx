<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

// Add parent_id to chapters to allow nesting
$sql = "ALTER TABLE chapters ADD COLUMN parent_id INT(11) DEFAULT 0 AFTER course_id";
if ($conn->query($sql)) {
    echo "Successfully added parent_id to chapters table.\n";
} else {
    echo "Error adding column: " . $conn->error . "\n";
}
?>