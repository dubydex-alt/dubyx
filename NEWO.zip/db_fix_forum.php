<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "<h2>Database Fix Utility</h2>";

$sql = "CREATE TABLE IF NOT EXISTS forum_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    teacher_id INT DEFAULT NULL,
    parent_id INT DEFAULT 0,
    title VARCHAR(255) DEFAULT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_parent (parent_id),
    INDEX idx_user (user_id),
    INDEX idx_teacher (teacher_id)
) ENGINE=InnoDB";

if ($conn->query($sql)) {
    echo "<p style='color: green;'>✅ Table 'forum_posts' created or already exists.</p>";
} else {
    echo "<p style='color: red;'>❌ Error creating table: " . $conn->error . "</p>";
}

echo "<p><a href='/forum.php'>Go to Community Chat</a></p>";
?>