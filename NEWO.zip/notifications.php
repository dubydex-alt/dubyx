<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mark all as read via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if ($_POST['action'] === 'mark_read') {
        $notif_id = (int) ($_POST['id'] ?? 0);
        if ($notif_id > 0) {
            $stmt = $conn->prepare("UPDATE notifications SET read_status = 1 WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $notif_id, $user_id);
            $stmt->execute();
            $stmt->close();
        }
        echo json_encode(['success' => true]);
        exit;
    }

    if ($_POST['action'] === 'mark_all_read') {
        $stmt = $conn->prepare("UPDATE notifications SET read_status = 1 WHERE user_id = ? AND read_status = 0");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
        echo json_encode(['success' => true]);
        exit;
    }
}

$notifications = $conn->query("SELECT * FROM notifications WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 50");
$unread = $conn->query("SELECT COUNT(*) as c FROM notifications WHERE user_id = $user_id AND read_status = 0")->fetch_assoc()['c'];

$page_title = 'Notifications';
include 'common/header.php';
?>

<main class="p-4">
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-lg font-bold text-gray-900">Notifications</h2>
        <?php if ($unread > 0): ?>
            <button onclick="markAllRead()" class="text-sm text-primary font-medium">Mark all read</button>
        <?php endif; ?>
    </div>

    <?php if ($notifications && $notifications->num_rows > 0): ?>
        <div class="space-y-2">
            <?php while ($n = $notifications->fetch_assoc()): ?>
                <div class="bg-white p-4 shadow-sm <?php echo !$n['read_status'] ? 'border-l-4 border-primary' : ''; ?>"
                    id="notif-<?php echo $n['id']; ?>">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex-1">
                            <h3 class="font-semibold text-gray-900 text-sm"><?php echo htmlspecialchars($n['title']); ?></h3>
                            <p class="text-sm text-gray-600 mt-1"><?php echo htmlspecialchars($n['message']); ?></p>
                            <p class="text-xs text-gray-400 mt-2">
                                <?php echo date('d M Y, h:i A', strtotime($n['created_at'])); ?></p>
                        </div>
                        <?php if (!$n['read_status']): ?>
                            <button onclick="markRead(<?php echo $n['id']; ?>)"
                                class="w-8 h-8 flex items-center justify-center text-primary flex-shrink-0" title="Mark as read">
                                <i class="fas fa-check-circle"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="bg-white p-8 text-center text-gray-500 shadow-sm">
            <i class="fas fa-bell-slash text-3xl mb-3 opacity-50"></i>
            <p>No notifications yet</p>
        </div>
    <?php endif; ?>
</main>

<script>
    function markRead(id) {
        const data = new FormData();
        data.append('action', 'mark_read');
        data.append('id', id);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/notifications.php', true);
        xhr.onload = function () {
            const el = document.getElementById('notif-' + id);
            if (el) {
                el.classList.remove('border-l-4', 'border-primary');
                const btn = el.querySelector('button');
                if (btn) btn.remove();
            }
        };
        xhr.send(data);
    }

    function markAllRead() {
        const data = new FormData();
        data.append('action', 'mark_all_read');

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/notifications.php', true);
        xhr.onload = function () {
            document.querySelectorAll('.border-l-4').forEach(el => {
                el.classList.remove('border-l-4', 'border-primary');
                const btn = el.querySelector('button');
                if (btn) btn.remove();
            });
        };
        xhr.send(data);
    }
</script>

<?php include 'common/bottom.php'; ?>