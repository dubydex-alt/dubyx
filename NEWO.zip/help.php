<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'raise_ticket') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $msg = 'Invalid request.';
        $msg_type = 'error';
    } else {
        $subject = clean($_POST['subject']);
        $message = clean($_POST['message']);
        $user_id = $_SESSION['user_id'] ?? 0;
        $teacher_id = $_SESSION['student_teacher_id'] ?? null;
        $user_type = 'student';

        // Check if teacher is logged in instead
        if (isset($_SESSION['teacher_id'])) {
            $user_id = $_SESSION['teacher_id'];
            $teacher_id = $_SESSION['teacher_id'];
            $user_type = 'teacher';
        }

        if ($user_id > 0 && $subject && $message) {
            $stmt = $conn->prepare("INSERT INTO tickets (user_type, user_id, teacher_id, subject, message) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("siiss", $user_type, $user_id, $teacher_id, $subject, $message);
            if ($stmt->execute()) {
                $msg = 'Ticket raised successfully. We will get back to you soon.';
                $msg_type = 'success';
            } else {
                $msg = 'Failed to raise ticket. Please try again.';
                $msg_type = 'error';
            }
            $stmt->close();
        } else {
            $msg = 'Please fill all fields.';
            $msg_type = 'error';
        }
    }
}

$page_title = 'Help & Support';
include 'common/header.php';
?>

<main class="p-4 max-w-lg mx-auto">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-lg font-bold text-gray-900">Help & Support</h2>
        <a href="/mytickets.php"
            class="text-[10px] font-bold text-primary border-b border-primary uppercase tracking-widest hover:text-primary-dark transition-colors">
            View My Tickets
        </a>
    </div>

    <?php if ($msg): ?>
        <div
            class="p-3 mb-4 text-sm text-center <?php echo $msg_type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'; ?>">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <!-- Raise a Ticket Form -->
    <div class="bg-white shadow-sm p-6 mb-6">
        <h3 class="font-bold text-gray-900 mb-4 flex items-center gap-2">
            <i class="fas fa-ticket-alt text-primary"></i> Raise a Ticket
        </h3>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="raise_ticket">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Subject</label>
                <input type="text" name="subject" required
                    class="w-full px-4 py-2 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all"
                    placeholder="Briefly describe your issue">
            </div>
            <div>
                <label class="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Message</label>
                <textarea name="message" rows="4" required
                    class="w-full px-4 py-2 border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:border-primary focus:bg-white text-sm rounded-lg transition-all"
                    placeholder="Provide details about your problem..."></textarea>
            </div>
            <button type="submit"
                class="w-full bg-primary text-white py-3 font-bold rounded-xl shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5">
                Submit Ticket
            </button>
        </form>
    </div>

    <div class="bg-white shadow-sm p-6 mb-4">
        <div class="text-center mb-6">
            <div class="w-16 h-16 bg-primary/10 text-primary flex items-center justify-center mx-auto mb-3">
                <i class="fas fa-headset text-3xl"></i>
            </div>
            <h3 class="font-bold text-gray-900 mb-1">Need Help?</h3>
            <p class="text-gray-500 text-sm">We're here to assist you</p>
        </div>

        <div class="space-y-4">
            <?php if ($settings['support_email']): ?>
                <a href="mailto:<?php echo clean($settings['support_email']); ?>"
                    class="flex items-center gap-4 p-4 bg-gray-50">
                    <div class="w-12 h-12 bg-primary text-white flex items-center justify-center flex-shrink-0">
                        <i class="fas fa-envelope text-lg"></i>
                    </div>
                    <div>
                        <p class="font-semibold text-gray-900 text-sm">Email Us</p>
                        <p class="text-primary text-sm"><?php echo clean($settings['support_email']); ?></p>
                    </div>
                </a>
            <?php endif; ?>

            <?php if ($settings['support_phone']): ?>
                <a href="tel:<?php echo clean($settings['support_phone']); ?>"
                    class="flex items-center gap-4 p-4 bg-gray-50">
                    <div class="w-12 h-12 bg-primary text-white flex items-center justify-center flex-shrink-0">
                        <i class="fas fa-phone text-lg"></i>
                    </div>
                    <div>
                        <p class="font-semibold text-gray-900 text-sm">Call Us</p>
                        <p class="text-primary text-sm"><?php echo clean($settings['support_phone']); ?></p>
                    </div>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white shadow-sm p-6">
        <h3 class="font-bold text-gray-900 mb-4">FAQ</h3>
        <div class="space-y-4">
            <div>
                <h4 class="font-semibold text-gray-900 text-sm mb-1">How do I access purchased courses?</h4>
                <p class="text-gray-500 text-sm">Go to "My Courses" from the bottom navigation after purchasing.</p>
            </div>
            <div>
                <h4 class="font-semibold text-gray-900 text-sm mb-1">Is there a refund policy?</h4>
                <p class="text-gray-500 text-sm">Contact support within 7 days of purchase for refund requests.</p>
            </div>
            <div>
                <h4 class="font-semibold text-gray-900 text-sm mb-1">Can I download videos?</h4>
                <p class="text-gray-500 text-sm">Videos are available for streaming only and cannot be downloaded.</p>
            </div>
            <div>
                <h4 class="font-semibold text-gray-900 text-sm mb-1">How long do I have access?</h4>
                <p class="text-gray-500 text-sm">Once purchased, you have lifetime access to the course content.</p>
            </div>
        </div>
    </div>
</main>

<?php include 'common/bottom.php'; ?>