<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting migration...<br>";

$queries = [
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS teacher_id INT DEFAULT NULL AFTER id",
    "ALTER TABLE categories ADD INDEX IF NOT EXISTS idx_teacher (teacher_id)",

    "ALTER TABLE banners ADD COLUMN IF NOT EXISTS teacher_id INT DEFAULT NULL AFTER id",
    "ALTER TABLE banners ADD INDEX IF NOT EXISTS idx_teacher (teacher_id)",

    "ALTER TABLE courses ADD COLUMN IF NOT EXISTS teacher_id INT DEFAULT NULL AFTER id",
    "ALTER TABLE courses ADD INDEX IF NOT EXISTS idx_teacher (teacher_id)"
];

foreach ($queries as $query) {
    if ($conn->query($query)) {
        echo "Executed: $query <br>";
    } else {
        echo "Error: " . $conn->error . " for query: $query <br>";
    }
}

echo "Migration completed.";
?>