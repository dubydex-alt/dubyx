<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting migration...\n";

// 1. Create teachers table
$sql_teachers = "CREATE TABLE IF NOT EXISTS teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id_str VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    qr_code VARCHAR(255) DEFAULT NULL,
    logo VARCHAR(255) DEFAULT NULL,
    features TEXT DEFAULT NULL, -- JSON string or comma-separated list
    status ENUM('active','blocked') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_teacher_id_str (teacher_id_str),
    INDEX idx_status (status)
) ENGINE=InnoDB";

if ($conn->query($sql_teachers)) {
    echo "Table 'teachers' created or already exists.\n";
} else {
    echo "Error creating 'teachers' table: " . $conn->error . "\n";
}

// 2. Add teacher_id to users table if it doesn't exist
$check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'teacher_id'");
if ($check_column->num_rows == 0) {
    if ($conn->query("ALTER TABLE users ADD COLUMN teacher_id INT DEFAULT NULL AFTER id")) {
        echo "Column 'teacher_id' added to 'users' table.\n";
    } else {
        echo "Error adding 'teacher_id' column: " . $conn->error . "\n";
    }
} else {
    echo "Column 'teacher_id' already exists in 'users' table.\n";
}

// 3. Add foreign key if not exists
// For simplicity, we won't strictly enforce FK if the DB type doesn't support it or if data is messy, 
// but it's good practice.
/*
$sql_fk = "ALTER TABLE users ADD CONSTRAINT fk_user_teacher FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL";
if ($conn->query($sql_fk)) {
    echo "Foreign key added.\n";
}
*/

echo "Migration finished.\n";
?>