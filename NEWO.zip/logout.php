<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();

// ── Clear Remember-Me cookie & DB token ─────────────────
if (isset($_COOKIE['remember_token'])) {
    require_once __DIR__ . '/common/config.php';
    $rtoken = $_COOKIE['remember_token'];
    $stmt = $conn->prepare("UPDATE users SET remember_token = NULL WHERE remember_token = ?");
    $stmt->bind_param('s', $rtoken);
    $stmt->execute();
    $stmt->close();
    // Expire the cookie immediately
    setcookie('remember_token', '', time() - 3600, '/', '', false, true);
}

// ── Destroy session ──────────────────────────────────────
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}
session_destroy();

header('Location: /login.php');
exit;
?>