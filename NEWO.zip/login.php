<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (isset($_SESSION['user_id'])) {
    header('Location: /index.php');
    exit;
}

// AJAX Handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    // LOGIN
    if ($_POST['action'] === 'login') {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required.']);
            exit;
        }

        if (!check_login_rate($conn, $email)) {
            echo json_encode(['success' => false, 'message' => 'Too many attempts. Try again after 10 minutes.']);
            exit;
        }

        $stmt = $conn->prepare("SELECT id, name, email, password, status, teacher_id FROM users WHERE email = ? AND deleted_at IS NULL");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if ($user['status'] === 'blocked') {
                echo json_encode(['success' => false, 'message' => 'Your account has been blocked.']);
                $stmt->close();
                exit;
            }
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['student_teacher_id'] = $user['teacher_id'];

                // Generate and save Session Token for Single Session Policy
                $session_token = bin2hex(random_bytes(32));
                $_SESSION['session_token'] = $session_token;

                $upd_stmt = $conn->prepare("UPDATE users SET session_token = ? WHERE id = ?");
                $upd_stmt->bind_param("si", $session_token, $user['id']);
                $upd_stmt->execute();
                $upd_stmt->close();

                // ── Remember Me ("Always Logged In") ────────────────
                if (!empty($_POST['remember_me'])) {
                    $remember = bin2hex(random_bytes(32));
                    $r_stmt = $conn->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                    $r_stmt->bind_param('si', $remember, $user['id']);
                    $r_stmt->execute();
                    $r_stmt->close();
                    // 30-day HttpOnly cookie
                    setcookie('remember_token', $remember, time() + 60 * 60 * 24 * 30, '/', '', false, true);
                }

                // Update OneSignal ID if provided
                $player_id = trim($_POST['player_id'] ?? '');
                if (!empty($player_id)) {
                    $upd = $conn->prepare("UPDATE users SET onesignal_id = ? WHERE id = ?");
                    $upd->bind_param("si", $player_id, $user['id']);
                    $upd->execute();
                    $upd->close();
                }

                log_activity($conn, $user['id'], 'User logged in');
                echo json_encode(['success' => true, 'message' => 'Login successful!']);
            } else {
                record_login_attempt($conn, $email);
                echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
            }
        } else {
            record_login_attempt($conn, $email);
            echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
        }
        $stmt->close();
        exit;
    }

    // SIGNUP
    if ($_POST['action'] === 'signup') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $teacher_id = (int) ($_POST['teacher_id'] ?? 0);

        if (empty($name) || empty($email) || empty($password) || empty($teacher_id)) {
            echo json_encode(['success' => false, 'message' => 'Name, Email, Password and Teacher selection are required.']);
            exit;
        }
        // ... validation ...
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
            exit;
        }
        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters.']);
            exit;
        }

        // Check duplicate email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Email already registered.']);
            $stmt->close();
            exit;
        }
        $stmt->close();

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $player_id = trim($_POST['player_id'] ?? '');
        $session_token = bin2hex(random_bytes(32));
        $stmt = $conn->prepare("INSERT INTO users (name, phone, email, password, teacher_id, onesignal_id, session_token) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssiss", $name, $phone, $email, $hashed, $teacher_id, $player_id, $session_token);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['student_teacher_id'] = $teacher_id;
            $_SESSION['session_token'] = $session_token;
            log_activity($conn, $stmt->insert_id, 'User signed up');
            echo json_encode(['success' => true, 'message' => 'Account created!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Signup failed. Try again.']);
        }
        $stmt->close();
        exit;
    }
}

$teachers = $conn->query("SELECT id, name, teacher_id_str FROM teachers WHERE status = 'active' ORDER BY name ASC");
$teachers_data = [];
while ($t = $teachers->fetch_assoc()) {
    $teachers_data[] = $t;
}

$page_title = 'Login';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0284C7">
    <title>Login - <?php echo clean($settings['app_name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { primary: '#0284C7', 'primary-dark': '#0369A1' } } } }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <style>
        * {
            -webkit-tap-highlight-color: transparent;
        }

        input {
            -webkit-user-select: text;
            user-select: text;
        }

        .dropdown-item:hover {
            background-color: #f3f4f6;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col">

    <div class="flex-1 flex flex-col items-center justify-center p-6">
        <!-- Logo -->
        <div class="mb-8 text-center">
            <div class="w-20 h-20 bg-primary text-white flex items-center justify-center mx-auto mb-3">
                <i class="fas fa-graduation-cap text-3xl"></i>
            </div>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo clean($settings['app_name']); ?></h1>
            <p class="text-gray-500 text-sm mt-1">Learn new skills today</p>
        </div>

        <div class="w-full max-w-sm">
            <!-- Tabs -->
            <div class="flex mb-6">
                <button id="tab-login" onclick="switchTab('login')"
                    class="flex-1 py-3 text-center font-semibold border-b-2 border-primary text-primary">Login</button>
                <button id="tab-signup" onclick="switchTab('signup')"
                    class="flex-1 py-3 text-center font-semibold border-b-2 border-gray-200 text-gray-400">Signup</button>
            </div>

            <!-- Alert -->
            <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

            <!-- Login Form -->
            <form id="form-login" class="space-y-4" onsubmit="return handleLogin(event)">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" required
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Enter your email">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <input type="password" name="password" required
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Enter your password">
                </div>
                <div class="flex items-center gap-2">
                    <input type="checkbox" name="remember_me" id="remember_me" value="1"
                        class="w-4 h-4 accent-primary cursor-pointer">
                    <label for="remember_me" class="text-sm text-gray-600 cursor-pointer select-none">Remember me for 30
                        days</label>
                </div>
                <button type="submit" id="btn-login" class="w-full bg-primary text-white py-3 font-semibold">
                    Login
                </button>
            </form>

            <!-- Signup Form -->
            <form id="form-signup" class="space-y-4 hidden" onsubmit="return handleSignup(event)">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input type="text" name="name" required
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Enter your name">
                </div>

                <!-- Teacher Selection -->
                <div class="relative">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Select Teacher <span
                            class="text-red-500">*</span></label>
                    <div class="flex gap-2">
                        <div class="relative flex-1">
                            <input type="text" id="teacher-search"
                                class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                                placeholder="Search Teacher or ID" onkeyup="filterTeachers()">
                            <input type="hidden" name="teacher_id" id="teacher-id">
                            <div id="teacher-dropdown"
                                class="absolute left-0 right-0 mt-1 bg-white border border-gray-200 shadow-lg z-50 max-h-48 overflow-y-auto hidden">
                                <?php foreach ($teachers_data as $t): ?>
                                    <div class="dropdown-item px-4 py-2 cursor-pointer text-sm"
                                        onclick="selectTeacher(<?php echo $t['id']; ?>, '<?php echo clean($t['name']); ?> (<?php echo $t['teacher_id_str']; ?>)')">
                                        <p class="font-medium"><?php echo clean($t['name']); ?></p>
                                        <p class="text-[10px] text-gray-500"><?php echo $t['teacher_id_str']; ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <button type="button" onclick="startScanner()"
                            class="bg-gray-100 px-4 border border-gray-300 hover:bg-gray-200" title="Scan QR">
                            <i class="fas fa-qrcode"></i>
                        </button>
                    </div>
                    <div id="qr-reader" class="mt-2 hidden"></div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="tel" name="phone"
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Enter your phone">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" required
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Enter your email">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <input type="password" name="password" required minlength="6"
                        class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                        placeholder="Min 6 characters">
                </div>
                <button type="submit" id="btn-signup" class="w-full bg-primary text-white py-3 font-semibold">
                    Create Account
                </button>
            </form>
        </div>
    </div>

    <script>
        const csrfToken = '<?php echo csrf_token(); ?>';

        function switchTab(tab) {
            document.getElementById('form-login').classList.toggle('hidden', tab !== 'login');
            document.getElementById('form-signup').classList.toggle('hidden', tab !== 'signup');
            document.getElementById('tab-login').classList.toggle('border-primary', tab === 'login');
            document.getElementById('tab-login').classList.toggle('text-primary', tab === 'login');
            document.getElementById('tab-login').classList.toggle('border-gray-200', tab !== 'login');
            document.getElementById('tab-login').classList.toggle('text-gray-400', tab !== 'login');
            document.getElementById('tab-signup').classList.toggle('border-primary', tab === 'signup');
            document.getElementById('tab-signup').classList.toggle('text-primary', tab === 'signup');
            document.getElementById('tab-signup').classList.toggle('border-gray-200', tab !== 'signup');
            document.getElementById('tab-signup').classList.toggle('text-gray-400', tab !== 'signup');
            hideAlert();
        }

        function showAlert(msg, type) {
            const el = document.getElementById('alert');
            el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
            el.textContent = msg;
            el.classList.remove('hidden');
        }

        function hideAlert() {
            document.getElementById('alert').classList.add('hidden');
        }

        function handleLogin(e) {
            e.preventDefault();
            const form = document.getElementById('form-login');
            const btn = document.getElementById('btn-login');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Logging in...';
            btn.disabled = true;

            const data = new FormData(form);
            data.append('action', 'login');
            data.append('csrf_token', csrfToken);

            const urlParams = new URLSearchParams(window.location.search);
            const player_id = urlParams.get('player_id');
            if (player_id) data.append('player_id', player_id);

            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/login.php', true);
            xhr.onload = function () {
                btn.innerHTML = 'Login';
                btn.disabled = false;
                try {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        showAlert(res.message, 'success');
                        setTimeout(() => window.location.href = '/index.php', 500);
                    } else {
                        showAlert(res.message, 'error');
                    }
                } catch (e) { showAlert('Something went wrong.', 'error'); }
            };
            xhr.onerror = function () {
                btn.innerHTML = 'Login';
                btn.disabled = false;
                showAlert('Network error.', 'error');
            };
            xhr.send(data);
            return false;
        }

        const teachersData = <?php echo json_encode($teachers_data); ?>;

        function filterTeachers() {
            const search = document.getElementById('teacher-search').value.toLowerCase();
            const dropdown = document.getElementById('teacher-dropdown');
            const items = dropdown.getElementsByClassName('dropdown-item');
            let hasResults = false;

            if (search.length > 0) {
                dropdown.classList.remove('hidden');
                for (let item of items) {
                    if (item.textContent.toLowerCase().includes(search)) {
                        item.style.display = 'block';
                        hasResults = true;
                    } else {
                        item.style.display = 'none';
                    }
                }
                if (!hasResults) dropdown.classList.add('hidden');
            } else {
                dropdown.classList.add('hidden');
            }
        }

        function selectTeacher(id, label) {
            document.getElementById('teacher-id').value = id;
            document.getElementById('teacher-search').value = label;
            document.getElementById('teacher-dropdown').classList.add('hidden');
        }

        let html5QrCode = null;
        function startScanner() {
            const readerEl = document.getElementById('qr-reader');
            readerEl.classList.toggle('hidden');

            if (readerEl.classList.contains('hidden')) {
                if (html5QrCode) html5QrCode.stop();
                return;
            }

            html5QrCode = new Html5Qrcode("qr-reader");
            html5QrCode.start(
                { facingMode: "environment" },
                { fps: 10, qrbox: { width: 250, height: 250 } },
                (decodedText) => {
                    // Find teacher with this ID string
                    const found = teachersData.find(t => t.teacher_id_str === decodedText);
                    if (found) {
                        selectTeacher(found.id, found.name + ' (' + found.teacher_id_str + ')');
                        html5QrCode.stop().then(() => readerEl.classList.add('hidden'));
                        showAlert('Teacher linked: ' + found.name, 'success');
                    } else {
                        showAlert('Invalid QR or Teacher ID: ' + decodedText, 'error');
                    }
                },
                (errorMessage) => { /* Ignore scan errors */ }
            ).catch(err => {
                showAlert('Camera error: ' + err, 'error');
                readerEl.classList.add('hidden');
            });
        }

        function handleSignup(e) {
            e.preventDefault();
            const form = document.getElementById('form-signup');
            const btn = document.getElementById('btn-signup');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Creating...';
            btn.disabled = true;

            const data = new FormData(form);
            data.append('action', 'signup');
            data.append('csrf_token', csrfToken);

            const urlParams = new URLSearchParams(window.location.search);
            const player_id = urlParams.get('player_id');
            if (player_id) data.append('player_id', player_id);

            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/login.php', true);
            xhr.onload = function () {
                btn.innerHTML = 'Create Account';
                btn.disabled = false;
                try {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        showAlert(res.message, 'success');
                        setTimeout(() => window.location.href = '/index.php', 500);
                    } else {
                        showAlert(res.message, 'error');
                    }
                } catch (e) { showAlert('Something went wrong.', 'error'); }
            };
            xhr.onerror = function () {
                btn.innerHTML = 'Create Account';
                btn.disabled = false;
                showAlert('Network error.', 'error');
            };
            xhr.send(data);
            return false;
        }
    </script>
</body>

</html>