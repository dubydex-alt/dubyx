<?php
/**
 * fix_db_schema.php
 * Run once to fix "Unknown column 'status'", "Unknown column 'mrp'", missing 'admin' table, etc.
 */
require_once 'common/config.php';

echo "<h2>🚀 Database Schema Fixer</h2>";

function log_msg($msg, $type = 'info')
{
    $color = $type === 'success' ? 'green' : ($type === 'error' ? 'red' : 'gray');
    echo "<p style='color:$color'>$msg</p>";
}

// 1. Fix Courses Table
log_msg("Checking 'courses' table...");
// Check if mrp exists
$check_mrp = $conn->query("SHOW COLUMNS FROM `courses` LIKE 'mrp'");
if ($check_mrp && $check_mrp->num_rows == 0) {
    if ($conn->query("ALTER TABLE `courses` ADD COLUMN `mrp` DECIMAL(10,2) DEFAULT 0.00 AFTER `title`")) {
        log_msg("✔ Added column 'mrp' to 'courses'", 'success');
    } else {
        log_msg("✘ Error adding 'mrp' to 'courses': " . $conn->error, 'error');
    }
}

// Check for thumbnail/image rename
$check_image = $conn->query("SHOW COLUMNS FROM `courses` LIKE 'image'");
$check_thumb = $conn->query("SHOW COLUMNS FROM `courses` LIKE 'thumbnail'");
if ($check_image && $check_image->num_rows == 0 && $check_thumb && $check_thumb->num_rows > 0) {
    if ($conn->query("ALTER TABLE `courses` CHANGE COLUMN `thumbnail` `image` VARCHAR(255) DEFAULT NULL")) {
        log_msg("✔ Renamed 'thumbnail' to 'image' in 'courses'", 'success');
    } else {
        log_msg("✘ Error renaming 'thumbnail' to 'image': " . $conn->error, 'error');
    }
} elseif ($check_image && $check_image->num_rows == 0 && $check_thumb && $check_thumb->num_rows == 0) {
    if ($conn->query("ALTER TABLE `courses` ADD COLUMN `image` VARCHAR(255) DEFAULT NULL AFTER `mrp`")) {
        log_msg("✔ Added column 'image' to 'courses'", 'success');
    }
}

// Add status if missing
$check_status = $conn->query("SHOW COLUMNS FROM `courses` LIKE 'status'");
if ($check_status && $check_status->num_rows == 0) {
    $conn->query("ALTER TABLE `courses` ADD COLUMN `status` ENUM('active','blocked') DEFAULT 'active'");
    log_msg("✔ Added column 'status' to 'courses'", 'success');
}

// Add deleted_at if missing
$check_deleted = $conn->query("SHOW COLUMNS FROM `courses` LIKE 'deleted_at'");
if ($check_deleted && $check_deleted->num_rows == 0) {
    $conn->query("ALTER TABLE `courses` ADD COLUMN `deleted_at` DATETIME DEFAULT NULL");
    log_msg("✔ Added column 'deleted_at' to 'courses'", 'success');
}

// 2. Fix Banners Table
log_msg("Checking 'banners' table...");
$check_b_status = $conn->query("SHOW COLUMNS FROM `banners` LIKE 'status'");
if ($check_b_status && $check_b_status->num_rows == 0) {
    $conn->query("ALTER TABLE `banners` ADD COLUMN `status` ENUM('active','blocked') DEFAULT 'active'");
    log_msg("✔ Added column 'status' to 'banners'", 'success');
}
$check_b_deleted = $conn->query("SHOW COLUMNS FROM `banners` LIKE 'deleted_at'");
if ($check_b_deleted && $check_b_deleted->num_rows == 0) {
    $conn->query("ALTER TABLE `banners` ADD COLUMN `deleted_at` DATETIME DEFAULT NULL");
    log_msg("✔ Added column 'deleted_at' to 'banners'", 'success');
}

// 3. Ensure 'orders' table exists
log_msg("Checking 'orders' table...");
$conn->query("CREATE TABLE IF NOT EXISTS `orders` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`             INT NOT NULL,
  `course_id`           INT NOT NULL,
  `amount`              DECIMAL(10,2) DEFAULT 0.00,
  `discount_amount`     DECIMAL(10,2) DEFAULT 0.00,
  `coupon_code`         VARCHAR(50) DEFAULT NULL,
  `status`              ENUM('pending','success','failed','refunded') DEFAULT 'pending',
  `razorpay_order_id`   VARCHAR(255) DEFAULT NULL,
  `razorpay_payment_id` VARCHAR(255) DEFAULT NULL,
  `razorpay_signature`  VARCHAR(255) DEFAULT NULL,
  `invoice_number`      VARCHAR(100) DEFAULT NULL,
  `created_at`          DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user` (`user_id`),
  INDEX `idx_course` (`course_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_rzp_order` (`razorpay_order_id`)
) ENGINE=InnoDB");
log_msg("✔ 'orders' table checked", 'success');

// 4. Ensure 'coupons' table exists
log_msg("Checking 'coupons' table...");
$conn->query("CREATE TABLE IF NOT EXISTS `coupons` (
  `id`               INT AUTO_INCREMENT PRIMARY KEY,
  `teacher_id`       INT DEFAULT NULL,
  `code`             VARCHAR(50) NOT NULL UNIQUE,
  `discount_percent` INT NOT NULL,
  `expiry_date`      DATE NOT NULL,
  `status`           ENUM('active','inactive') DEFAULT 'active',
  `created_at`       DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_code` (`code`),
  INDEX `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB");
log_msg("✔ 'coupons' table checked", 'success');

// 5. Ensure 'admin' table exists
log_msg("Checking 'admin' table...");
$conn->query("CREATE TABLE IF NOT EXISTS `admin` (
  `id`       INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB");
$check_admin = $conn->query("SELECT id FROM admin LIMIT 1");
if ($check_admin && $check_admin->num_rows == 0) {
    $hashed_admin = password_hash('admin123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO admin (username, password) VALUES ('admin', '$hashed_admin')");
    log_msg("✔ Added default admin user (admin/admin123)", 'success');
}
log_msg("✔ 'admin' table checked", 'success');

// 6. Fix Activity Logs
log_msg("Checking 'activity_logs' table...");
$conn->query("ALTER TABLE `activity_logs` MODIFY COLUMN `user_id` INT DEFAULT NULL");
log_msg("✔ Made 'user_id' nullable in 'activity_logs'", 'success');

// 7. Fix Teachers Table - Settings column
log_msg("Checking 'teachers' table for 'settings' column...");
$check_t_settings = $conn->query("SHOW COLUMNS FROM `teachers` LIKE 'settings'");
if ($check_t_settings && $check_t_settings->num_rows == 0) {
    if ($conn->query("ALTER TABLE `teachers` ADD COLUMN `settings` TEXT DEFAULT NULL AFTER `features`")) {
        log_msg("✔ Added column 'settings' to 'teachers'", 'success');
    } else {
        log_msg("✘ Error adding 'settings' to 'teachers': " . $conn->error, 'error');
    }
}

// 8. Fix Users Table - forum_blocked column
log_msg("Checking 'users' table for 'forum_blocked' column...");
$check_u_forum = $conn->query("SHOW COLUMNS FROM `users` LIKE 'forum_blocked'");
if ($check_u_forum && $check_u_forum->num_rows == 0) {
    if ($conn->query("ALTER TABLE `users` ADD COLUMN `forum_blocked` TINYINT(1) DEFAULT 0 AFTER `status`")) {
        log_msg("✔ Added column 'forum_blocked' to 'users'", 'success');
    } else {
        log_msg("✘ Error adding 'forum_blocked' to 'users': " . $conn->error, 'error');
    }
}

echo "<h3>🎉 All Done! Please delete this file now.</h3>";
?>