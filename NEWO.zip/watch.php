<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$course_id = (int) ($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    header('Location: /mycourses.php');
    exit;
}

// Check purchase
$stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND status = 'success'");
$stmt->bind_param("ii", $_SESSION['user_id'], $course_id);
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    header('Location: /course_detail.php?id=' . $course_id);
    exit;
}
$stmt->close();

// Get course details
$stmt = $conn->prepare("SELECT title FROM courses WHERE id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$course) {
    header('Location: /mycourses.php');
    exit;
}

// Function to fetch chapters and their content recursively
function getFolderTree($conn, $course_id, $parent_id = 0)
{
    $tree = [];
    $stmt = $conn->prepare("SELECT id, title FROM chapters WHERE course_id = ? AND parent_id = ? ORDER BY sort_order, id");
    $stmt->bind_param("ii", $course_id, $parent_id);
    $stmt->execute();
    $chapters = $stmt->get_result();

    while ($ch = $chapters->fetch_assoc()) {
        // Get items in this chapter
        $vids_stmt = $conn->prepare("SELECT id, title, type, url, is_test, start_time, end_time FROM videos WHERE chapter_id = ? ORDER BY sort_order, id");
        $vids_stmt->bind_param("i", $ch['id']);
        $vids_stmt->execute();
        $vids_result = $vids_stmt->get_result();

        $ch['videos'] = [];
        while ($v = $vids_result->fetch_assoc()) {
            // Check for violation
            if ($v['is_test']) {
                $check_v = $conn->prepare("SELECT id FROM exam_violations WHERE user_id = ? AND video_id = ?");
                $check_v->bind_param("ii", $_SESSION['user_id'], $v['id']);
                $check_v->execute();
                $v['has_violation'] = ($check_v->get_result()->num_rows > 0);
                $check_v->close();
            } else {
                $v['has_violation'] = false;
            }
            $ch['videos'][] = $v;
        }
        $vids_stmt->close();

        // Get sub-folders recursively
        $ch['sub_folders'] = getFolderTree($conn, $course_id, $ch['id']);

        $tree[] = $ch;
    }
    $stmt->close();
    return $tree;
}

$all_chapters = getFolderTree($conn, $course_id, 0);

// Total video count for summary
function countVideos($tree)
{
    $count = 0;
    foreach ($tree as $node) {
        $count += count($node['videos']);
        $count += countVideos($node['sub_folders']);
    }
    return $count;
}
$total_vids = countVideos($all_chapters);

// Rendering function (recursive)
function renderStudentFolder($ch, $depth = 0)
{
    $unique_id = "f-" . $ch['id'];
    ?>
    <div class="bg-white border-b border-gray-100 last:border-0" style="margin-left: <?php echo $depth * 10; ?>px">
        <button onclick="toggleSection('<?php echo $unique_id; ?>')"
            class="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50 transition-colors">
            <div class="flex items-center gap-4">
                <div
                    class="w-10 h-10 rounded-full <?php echo $depth == 0 ? 'bg-primary/5 text-primary' : 'bg-gray-100 text-gray-400'; ?> flex items-center justify-center font-bold text-sm">
                    <?php if ($depth == 0): ?>
                        <i class="fas fa-folder"></i>
                    <?php else: ?>
                        <i class="fas fa-folder-open text-xs"></i>
                    <?php endif; ?>
                </div>
                <div>
                    <h3 class="font-bold text-gray-900 <?php echo $depth == 0 ? 'text-base' : 'text-sm'; ?>">
                        <?php echo clean($ch['title']); ?>
                    </h3>
                    <p class="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">
                        <?php echo count($ch['videos']); ?> Videos | <?php echo count($ch['sub_folders']); ?> Folders
                    </p>
                </div>
            </div>
            <i class="fas fa-chevron-down text-gray-300 transition-transform" id="arrow-<?php echo $unique_id; ?>"></i>
        </button>

        <div id="section-<?php echo $unique_id; ?>" class="hidden bg-gray-50/30">
            <!-- Render Sub-folders -->
            <?php foreach ($ch['sub_folders'] as $sub): ?>
                <?php renderStudentFolder($sub, $depth + 1); ?>
            <?php endforeach; ?>

            <!-- Render Videos -->
            <div class="divide-y divide-gray-100">
                <?php foreach ($ch['videos'] as $v): ?>
                    <?php
                    $now = time();
                    $start = strtotime($v['start_time']);
                    $end = strtotime($v['end_time']);
                    $is_live = ($now >= $start && $now <= $end);
                    $is_past = ($now > $end);
                    $is_future = ($now < $start);

                    $can_play = true;
                    if ($v['is_test'] && (!$is_live || $is_past) && !$v['has_violation']) {
                        if ($is_past || $is_future)
                            $can_play = false;
                    }

                    $tag = $can_play ? 'a' : 'div';
                    $href = $can_play ? 'href="/play.php?video_id=' . $v['id'] . '"' : '';
                    ?>
                    <<?php echo $tag; ?>         <?php echo $href; ?>
                        class="flex items-center gap-4 px-8 py-4
                        <?php echo $can_play ? 'hover:bg-white group cursor-pointer' : 'opacity-60 cursor-not-allowed'; ?>
                        border-b border-gray-100 last:border-0 transition-all"
                        style="padding-left: <?php echo ($depth + 1) * 20 + 20; ?>px">
                        <div
                            class="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center <?php echo $can_play ? 'group-hover:bg-primary group-hover:text-white' : ''; ?> transition-all text-gray-400 border border-gray-100">
                            <?php if ($v['is_test']): ?>
                                <i
                                    class="fas fa-file-signature <?php echo $is_live ? 'text-red-500' : 'text-gray-400'; ?> text-sm"></i>
                            <?php else: ?>
                                <i
                                    class="fas fa-play-circle text-primary opacity-30 group-hover:opacity-100 transition-opacity text-sm"></i>
                            <?php endif; ?>
                        </div>
                        <div class="flex-1">
                            <h4
                                class="text-sm font-bold text-gray-700 <?php echo $can_play ? 'group-hover:text-primary' : ''; ?> transition-colors flex items-center gap-2">
                                <?php echo clean($v['title']); ?>
                                <?php if ($v['is_test']): ?>
                                    <?php if ($v['has_violation']): ?>
                                        <span
                                            class="bg-gray-200 text-gray-500 text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border border-gray-300">Blocked</span>
                                    <?php elseif ($is_past): ?>
                                        <span
                                            class="bg-gray-100 text-gray-400 text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border border-gray-200">Closed</span>
                                    <?php elseif ($is_live): ?>
                                        <span
                                            class="bg-red-100 text-red-600 text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border border-red-200">LIVE
                                            NOW</span>
                                    <?php else: ?>
                                        <span
                                            class="bg-blue-100 text-blue-600 text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest border border-blue-200">Scheduled</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </h4>
                            <?php if ($v['is_test']): ?>
                                <p class="text-[10px] text-gray-400 font-bold mt-0.5">
                                    <i class="fas fa-clock mr-1"></i>
                                    <?php if ($v['has_violation']): ?>
                                        Access Revoked
                                    <?php elseif ($is_live): ?>
                                        Closes at <?php echo date('h:i A', strtotime($v['end_time'])); ?>
                                    <?php else: ?>
                                        Scheduled: <?php echo date('d M, h:i A', strtotime($v['start_time'])); ?>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if ($can_play): ?>
                            <div
                                class="flex items-center gap-2 text-primary font-bold text-[10px] opacity-0 group-hover:opacity-100 transition-all">
                                PLAY <i class="fas fa-play text-[8px]"></i>
                            </div>
                        <?php else: ?>
                            <div class="text-[10px] font-bold text-gray-300">
                                LOCKED <i class="fas fa-lock text-[8px]"></i>
                            </div>
                        <?php endif; ?>
                    </<?php echo $tag; ?>>
                <?php endforeach; ?>
            </div>

            <?php if (empty($ch['videos']) && empty($ch['sub_folders'])): ?>
                <div class="p-8 text-center text-gray-400 text-xs italic">This folder is empty</div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

$page_title = "Curriculum: " . $course['title'];
include 'common/header.php';
?>

<main class="bg-gray-50 min-h-screen pb-12">
    <!-- Course Header -->
    <div class="bg-primary text-white p-10">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-2xl md:text-4xl font-black mb-2 tracking-tight"><?php echo clean($course['title']); ?></h1>
            <p class="text-white/70 text-sm md:text-base font-medium">Browse your curriculum and start learning</p>
        </div>
    </div>

    <!-- Syllabus Container -->
    <div class="max-w-4xl mx-auto p-4 -mt-8">
        <div class="bg-white shadow-2xl border border-gray-200/50 rounded-2xl overflow-hidden">
            <div class="p-6 md:p-8 border-b bg-white flex items-center justify-between">
                <h2 class="font-black text-gray-900 md:text-xl flex items-center gap-3">
                    <i class="fas fa-layer-group text-primary"></i> Course Content
                </h2>
                <div class="flex items-center gap-3">
                    <span class="text-xs font-bold text-gray-400 uppercase tracking-widest">
                        <?php echo $total_vids; ?> Lessons
                    </span>
                </div>
            </div>

            <!-- Live Sessions Section -->
            <?php
            $live_sessions = $conn->query("SELECT * FROM live_sessions WHERE course_id = $course_id AND status != 'ended' ORDER BY status = 'live' DESC, scheduled_at ASC");
            if ($live_sessions->num_rows > 0): ?>
                <div class="p-6 bg-red-50/50 border-b border-red-100">
                    <h3 class="text-xs font-black text-red-600 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <i class="fas fa-satellite-dish animate-pulse"></i> Active & Upcoming Live
                    </h3>
                    <div class="space-y-3">
                        <?php while ($ls = $live_sessions->fetch_assoc()): ?>
                            <div
                                class="bg-white rounded-xl p-4 border border-red-100 flex items-center justify-between shadow-sm">
                                <div class="flex items-center gap-4">
                                    <div
                                        class="w-10 h-10 rounded-full flex items-center justify-center <?php echo $ls['status'] === 'live' ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-100 text-gray-400'; ?>">
                                        <i class="fas fa-play"></i>
                                    </div>
                                    <div>
                                        <h4 class="font-bold text-gray-900 text-sm"><?php echo clean($ls['title']); ?></h4>
                                        <p
                                            class="text-[10px] font-black uppercase tracking-widest <?php echo $ls['status'] === 'live' ? 'text-red-500' : 'text-gray-400'; ?>">
                                            <?php echo $ls['status'] === 'live' ? 'LIVE NOW' : 'Starts: ' . date('d M, h:i A', strtotime($ls['scheduled_at'])); ?>
                                        </p>
                                    </div>
                                </div>
                                <a href="/play.php?live_id=<?php echo $ls['id']; ?>"
                                    class="bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest shadow-lg shadow-red-600/20 hover:-translate-y-0.5 transition-all">
                                    <?php echo $ls['status'] === 'live' ? 'Join Now' : 'Remind Me'; ?>
                                </a>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="divide-y divide-gray-100">
                <?php if (empty($all_chapters)): ?>
                    <div class="p-20 text-center">
                        <i class="fas fa-folder-open text-6xl text-gray-100 mb-4"></i>
                        <p class="text-gray-400 font-bold">No content available for this course yet.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($all_chapters as $index => $ch): ?>
                        <?php renderStudentFolder($ch); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<script>
    function toggleSection(id) {
        const el = document.getElementById('section-' + id);
        const arrow = document.getElementById('arrow-' + id);
        if (!el) return;

        const isHidden = el.classList.contains('hidden');
        if (isHidden) {
            el.classList.remove('hidden');
            arrow.classList.add('rotate-180');
        } else {
            el.classList.add('hidden');
            arrow.classList.remove('rotate-180');
        }
    }

    // Auto-expand first root folder
    <?php if (!empty($all_chapters)): ?>
        toggleSection('f-<?php echo $all_chapters[0]['id']; ?>');
    <?php endif; ?>
</script>

<?php include 'common/bottom.php'; ?>