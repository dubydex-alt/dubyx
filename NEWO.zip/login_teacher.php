<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (isset($_SESSION['teacher_id'])) {
    header('Location: /teacher/index.php');
    exit;
}

// AJAX Handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    if ($_POST['action'] === 'login') {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            echo json_encode(['success' => false, 'message' => 'All fields are required.']);
            exit;
        }

        $stmt = $conn->prepare("SELECT id, name, email, password, status, features, logo FROM teachers WHERE (email = ? OR teacher_id_str = ?) AND status = 'active'");
        $stmt->bind_param("ss", $email, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['teacher_id'] = $user['id'];
                $_SESSION['teacher_name'] = $user['name'];
                $_SESSION['teacher_email'] = $user['email'];
                $_SESSION['teacher_features'] = json_decode($user['features'] ?? '[]', true);
                $_SESSION['teacher_logo'] = $user['logo'];

                echo json_encode(['success' => true, 'message' => 'Login successful!']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid credentials.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Account not found or inactive.']);
        }
        $stmt->close();
        exit;
    }
}

$page_title = 'Teacher Login';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login -
        <?php echo clean($settings['app_name']); ?>
    </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { primary: '#0284C7', 'primary-dark': '#0369A1' } } } }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">

    <div class="w-full max-w-sm">
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-primary text-white flex items-center justify-center mx-auto mb-3">
                <i class="fas fa-chalkboard-teacher text-3xl"></i>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">
                <?php echo clean($settings['app_name']); ?>
            </h1>
            <p class="text-gray-500 text-sm mt-1">Teacher Panel Access</p>
        </div>

        <div class="bg-white shadow-lg p-8">
            <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

            <form id="form-login" class="space-y-4" onsubmit="return handleLogin(event)">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email or Teacher ID</label>
                    <input type="text" name="email" required
                        class="w-full px-4 py-3 border border-gray-300 focus:outline-none focus:border-primary"
                        placeholder="Enter your email or ID">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <input type="password" name="password" required
                        class="w-full px-4 py-3 border border-gray-300 focus:outline-none focus:border-primary"
                        placeholder="Enter your password">
                </div>
                <button type="submit" id="btn-login"
                    class="w-full bg-primary text-white py-3 font-semibold hover:bg-primary-dark transition duration-200">
                    Login as Teacher
                </button>
            </form>

            <div class="mt-6 text-center text-sm">
                <a href="/login.php" class="text-gray-500 hover:text-primary">Are you a student? Login here</a>
            </div>
        </div>
    </div>

    <script>
        const csrfToken = '<?php echo csrf_token(); ?>';

        function showAlert(msg, type) {
            const el = document.getElementById('alert');
            el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
            el.textContent = msg;
            el.classList.remove('hidden');
        }

        function handleLogin(e) {
            e.preventDefault();
            const btn = document.getElementById('btn-login');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Logging in...';
            btn.disabled = true;

            const data = new FormData(document.getElementById('form-login'));
            data.append('action', 'login');
            data.append('csrf_token', csrfToken);

            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/login_teacher.php', true);
            xhr.onload = function () {
                btn.innerHTML = 'Login as Teacher';
                btn.disabled = false;
                try {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success) {
                        showAlert(res.message, 'success');
                        setTimeout(() => window.location.href = '/teacher/index.php', 500);
                    } else {
                        showAlert(res.message, 'error');
                    }
                } catch (e) { showAlert('Something went wrong.', 'error'); }
            };
            xhr.send(data);
            return false;
        }
    </script>
</body>

</html>