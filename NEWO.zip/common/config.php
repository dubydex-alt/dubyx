<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Remember-Me Auto-Login ────────────────────────────────
// If not yet logged in but a valid remember_token cookie exists,
// restore the session automatically ("always logged in").
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_token'])) {
    // We connect temporarily here (full $conn is set below) – so just
    // re-use the credentials defined later. Load them inline:
    $_tmp_conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');
    if (!$_tmp_conn->connect_error) {
        $_tmp_conn->set_charset('utf8mb4');
        $rtoken = $_COOKIE['remember_token'];
        $stmt_r = $_tmp_conn->prepare(
            "SELECT id, name, email, teacher_id FROM users
             WHERE remember_token = ? AND deleted_at IS NULL AND status = 'active'
             LIMIT 1"
        );
        $stmt_r->bind_param('s', $rtoken);
        $stmt_r->execute();
        $row_r = $stmt_r->get_result()->fetch_assoc();
        $stmt_r->close();

        if ($row_r) {
            // Regenerate a fresh session token and persist it
            $new_st = bin2hex(random_bytes(32));
            $upd_r = $_tmp_conn->prepare("UPDATE users SET session_token = ? WHERE id = ?");
            $upd_r->bind_param('si', $new_st, $row_r['id']);
            $upd_r->execute();
            $upd_r->close();

            $_SESSION['user_id'] = $row_r['id'];
            $_SESSION['user_name'] = $row_r['name'];
            $_SESSION['user_email'] = $row_r['email'];
            $_SESSION['student_teacher_id'] = $row_r['teacher_id'];
            $_SESSION['session_token'] = $new_st;

            // Refresh the cookie lifetime (rolling 30-day window)
            setcookie('remember_token', $rtoken, time() + 60 * 60 * 24 * 30, '/', '', false, true);
        }
        $_tmp_conn->close();
    }
}

// Set Timezone to IST
date_default_timezone_set('Asia/Kolkata');

// ═══════════════════════════════════════════════════
// DATABASE CREDENTIALS — Single Source of Truth
// Change values here; every page reads from this file.
// ═══════════════════════════════════════════════════
define('DB_HOST', 'sql301.infinityfree.com');
define('DB_USER', 'if0_41158662');
define('DB_PASS', 'D2UQHHFoBdbafCp');
define('DB_NAME', 'if0_41158662_backendxtra9');

// Connect to MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    if (defined('IS_API') && IS_API) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Database connection failed. Please contact support.']);
        exit;
    }
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// Single Session Login Policy
if (isset($_SESSION['user_id']) && isset($_SESSION['session_token'])) {
    $uid = $_SESSION['user_id'];
    $stoken = $_SESSION['session_token'];
    $stmt_sess = $conn->prepare("SELECT session_token FROM users WHERE id = ?");
    $stmt_sess->bind_param("i", $uid);
    $stmt_sess->execute();
    $res_sess = $stmt_sess->get_result()->fetch_assoc();
    $stmt_sess->close();

    if ($res_sess && $res_sess['session_token'] !== $stoken) {
        // Token mismatch - logout this older session
        session_destroy();

        // Detect if this is an AJAX/API request
        $is_api = (defined('IS_API') && IS_API) ||
            (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') ||
            (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false);

        if ($is_api) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Session expired or logged in elsewhere. Please refresh.']);
            exit;
        }

        header('Location: /login.php?error=session_expired');
        exit;
    }
}

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function csrf_token()
{
    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf($token)
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Get App Settings
function get_settings($conn)
{
    $result = $conn->query("SELECT * FROM settings LIMIT 1");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return [
        'app_name' => 'SkillzUp',
        'razorpay_key' => '',
        'razorpay_secret' => '',
        'support_email' => '',
        'support_phone' => ''
    ];
}

$settings = get_settings($conn);

// Login Rate Limiting
function check_login_rate($conn, $email)
{
    $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM login_attempts WHERE email = ? AND attempted_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['cnt'] < 5;
}

function record_login_attempt($conn, $email)
{
    $stmt = $conn->prepare("INSERT INTO login_attempts (email, attempted_at) VALUES (?, NOW())");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
}

// Image Compression
function compress_image($source, $destination, $quality = 75)
{
    if (!extension_loaded('gd')) {
        return move_uploaded_file($source, $destination);
    }

    $info = getimagesize($source);
    if ($info === false)
        return false;

    switch ($info['mime']) {
        case 'image/jpeg':
            $image = @imagecreatefromjpeg($source);
            if ($image) {
                imagejpeg($image, $destination, $quality);
                imagedestroy($image);
            }
            break;
        case 'image/png':
            $image = @imagecreatefrompng($source);
            if ($image) {
                imagepng($image, $destination, 8);
                imagedestroy($image);
            }
            break;
        case 'image/webp':
            $image = @imagecreatefromwebp($source);
            if ($image) {
                imagewebp($image, $destination, $quality);
                imagedestroy($image);
            }
            break;
        default:
            return move_uploaded_file($source, $destination);
    }
    return true;
}

// Soft Delete Helper
function soft_delete($conn, $table, $id)
{
    $stmt = $conn->prepare("UPDATE $table SET deleted_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

// Activity Log
function log_activity($conn, $user_id, $action)
{
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $user_id, $action);
    $stmt->execute();
    $stmt->close();
}

// Clean Input
function clean($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

require_once __DIR__ . '/notifications_helper.php';
?>