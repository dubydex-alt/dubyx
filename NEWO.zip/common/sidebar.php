<nav id="sidebar"
    class="fixed top-0 left-0 h-full w-72 bg-white z-50 shadow-xl transform -translate-x-full transition-transform duration-300">
    <div class="bg-primary text-white p-6">
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="w-16 h-16 bg-white/20 flex items-center justify-center mb-3">
                <i class="fas fa-user text-3xl"></i>
            </div>
            <p class="font-bold text-lg"><?php echo clean($_SESSION['user_name'] ?? 'User'); ?></p>
            <p class="text-sm text-white/80"><?php echo clean($_SESSION['user_email'] ?? ''); ?></p>
        <?php else: ?>
            <div class="w-16 h-16 bg-white/20 flex items-center justify-center mb-3">
                <i class="fas fa-user text-3xl"></i>
            </div>
            <p class="font-bold text-lg">Guest</p>
            <a href="/login.php" class="text-sm text-white/80 underline">Login / Signup</a>
        <?php endif; ?>
    </div>
    <div class="py-2">
        <a href="/index.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-home w-6 text-center text-primary"></i>
            <span>Home</span>
        </a>
        <a href="/course.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-book w-6 text-center text-primary"></i>
            <span>Courses</span>
        </a>
        <a href="/forum.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-users w-6 text-center text-primary"></i>
            <span>Community Chat</span>
        </a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="/mycourses.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-graduation-cap w-6 text-center text-primary"></i>
                <span>My Courses</span>
            </a>

            <?php if (isset($_SESSION['teacher_id'])): ?>
                <div class="px-6 py-4">
                    <p class="text-white/40 text-[10px] font-black uppercase tracking-widest mb-2">Teacher Resources</p>
                    <a href="/teacher/courses.php"
                        class="flex items-center gap-4 py-2 text-white hover:text-white/80 transition-colors">
                        <i class="fas fa-chalkboard-teacher w-6 text-center text-xs"></i>
                        <span class="font-medium text-sm">Manage Courses</span>
                    </a>
                </div>
            <?php endif; ?>
            <a href="/notifications.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-bell w-6 text-center text-primary"></i>
                <span>Notifications</span>
            </a>
            <a href="/profile.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-user w-6 text-center text-primary"></i>
                <span>Profile</span>
            </a>
        <?php endif; ?>
        <a href="/help.php" class="flex items-center gap-4 px-6 py-3 text-gray-700 hover:bg-gray-100">
            <i class="fas fa-question-circle w-6 text-center text-primary"></i>
            <span>Help & Support</span>
        </a>
        <div class="border-t my-2"></div>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="/logout.php" class="flex items-center gap-4 px-6 py-3 text-red-600 hover:bg-red-50">
                <i class="fas fa-sign-out-alt w-6 text-center"></i>
                <span>Logout</span>
            </a>
        <?php else: ?>
            <a href="/login.php" class="flex items-center gap-4 px-6 py-3 text-primary hover:bg-blue-50">
                <i class="fas fa-sign-in-alt w-6 text-center"></i>
                <span>Login / Signup</span>
            </a>
        <?php endif; ?>
    </div>
</nav>