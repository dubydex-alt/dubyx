<?php
require_once __DIR__ . '/config.php';

// Get all tables
$r = $conn->query("SHOW TABLES");
$all = [];
while ($row = $r->fetch_row()) {
    $all[] = $row[0];
}
echo "ALL TABLES: " . implode(', ', $all) . PHP_EOL . PHP_EOL;

$tables = ['coupons', 'courses'];
foreach ($tables as $table) {
    $create = $conn->query("SHOW CREATE TABLE `$table`");
    if ($create) {
        $cr = $create->fetch_row();
        echo "=== TABLE: $table ===" . PHP_EOL;
        echo $cr[1] . PHP_EOL . PHP_EOL;
    }
}

// Check for activity_log
$r2 = $conn->query("SHOW TABLES LIKE 'activity%'");
echo "activity tables: " . $r2->num_rows . PHP_EOL;
while ($row = $r2->fetch_row()) {
    echo "  - " . $row[0] . PHP_EOL;
}

// Check community tables
$r3 = $conn->query("SHOW TABLES LIKE 'community%'");
echo "community tables: " . $r3->num_rows . PHP_EOL;
while ($row = $r3->fetch_row()) {
    echo "  - " . $row[0] . PHP_EOL;
}
