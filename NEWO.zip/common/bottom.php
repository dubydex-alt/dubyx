<!-- Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
    <div class="flex items-center justify-around h-16">
        <a href="/index.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <i class="fas fa-home text-xl"></i>
            <span>Home</span>
        </a>
        <a href="/course.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'course.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <i class="fas fa-book text-xl"></i>
            <span>Courses</span>
        </a>
        <a href="/live.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'live.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <div class="relative">
                <i class="fas fa-satellite-dish text-xl"></i>
                <span class="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
            </div>
            <span>Live</span>
        </a>
        <a href="/mycourses.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'mycourses.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <i class="fas fa-graduation-cap text-xl"></i>
            <span>My Courses</span>
        </a>
        <a href="/help.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'help.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <i class="fas fa-question-circle text-xl"></i>
            <span>Help</span>
        </a>
        <a href="/profile.php"
            class="flex flex-col items-center justify-center gap-1 text-xs <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'text-primary' : 'text-gray-500'; ?>">
            <i class="fas fa-user text-xl"></i>
            <span>Profile</span>
        </a>
    </div>
</nav>

<!-- Service Worker Registration -->
<script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/service-worker.js').catch(function () { });
    }

    // Global Loader Control
    window.addEventListener('load', function () {
        const loader = document.getElementById('global-loader');
        if (loader) {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.visibility = 'hidden';
            }, 300);
        }
    });

    // Show loader on link clicks
    document.addEventListener('click', function (e) {
        const link = e.target.closest('a');
        if (link && link.href && !link.href.includes('#') && !link.target && !link.href.startsWith('javascript:')) {
            const loader = document.getElementById('global-loader');
            if (loader) {
                loader.style.visibility = 'visible';
                loader.style.opacity = '1';
            }
        }
    });

    // Show loader on form submissions
    document.addEventListener('submit', function (e) {
        if (e.target.hasAttribute('data-no-loader')) return;
        const loader = document.getElementById('global-loader');
        if (loader) {
            loader.style.visibility = 'visible';
            loader.style.opacity = '1';
        }
    });
</script>
</body>

</html>