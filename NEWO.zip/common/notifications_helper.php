<?php
/**
 * Shared Notification Helper
 */

/**
 * Send OneSignal Push Notification
 */
function send_onesignal_notification($title, $message, $player_ids)
{
    global $settings, $conn;

    // Fetch settings if not already provided (needed for standalone or teacher context)
    if (!isset($settings['onesignal_app_id'])) {
        $res = $conn->query("SELECT onesignal_app_id, onesignal_rest_key FROM settings LIMIT 1");
        $settings = array_merge($settings ?? [], $res->fetch_assoc() ?: []);
    }

    if (empty($settings['onesignal_app_id']) || empty($settings['onesignal_rest_key']) || empty($player_ids)) {
        return false;
    }

    $content = array("en" => $message);
    $headings = array("en" => $title);
    $fields = array(
        'app_id' => $settings['onesignal_app_id'],
        'include_player_ids' => is_array($player_ids) ? $player_ids : array($player_ids),
        'contents' => $content,
        'headings' => $headings
    );

    $fields = json_encode($fields);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json; charset=utf-8',
        'Authorization: Basic ' . $settings['onesignal_rest_key']
    ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

/**
 * Universal Notification Sender (DB + Push)
 */
function send_notification($conn, $user_id, $title, $message, $send_push = true)
{
    // 1. Save to Database
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $title, $message);
    $result = $stmt->execute();
    $stmt->close();

    // 2. Send Push Notification if Player ID exists
    if ($result && $send_push) {
        $res = $conn->query("SELECT onesignal_id FROM users WHERE id = $user_id");
        $user = $res->fetch_assoc();
        if ($user && $user['onesignal_id']) {
            send_onesignal_notification($title, $message, $user['onesignal_id']);
        }
    }

    return $result;
}
?>