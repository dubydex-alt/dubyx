<?php if (!isset($conn))
    require_once __DIR__ . '/config.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0284C7">
    <meta name="description"
        content="<?php echo isset($page_description) ? clean($page_description) : 'Learn new skills with ' . clean($settings['app_name']); ?>">
    <meta property="og:title"
        content="<?php echo isset($page_title) ? clean($page_title) : clean($settings['app_name']); ?>">
    <meta property="og:description"
        content="<?php echo isset($page_description) ? clean($page_description) : 'Digital course platform'; ?>">
    <meta property="og:type" content="website">
    <title>
        <?php echo isset($page_title) ? clean($page_title) . ' - ' . clean($settings['app_name']) : clean($settings['app_name']); ?>
    </title>
    <link rel="manifest" href="/manifest.json">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#0284C7',
                        'primary-dark': '#0369A1',
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * {
            -webkit-tap-highlight-color: transparent;
        }

        body {
            -webkit-user-select: none;
            user-select: none;
            overscroll-behavior: none;
        }

        input,
        textarea {
            -webkit-user-select: text;
            user-select: text;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        body {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .no-scroll {
            overflow: hidden;
        }

        .aspect-video {
            aspect-ratio: 16/9;
        }

        .hide-scrollbar::-webkit-scrollbar {
            display: none;
        }

        .hide-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        /* Global Loader Styles */
        #global-loader {
            transition: opacity 0.3s ease-in-out, visibility 0.3s;
        }

        .loader-spinner {
            width: 40px;
            height: 40px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes blink {
            0% {
                opacity: 1;
                transform: scale(1);
            }

            50% {
                opacity: 0.5;
                transform: scale(1.1);
            }

            100% {
                opacity: 1;
                transform: scale(1);
            }
        }

        .animate-blink {
            animation: blink 1s infinite;
        }
    </style>
</head>

<body class="bg-gray-50 text-gray-900 min-h-screen pb-20">

    <!-- Global Loader Overlay -->
    <div id="global-loader" class="fixed inset-0 z-[9999] bg-primary flex items-center justify-center">
        <div class="flex flex-col items-center gap-4">
            <div class="loader-spinner"></div>
            <p class="text-white font-bold tracking-widest text-xs uppercase animate-pulse">Loading...</p>
        </div>
    </div>

    <!-- Header -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-primary text-white">
        <div class="flex items-center justify-between px-4 h-14">
            <button onclick="toggleSidebar()" class="w-10 h-10 flex items-center justify-center">
                <i class="fas fa-bars text-lg"></i>
            </button>
            <?php
            $display_logo = null;
            if (isset($_SESSION['student_teacher_id']) && $_SESSION['student_teacher_id'] > 0) {
                $t_id = (int) $_SESSION['student_teacher_id'];
                $t_query = $conn->query("SELECT logo FROM teachers WHERE id = $t_id");
                if ($t_query && $t_query->num_rows > 0) {
                    $t_data = $t_query->fetch_assoc();
                    if ($t_data['logo'])
                        $display_logo = $t_data['logo'];
                }
            }
            ?>
            <?php if ($display_logo): ?>
                <img src="/<?php echo $display_logo; ?>" class="h-10 w-10 object-contain">
            <?php else: ?>
                <h1 class="text-lg font-bold tracking-wide"><?php echo clean($settings['app_name']); ?></h1>
            <?php endif; ?>
            <div class="flex items-center gap-2">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/notifications.php" class="w-10 h-10 flex items-center justify-center relative">
                        <i class="fas fa-bell text-lg" id="bell-icon"></i>
                        <span id="notif-badge"
                            class="hidden absolute top-1 right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center font-bold rounded-full"
                            style="font-size:10px;"></span>
                    </a>
                <?php endif; ?>
                <a href="<?php echo isset($_SESSION['user_id']) ? '/profile.php' : '/login.php'; ?>"
                    class="w-10 h-10 flex items-center justify-center">
                    <i class="fas fa-user-circle text-lg"></i>
                </a>
            </div>
        </div>
    </header>

    <div class="h-14"></div>

    <!-- Sidebar Overlay -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-50 hidden" onclick="toggleSidebar()"></div>

    <!-- Sidebar -->
    <?php include __DIR__ . '/sidebar.php'; ?>

    <script>
        // Disable right-click, F12, Ctrl+S, Ctrl+U
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('keydown', function (e) {
            if (e.key === 'F12' || (e.ctrlKey && (e.key === 's' || e.key === 'u' || e.key === 'S' || e.key === 'U'))) {
                e.preventDefault();
            }
        });

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
            document.body.classList.toggle('no-scroll');
        }

        // Notification badge check
        <?php if (isset($_SESSION['user_id'])): ?>
                (function checkNotifs() {
                    const xhr = new XMLHttpRequest();
                    xhr.open('GET', '/ajax/notifications_count.php', true);
                    xhr.onload = function () {
                        if (xhr.status === 200) {
                            const data = JSON.parse(xhr.responseText);
                            const badge = document.getElementById('notif-badge');
                            const bell = document.getElementById('bell-icon');
                            if (data.count > 0) {
                                badge.textContent = data.count > 9 ? '9+' : data.count;
                                badge.classList.remove('hidden');
                                if (bell) bell.classList.add('animate-blink');
                            } else {
                                badge.classList.add('hidden');
                                if (bell) bell.classList.remove('animate-blink');
                            }
                        }
                    };
                    xhr.send();
                    setTimeout(checkNotifs, 30000);
                })();

            // Capture OneSignal Player ID from URL
            (function capturePlayerId() {
                const urlParams = new URLSearchParams(window.location.search);
                const playerId = urlParams.get('player_id');
                if (playerId) {
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', '/ajax/update_onesignal_id.php', true);
                    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                    xhr.onload = function () {
                        // Optionally remove parameter from URL without refresh
                        const url = new URL(window.location);
                        url.searchParams.delete('player_id');
                        window.history.replaceState({}, '', url);
                    };
                    xhr.send('player_id=' + encodeURIComponent(playerId));
                }
            })();
        <?php endif; ?>
    </script>