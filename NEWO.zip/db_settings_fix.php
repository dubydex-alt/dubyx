<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

// Check if community_url exists in settings table
$res = $conn->query("SHOW COLUMNS FROM settings LIKE 'community_url'");
if ($res && $res->num_rows === 0) {
    if ($conn->query("ALTER TABLE settings ADD COLUMN community_url VARCHAR(255) DEFAULT '' AFTER support_phone")) {
        echo "Successfully added community_url column to settings table.\n";
    } else {
        echo "Error: " . $conn->error . "\n";
    }
} else {
    echo "community_url column already exists.\n";
}
?>