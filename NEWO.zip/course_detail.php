<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: /course.php');
    exit;
}

$stmt = $conn->prepare("SELECT c.*, cat.name as category_name FROM courses c LEFT JOIN categories cat ON c.category_id = cat.id WHERE c.id = ? AND c.status = 'active' AND c.deleted_at IS NULL");
$stmt->bind_param("i", $id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$course) {
    header('Location: /course.php');
    exit;
}

$page_title = $course['title'];
$page_description = $course['meta_description'] ?: substr(strip_tags($course['description']), 0, 160);
$discount = $course['mrp'] > 0 ? round((($course['mrp'] - $course['price']) / $course['mrp']) * 100) : 0;

// Check if purchased
$purchased = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND status = 'success'");
    $stmt->bind_param("ii", $_SESSION['user_id'], $id);
    $stmt->execute();
    $purchased = $stmt->get_result()->num_rows > 0;
    $stmt->close();
}

// Get chapters & video count
$chapters = $conn->query("SELECT ch.id, ch.title, (SELECT COUNT(*) FROM videos v WHERE v.chapter_id = ch.id) as video_count FROM chapters ch WHERE ch.course_id = $id ORDER BY ch.sort_order, ch.id");

include 'common/header.php';
?>

<main class="pb-24">
    <!-- Course Image -->
    <div class="relative">
        <img src="/uploads/courses/<?php echo clean($course['image']); ?>" alt="<?php echo clean($course['title']); ?>"
            class="w-full aspect-video object-cover">
        <?php if ($discount > 0): ?>
            <span class="absolute top-3 left-3 bg-red-500 text-white text-sm px-3 py-1 font-bold"><?php echo $discount; ?>%
                OFF</span>
        <?php endif; ?>
    </div>

    <!-- Course Info -->
    <div class="p-4">
        <?php if ($course['category_name']): ?>
            <span
                class="inline-block bg-primary/10 text-primary text-xs font-semibold px-3 py-1 mb-3"><?php echo clean($course['category_name']); ?></span>
        <?php endif; ?>

        <h1 class="text-xl font-bold text-gray-900 mb-3"><?php echo clean($course['title']); ?></h1>

        <div class="flex items-center gap-3 mb-4">
            <span class="text-2xl font-bold text-primary">&#8377;<?php echo number_format($course['price']); ?></span>
            <?php if ($course['mrp'] > $course['price']): ?>
                <span class="text-lg text-gray-400 line-through">&#8377;<?php echo number_format($course['mrp']); ?></span>
                <span class="bg-green-100 text-green-700 text-xs font-bold px-2 py-1">Save
                    &#8377;<?php echo number_format($course['mrp'] - $course['price']); ?></span>
            <?php endif; ?>
        </div>

        <!-- Description -->
        <div class="mb-6">
            <h2 class="font-bold text-gray-900 mb-2">About this Course</h2>
            <div class="text-gray-600 text-sm leading-relaxed"><?php echo nl2br(clean($course['description'])); ?></div>
        </div>

        <!-- Course Content -->
        <?php if ($chapters && $chapters->num_rows > 0): ?>
            <div class="mb-6">
                <h2 class="font-bold text-gray-900 mb-3">Course Content</h2>
                <div class="space-y-2">
                    <?php while ($ch = $chapters->fetch_assoc()): ?>
                        <div class="bg-gray-50 p-4 flex items-center justify-between">
                            <div class="flex items-center gap-3">
                                <i class="fas fa-folder text-primary"></i>
                                <span class="text-sm font-medium text-gray-900"><?php echo clean($ch['title']); ?></span>
                            </div>
                            <span class="text-xs text-gray-500"><?php echo $ch['video_count']; ?>
                                video<?php echo $ch['video_count'] != 1 ? 's' : ''; ?></span>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Sticky Buy/Start Button -->
    <div class="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-200 p-4 z-30">
        <div class="flex items-center gap-4 max-w-lg mx-auto">
            <div class="flex-1">
                <span
                    class="text-xl font-bold text-primary">&#8377;<?php echo number_format($course['price']); ?></span>
                <?php if ($course['mrp'] > $course['price']): ?>
                    <span
                        class="text-sm text-gray-400 line-through ml-2">&#8377;<?php echo number_format($course['mrp']); ?></span>
                <?php endif; ?>
            </div>
            <?php if ($purchased): ?>
                <a href="/watch.php?course_id=<?php echo $course['id']; ?>"
                    class="bg-green-600 text-white px-8 py-3 font-semibold text-center">
                    <i class="fas fa-play mr-2"></i>Start Course
                </a>
            <?php else: ?>
                <a href="<?php echo isset($_SESSION['user_id']) ? '/buy.php?course_id=' . $course['id'] : '/login.php'; ?>"
                    class="bg-primary text-white px-8 py-3 font-semibold text-center">
                    <i class="fas fa-shopping-cart mr-2"></i>Buy Now
                </a>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include 'common/bottom.php'; ?>