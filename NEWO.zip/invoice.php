<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

/**
 * Invoice Generator (Pure PHP - No Composer)
 * Generates a clean HTML invoice that can be printed/saved as PDF
 */
require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$order_id = (int) ($_GET['order_id'] ?? 0);
if ($order_id <= 0) {
    header('Location: /mycourses.php');
    exit;
}

// Get order with course and user details
$stmt = $conn->prepare("
    SELECT o.*, c.title as course_title, c.description as course_desc, u.name as user_name, u.email as user_email, u.phone as user_phone
    FROM orders o 
    JOIN courses c ON o.course_id = c.id 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ? AND o.user_id = ? AND o.status = 'success'
");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header('Location: /mycourses.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?php echo htmlspecialchars($order['invoice_number']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }

            body {
                margin: 0;
                padding: 0;
            }

            .invoice {
                box-shadow: none !important;
                max-width: 100% !important;
            }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen p-4">
    <!-- Actions -->
    <div class="max-w-lg mx-auto mb-4 flex gap-3 no-print">
        <button onclick="window.print()" class="flex-1 bg-sky-600 text-white py-3 font-semibold text-sm">
            <i class="fas fa-print mr-2"></i>Print / Save PDF
        </button>
        <a href="/mycourses.php" class="flex-1 bg-gray-800 text-white py-3 font-semibold text-sm text-center">
            <i class="fas fa-arrow-left mr-2"></i>Back
        </a>
    </div>

    <!-- Invoice -->
    <div class="invoice max-w-lg mx-auto bg-white shadow-lg">
        <!-- Header -->
        <div class="bg-sky-600 text-white p-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-xl font-bold"><?php echo htmlspecialchars($settings['app_name']); ?></h1>
                    <p class="text-sm text-white/80 mt-1">Digital Course Platform</p>
                </div>
                <div class="text-right">
                    <p class="text-2xl font-bold">INVOICE</p>
                    <p class="text-sm text-white/80"><?php echo htmlspecialchars($order['invoice_number']); ?></p>
                </div>
            </div>
        </div>

        <div class="p-6">
            <!-- Dates & Info -->
            <div class="grid grid-cols-2 gap-4 mb-6">
                <div>
                    <p class="text-xs text-gray-500 font-medium mb-1">BILLED TO</p>
                    <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($order['user_name']); ?></p>
                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($order['user_email']); ?></p>
                    <?php if ($order['user_phone']): ?>
                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($order['user_phone']); ?></p>
                    <?php endif; ?>
                </div>
                <div class="text-right">
                    <p class="text-xs text-gray-500 font-medium mb-1">DATE</p>
                    <p class="text-sm text-gray-900"><?php echo date('d M Y', strtotime($order['created_at'])); ?></p>
                    <p class="text-xs text-gray-500 font-medium mt-3 mb-1">PAYMENT ID</p>
                    <p class="text-sm text-gray-900 break-all">
                        <?php echo htmlspecialchars($order['razorpay_payment_id']); ?></p>
                </div>
            </div>

            <!-- Line Items -->
            <table class="w-full mb-6">
                <thead>
                    <tr class="border-b-2 border-gray-200">
                        <th class="text-left text-xs font-semibold text-gray-500 py-3">ITEM</th>
                        <th class="text-right text-xs font-semibold text-gray-500 py-3">AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-b border-gray-100">
                        <td class="py-4">
                            <p class="font-medium text-gray-900"><?php echo htmlspecialchars($order['course_title']); ?>
                            </p>
                            <p class="text-xs text-gray-500 mt-1">Digital Course - Lifetime Access</p>
                        </td>
                        <td class="py-4 text-right">
                            <p class="font-medium text-gray-900">
                                &#8377;<?php echo number_format($order['amount'] + $order['discount_amount'], 2); ?></p>
                        </td>
                    </tr>
                    <?php if ($order['discount_amount'] > 0): ?>
                        <tr class="border-b border-gray-100">
                            <td class="py-3">
                                <p class="text-sm text-green-600">Coupon Discount
                                    (<?php echo htmlspecialchars($order['coupon_code']); ?>)</p>
                            </td>
                            <td class="py-3 text-right">
                                <p class="text-sm text-green-600">
                                    -&#8377;<?php echo number_format($order['discount_amount'], 2); ?></p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr class="border-t-2 border-gray-300">
                        <td class="py-4">
                            <p class="font-bold text-gray-900 text-lg">Total Paid</p>
                        </td>
                        <td class="py-4 text-right">
                            <p class="font-bold text-sky-600 text-lg">
                                &#8377;<?php echo number_format($order['amount'], 2); ?></p>
                        </td>
                    </tr>
                </tfoot>
            </table>

            <!-- Payment Status -->
            <div class="bg-green-50 border border-green-200 p-3 text-center mb-6">
                <p class="text-green-700 font-semibold text-sm">
                    <i class="fas fa-check-circle mr-1"></i>Payment Successful
                </p>
            </div>

            <!-- Footer -->
            <div class="text-center text-xs text-gray-400 border-t pt-4">
                <p>This is a computer-generated invoice and does not require a signature.</p>
                <?php if ($settings['support_email']): ?>
                    <p class="mt-1">For queries, contact: <?php echo htmlspecialchars($settings['support_email']); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>