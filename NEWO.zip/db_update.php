<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

// Add 'type' column to videos table
$sql = "ALTER TABLE videos ADD COLUMN type ENUM('youtube', 'gdrive') DEFAULT 'youtube' AFTER title";
if ($conn->query($sql)) {
    echo "Successfully added 'type' column to videos table.\n";
} else {
    echo "Error adding 'type' column: " . $conn->error . "\n";
}

// Rename 'filename' column to 'url' to be more descriptive for links
$sql = "ALTER TABLE videos CHANGE filename url VARCHAR(255)";
if ($conn->query($sql)) {
    echo "Successfully renamed 'filename' to 'url'.\n";
} else {
    echo "Error renaming column: " . $conn->error . "\n";
}
?>