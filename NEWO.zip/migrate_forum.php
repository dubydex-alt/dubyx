<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting forum migration...\n";

$sql = "CREATE TABLE IF NOT EXISTS forum_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    teacher_id INT DEFAULT NULL,
    parent_id INT DEFAULT 0,
    title VARCHAR(255) DEFAULT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_parent (parent_id),
    INDEX idx_user (user_id),
    INDEX idx_teacher (teacher_id)
) ENGINE=InnoDB";

if ($conn->query($sql)) {
    echo "Table 'forum_posts' created successfully.\n";
} else {
    echo "Error creating table: " . $conn->error . "\n";
}

echo "Migration finished.\n";
?>