<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

$page_title = 'My Tickets';
require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
include 'common/header.php';

$offset = (int) ($_GET['offset'] ?? 0);
$limit = 10;

$tickets = $conn->query("SELECT * FROM tickets 
                         WHERE user_id = $user_id AND user_type = 'student'
                         ORDER BY created_at DESC LIMIT $limit OFFSET $offset");

$total_check = $conn->query("SELECT COUNT(id) as total FROM tickets WHERE user_id = $user_id AND user_type = 'student'")->fetch_assoc();
$has_more = ($offset + $limit) < $total_check['total'];
?>

<main class="p-4 bg-gray-50 min-h-screen pb-20">
    <div class="max-w-lg mx-auto">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-gray-900">My Support Tickets</h2>
            <a href="/help.php" class="text-primary text-xs font-bold uppercase tracking-widest hover:underline">
                <i class="fas fa-plus mr-1"></i>New Ticket
            </a>
        </div>

        <div class="space-y-4">
            <?php if ($tickets->num_rows === 0): ?>
                <div class="bg-white p-12 text-center rounded-xl border-2 border-dashed text-gray-400">
                    <i class="fas fa-ticket-alt text-5xl mb-4 opacity-20"></i>
                    <p class="font-bold">No tickets found.</p>
                    <p class="text-xs mt-1">Raise a ticket from the Help section if you need assistance.</p>
                </div>
            <?php else:
                while ($t = $tickets->fetch_assoc()): ?>
                    <div class="bg-white rounded-xl shadow-sm border p-5">
                        <div class="flex items-start justify-between mb-4">
                            <div class="flex gap-4">
                                <div
                                    class="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-primary border border-gray-100">
                                    <i class="fas fa-ticket-alt"></i>
                                </div>
                                <div>
                                    <h3 class="font-bold text-gray-900 text-sm">
                                        <?php echo clean($t['subject']); ?>
                                    </h3>
                                    <p class="text-[10px] text-gray-400 font-bold uppercase">ID: #
                                        <?php echo $t['id']; ?>
                                    </p>
                                </div>
                            </div>
                            <span
                                class="px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest <?php echo $t['status'] === 'open' ? 'bg-green-100 text-green-600' : ($t['status'] === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'); ?>">
                                <?php echo $t['status']; ?>
                            </span>
                        </div>

                        <div
                            class="bg-gray-50 p-4 rounded-xl border border-gray-100 italic text-xs text-gray-600 leading-relaxed mb-4">
                            "
                            <?php echo nl2br(clean($t['message'])); ?>"
                        </div>

                        <div class="text-[10px] text-gray-400 font-bold uppercase tracking-widest text-right">
                            <?php echo date('d M Y - h:i A', strtotime($t['created_at'])); ?>
                        </div>
                    </div>
                <?php endwhile;
            endif; ?>

            <?php if ($has_more): ?>
                <div class="text-center mt-8">
                    <a href="?offset=<?php echo $offset + $limit; ?>"
                        class="bg-white border text-gray-600 px-6 py-2 rounded-full font-bold text-xs shadow-sm hover:bg-gray-50 transition-all">
                        Load Older Tickets
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include 'common/bottom.php'; ?>