<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

$sql = "ALTER TABLE videos 
        ADD COLUMN is_test TINYINT(1) DEFAULT 0,
        ADD COLUMN start_time DATETIME NULL,
        ADD COLUMN end_time DATETIME NULL,
        ADD COLUMN test_url TEXT NULL";

if ($conn->query($sql)) {
    echo "Table 'videos' updated successfully for Exam Mode.";
} else {
    // Column might already exist if re-running
    if (strpos($conn->error, 'Duplicate column name') !== false) {
        echo "Table already updated.";
    } else {
        echo "Error updating table: " . $conn->error;
    }
}
?>