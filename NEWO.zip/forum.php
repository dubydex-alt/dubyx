<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

// Access Control
if (!isset($_SESSION['user_id']) && !isset($_SESSION['teacher_id'])) {
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;
$teacher_id = $_SESSION['teacher_id'] ?? 0;
$student_teacher_id = $_SESSION['student_teacher_id'] ?? 0;
$admin_id = $_SESSION['admin_id'] ?? 0;

if ($user_id === 0 && $teacher_id === 0 && $admin_id === 0) {
    header('Location: /login.php');
    exit;
}

// Fetch Teacher Context
$eff_teacher_id = $teacher_id > 0 ? $teacher_id : $student_teacher_id;

if ($admin_id === 0) {
    if ($eff_teacher_id === 0) {
        die("Unable to determine instructor context. Please login again.");
    }

    $t_stmt = $conn->prepare("SELECT features, settings FROM teachers WHERE id = ?");
    $t_stmt->bind_param("i", $eff_teacher_id);
    $t_stmt->execute();
    $t_row = $t_stmt->get_result()->fetch_assoc();
    $t_features = json_decode($t_row['features'] ?? '[]', true);
    $t_settings = json_decode($t_row['settings'] ?? '{}', true);

    // Access check
    if (!in_array('community', $t_features)) {
        include 'common/header.php';
        include 'common/sidebar.php';
        echo '<main class="max-w-xl mx-auto pt-12 pb-20 px-4 text-center">
                <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                    <i class="fas fa-lock text-gray-200 text-6xl mb-4"></i>
                    <h1 class="text-xl font-bold text-gray-900">Feature Disabled</h1>
                    <p class="text-gray-500 text-sm mt-2">Community & Discussion is currently disabled by your instructor.</p>
                    <a href="/index.php" class="inline-block mt-6 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold">Go Back Home</a>
                </div>
              </main>';
        include 'common/bottom.php';
        exit;
    }
} else {
    // Admin defaults
    $t_settings = ['disable_student_groups' => false];
}

include 'common/header.php';
include 'common/sidebar.php';
?>

<style>
    /* SPA View Transitions */
    .view-container {
        position: relative;
        overflow: hidden;
        min-height: calc(100vh - 100px);
    }

    .view {
        transition: transform 0.3s ease-out, opacity 0.3s ease-out;
        width: 100%;
    }

    .view.hidden {
        display: none;
        transform: translateX(20px);
        opacity: 0;
    }

    /* Chat Room Specific Styles (Merged from forum_thread.php) */
    .chat-room-container {
        display: flex;
        flex-direction: column;
        height: calc(100vh - 80px);
        /* Adjust based on your header */
        background: #f8fafc;
    }

    .message-area {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        background: #fdfdfd;
        scroll-behavior: smooth;
    }

    .bubble {
        max-width: 80%;
        padding: 10px 14px;
        border-radius: 18px;
        font-size: 13px;
        line-height: 1.5;
        position: relative;
        animation: bubble-in 0.2s ease-out;
    }

    @keyframes bubble-in {
        from {
            transform: translateY(10px);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .bubble.left {
        align-self: flex-start;
        background: white;
        color: #1e293b;
        border: 1px solid #f1f5f9;
        border-bottom-left-radius: 4px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
    }

    .bubble.right {
        align-self: flex-end;
        background: #4f46e5;
        color: white;
        border-bottom-right-radius: 4px;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.15);
    }

    .bubble .author {
        font-size: 9px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 4px;
        color: #94a3b8;
    }

    .bubble.right .author {
        color: #c7d2fe;
    }

    .bubble .time {
        font-size: 8px;
        margin-top: 4px;
        text-align: right;
        opacity: 0.6;
    }

    .sticker-input {
        background: white;
        border-top: 1px solid #f1f5f9;
        padding: 12px 16px;
        position: sticky;
        bottom: 0;
        z-index: 30;
    }
</style>

<main class="max-w-xl mx-auto pt-4 pb-20 px-4 view-container">

    <!-- VIEW 1: Group List & Community Hub -->
    <div id="list-view" class="view">
        <div class="max-w-4xl mx-auto px-4 py-8">
            <!-- Header -->
            <div class="mb-10 text-center">
                <h1 class="text-3xl font-black text-gray-900 mb-2">Student Community</h1>
                <p class="text-gray-500 font-medium">Ask doubts, share knowledge, and learn together.</p>
            </div>

            <!-- Ask Doubt Section -->
            <div class="bg-white rounded-[2rem] shadow-xl shadow-indigo-100/50 p-6 mb-10 border border-indigo-50">
                <div id="post-alert" class="hidden mb-4 p-4 rounded-2xl text-sm font-bold"></div>
                <form id="doubt-form" class="space-y-4" data-no-loader>
                    <input type="hidden" name="action" value="post">
                    <input type="hidden" name="parent_id" value="0">
                    <div class="relative">
                        <textarea name="message" required
                            class="w-full bg-gray-50 border-none rounded-3xl px-6 py-5 text-gray-900 placeholder:text-gray-400 focus:ring-2 focus:ring-indigo-500 min-h-[120px] transition-all"
                            placeholder="Describe your doubt or question here..."></textarea>
                        <div class="absolute right-4 bottom-4">
                            <button type="submit" id="post-btn"
                                class="bg-indigo-600 text-white font-black px-8 py-3 rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
                                Post Doubt
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Doubt Feed -->
            <div id="doubt-feed" class="space-y-8">
                <!-- Doubts will be loaded here -->
            </div>

            <!-- Load More -->
            <div id="load-more-container" class="mt-12 text-center hidden">
                <button id="load-more-btn"
                    class="bg-white border-2 border-indigo-50 text-indigo-600 font-bold px-10 py-4 rounded-[2rem] hover:bg-indigo-50 transition-all flex items-center gap-3 mx-auto">
                    <span>Load More Doubts</span>
                    <i class="fas fa-chevron-down text-xs"></i>
                </button>
            </div>

            <div id="initial-loader" class="py-20 text-center">
                <div
                    class="inline-block w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin">
                </div>
            </div>
        </div>

        <template id="doubt-template">
            <div
                class="doubt-card bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm transition-all hover:shadow-md">
                <div class="flex items-start justify-between mb-6">
                    <div class="flex items-center gap-4">
                        <div
                            class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-xl author-avatar">
                            A
                        </div>
                        <div>
                            <h3 class="font-black text-gray-900 mb-0.5 author-name">Student Name</h3>
                            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest post-time">Time</p>
                        </div>
                    </div>
                    <div
                        class="is-teacher-badge hidden bg-indigo-600 text-white text-[9px] font-black uppercase px-3 py-1 rounded-full tracking-widest">
                        Instructor
                    </div>
                </div>

                <div class="text-gray-700 leading-relaxed mb-8 doubt-message whitespace-pre-wrap">
                    Message body
                </div>

                <hr class="border-gray-50 mb-6">

                <!-- Replies Section -->
                <div class="replies-container space-y-4 mb-6">
                    <!-- Comments go here -->
                </div>

                <!-- Reply Form -->
                <form class="reply-form flex gap-3 items-center" data-no-loader>
                    <input type="hidden" name="action" value="post">
                    <input type="hidden" name="parent_id" class="parent-id-input">
                    <input type="text" name="message" required
                        class="flex-1 bg-gray-50 border-none rounded-2xl px-5 py-3 text-sm focus:ring-1 focus:ring-indigo-200 transition-all"
                        placeholder="Write a reply...">
                    <button type="submit"
                        class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center">
                        <i class="fas fa-paper-plane fa-sm"></i>
                    </button>
                </form>
            </div>
        </template>

        <template id="reply-template">
            <div class="reply-item flex gap-4 p-4 rounded-3xl transition-all border border-transparent">
                <div
                    class="w-8 h-8 rounded-xl bg-gray-50 text-gray-400 flex items-center justify-center font-bold text-xs reply-avatar">
                    R
                </div>
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="font-bold text-gray-900 text-sm reply-author">Author</span>
                        <span
                            class="reply-teacher-badge hidden bg-indigo-100 text-indigo-600 text-[8px] font-black px-2 py-0.5 rounded-full uppercase">Support</span>
                        <span class="text-[9px] text-gray-400 font-bold uppercase reply-time">Time</span>
                    </div>
                    <p class="text-sm text-gray-600 reply-message">Comment body</p>
                </div>
            </div>
        </template>

        <style>
            body {
                background-color: #f8fafc;
            }

            .reply-item.teacher-highlight {
                background-color: #eef2ff;
                border-color: #e0e7ff;
            }
        </style>

        <script>
            const doubtFeed = document.getElementById('doubt-feed');
            const doubtTemplate = document.getElementById('doubt-template');
            const replyTemplate = document.getElementById('reply-template');
            const loadMoreBtn = document.getElementById('load-more-btn');
            const loadMoreContainer = document.getElementById('load-more-container');
            const initialLoader = document.getElementById('initial-loader');

            let offset = 0;
            let isLoading = false;

            // Load initial doubts
            fetchDoubts();

            function fetchDoubts(append = false) {
                if (isLoading) return;
                isLoading = true;

                fetch(`api/forum.php?action=fetch&parent_id=0&offset=${offset}`)
                    .then(res => res.json())
                    .then(data => {
                        initialLoader.classList.add('hidden');
                        if (data.success) {
                            if (!append) doubtFeed.innerHTML = '';

                            data.posts.forEach(post => {
                                doubtFeed.appendChild(createDoubtCard(post));
                            });

                            offset += data.posts.length;
                            if (data.posts.length === 10) {
                                loadMoreContainer.classList.remove('hidden');
                            } else {
                                loadMoreContainer.classList.add('hidden');
                            }
                        }
                        isLoading = false;
                    })
                    .catch(() => { isLoading = false; });
            }

            function createDoubtCard(post) {
                const clone = doubtTemplate.content.cloneNode(true);
                const card = clone.querySelector('.doubt-card');

                card.querySelector('.author-name').innerText = post.author;
                card.querySelector('.author-avatar').innerText = post.author.charAt(0).toUpperCase();
                card.querySelector('.post-time').innerText = post.created_at;
                card.querySelector('.doubt-message').innerText = post.message;
                card.querySelector('.parent-id-input').value = post.id;

                if (post.is_teacher) {
                    card.querySelector('.is-teacher-badge').classList.remove('hidden');
                    card.querySelector('.author-avatar').classList.replace('bg-indigo-50', 'bg-indigo-600');
                    card.querySelector('.author-avatar').classList.replace('text-indigo-600', 'text-white');
                }

                const repliesContainer = card.querySelector('.replies-container');
                fetchReplies(post.id, repliesContainer);

                // Reply form submission
                const form = card.querySelector('.reply-form');
                form.onsubmit = function (e) {
                    e.preventDefault();
                    const btn = form.querySelector('button');
                    const msgInput = form.querySelector('input[name="message"]');
                    const msg = msgInput.value.trim();
                    if (!msg) return;

                    btn.disabled = true;
                    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

                    const formData = new FormData(form);
                    fetch('api/forum.php', { method: 'POST', body: formData })
                        .then(res => res.json())
                        .then(resData => {
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fas fa-paper-plane fa-sm"></i>';
                            if (resData.success) {
                                msgInput.value = '';
                                repliesContainer.appendChild(createReplyItem(resData.post));
                            } else {
                                alert(resData.message);
                            }
                        });
                };

                return card;
            }

            function fetchReplies(doubtId, container) {
                fetch(`api/forum.php?action=fetch&parent_id=${doubtId}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            container.innerHTML = '';
                            data.posts.forEach(reply => {
                                container.appendChild(createReplyItem(reply));
                            });
                        }
                    });
            }

            function createReplyItem(reply) {
                const clone = replyTemplate.content.cloneNode(true);
                const item = clone.querySelector('.reply-item');

                item.querySelector('.reply-author').innerText = reply.author;
                item.querySelector('.reply-avatar').innerText = reply.author.charAt(0).toUpperCase();
                item.querySelector('.reply-time').innerText = reply.created_at;
                item.querySelector('.reply-message').innerText = reply.message;

                if (reply.is_teacher) {
                    item.classList.add('teacher-highlight');
                    item.querySelector('.reply-teacher-badge').classList.remove('hidden');
                    item.querySelector('.reply-avatar').classList.replace('bg-gray-50', 'bg-indigo-600');
                    item.querySelector('.reply-avatar').classList.replace('text-gray-400', 'text-white');
                }

                return item;
            }

            // New Doubt Submission
            document.getElementById('doubt-form').onsubmit = function (e) {
                e.preventDefault();
                const btn = document.getElementById('post-btn');
                const form = e.target;
                const msg = form.querySelector('textarea').value.trim();
                const alertEl = document.getElementById('post-alert');

                if (!msg) return;

                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Posting...';
                alertEl.classList.add('hidden');

                const formData = new FormData(form);
                fetch('api/forum.php', { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        btn.disabled = false;
                        btn.innerHTML = 'Post Doubt';
                        if (data.success) {
                            form.reset();
                            // Prepend the new doubt
                            doubtFeed.prepend(createDoubtCard(data.post));
                        } else {
                            alertEl.innerText = data.message;
                            alertEl.className = "mb-4 p-4 rounded-2xl text-sm font-bold bg-red-50 text-red-600";
                            alertEl.classList.remove('hidden');
                        }
                    })
                    .catch(() => {
                        btn.disabled = false;
                        btn.innerHTML = 'Post Doubt';
                    });
            };

            loadMoreBtn.onclick = () => fetchDoubts(true);
        </script>

        <?php include 'common/bottom.php'; ?>