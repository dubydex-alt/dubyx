<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

/**
 * Secure Video Streaming
 * - Validates session & purchase
 * - Validates stream token
 * - Serves video via readfile() with proper headers
 * - Never exposes direct file path
 */
session_start();

define('IS_API', true); // Prevents direct HTML output on connection error
require_once __DIR__ . '/common/config.php';

// Must be logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit('Access denied');
}

// Must have valid stream token
$token = $_GET['token'] ?? '';
if (empty($token) || !isset($_SESSION['stream_token']) || !hash_equals($_SESSION['stream_token'], $token)) {
    http_response_code(403);
    exit('Invalid token');
}

$video_id = (int) ($_GET['video_id'] ?? 0);
if ($video_id <= 0) {
    http_response_code(400);
    exit('Invalid video');
}

// Get video info with course validation
$stmt = $conn->prepare("
    SELECT v.filename, v.title, ch.course_id 
    FROM videos v 
    JOIN chapters ch ON v.chapter_id = ch.id 
    WHERE v.id = ?
");
$stmt->bind_param("i", $video_id);
$stmt->execute();
$video = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$video) {
    http_response_code(404);
    exit('Video not found');
}

// Check if user purchased the course
$stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND status = 'success'");
$stmt->bind_param("ii", $_SESSION['user_id'], $video['course_id']);
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    http_response_code(403);
    exit('Not purchased');
}
$stmt->close();
$conn->close();

// Serve the video file
$filepath = __DIR__ . '/uploads/videos/' . $video['filename'];
if (!file_exists($filepath)) {
    http_response_code(404);
    exit('File not found');
}

$filesize = filesize($filepath);
$mime = 'video/mp4';

// Support range requests for seeking
$start = 0;
$end = $filesize - 1;
$length = $filesize;

if (isset($_SERVER['HTTP_RANGE'])) {
    $range = $_SERVER['HTTP_RANGE'];
    if (preg_match('/bytes=(\d+)-(\d*)/', $range, $matches)) {
        $start = (int) $matches[1];
        if (!empty($matches[2])) {
            $end = (int) $matches[2];
        }
        $length = $end - $start + 1;
        http_response_code(206);
        header("Content-Range: bytes $start-$end/$filesize");
    }
} else {
    http_response_code(200);
}

header("Content-Type: $mime");
header("Content-Length: $length");
header("Accept-Ranges: bytes");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-Disposition: inline");
// Prevent download
header("X-Content-Type-Options: nosniff");

$fp = fopen($filepath, 'rb');
if ($fp) {
    fseek($fp, $start);
    $sent = 0;
    $chunk_size = 8192;
    while (!feof($fp) && $sent < $length && !connection_aborted()) {
        $read = min($chunk_size, $length - $sent);
        echo fread($fp, $read);
        $sent += $read;
        flush();
    }
    fclose($fp);
}
exit;
