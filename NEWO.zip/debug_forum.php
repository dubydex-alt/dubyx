<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';
header('Content-Type: text/plain');

echo "--- FORUM DEBUG DIAGNOSTICS ---\n\n";

// 1. Check Tables
$tables = ['forum_posts', 'users', 'teachers', 'courses'];
foreach ($tables as $t) {
    echo "Table '$t' exists: " . ($conn->query("SHOW TABLES LIKE '$t'")->num_rows > 0 ? "YES" : "NO") . "\n";
}

echo "\n--- SAMPLE DATA ---\n";

// 2. Sample Posts
$res = $conn->query("SELECT f.id, f.user_id, f.teacher_id, f.course_id, f.title, u.teacher_id as u_teacher_id 
                    FROM forum_posts f 
                    LEFT JOIN users u ON f.user_id = u.id 
                    WHERE f.parent_id = 0 
                    LIMIT 5");
echo "\nRecent Groups (parent_id=0):\n";
if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        print_r($row);
    }
} else {
    echo "No groups found in DB.\n";
}

// 3. User Context Check
echo "\n--- YOUR CURRENT SESSION ---\n";
print_r($_SESSION);

echo "\n--- TEACHER TARGETS ---\n";
if (isset($_SESSION['teacher_id'])) {
    $tid = $_SESSION['teacher_id'];
    $res = $conn->query("SELECT id, title FROM courses WHERE teacher_id = $tid");
    echo "Your Courses:\n";
    while ($row = $res->fetch_assoc()) {
        echo "- {$row['id']}: {$row['title']}\n";
    }
}
?>