<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once '../common/config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$video_id = (int) ($_POST['video_id'] ?? 0);
$detail = $_POST['detail'] ?? '';

if ($action === 'log_security' && $video_id > 0) {
    // Record the violation
    $stmt = $conn->prepare("INSERT INTO exam_violations (user_id, video_id, reason) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $user_id, $video_id, $detail);
    if ($stmt->execute()) {
        log_activity($conn, $user_id, "Exam security violation on video #$video_id: $detail");
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>