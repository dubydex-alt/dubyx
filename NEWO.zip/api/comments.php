<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

session_start();
require_once '../common/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) && !isset($_SESSION['teacher_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;
$teacher_id = $_SESSION['teacher_id'] ?? 0;
$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'post') {
    $live_id = (int) ($_POST['live_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    if ($live_id <= 0 || empty($message)) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        exit;
    }

    // Check if live session is still active
    $stmt = $conn->prepare("SELECT status FROM live_sessions WHERE id = ?");
    $stmt->bind_param("i", $live_id);
    $stmt->execute();
    $session = $stmt->get_result()->fetch_assoc();

    if (!$session || $session['status'] !== 'live') {
        echo json_encode(['success' => false, 'message' => 'Comments are closed for this session.']);
        exit;
    }

    // Check if user is blocked
    if ($user_id > 0) {
        $block_check = $conn->prepare("SELECT id FROM live_blocks WHERE live_id = ? AND user_id = ?");
        $block_check->bind_param("ii", $live_id, $user_id);
        $block_check->execute();
        if ($block_check->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'You are blocked from commenting in this session.']);
            exit;
        }
    }

    if ($teacher_id > 0) {
        $stmt = $conn->prepare("INSERT INTO live_comments (live_id, teacher_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $live_id, $teacher_id, $message);
    } else {
        $stmt = $conn->prepare("INSERT INTO live_comments (live_id, user_id, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $live_id, $user_id, $message);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    exit;
}

if ($action === 'fetch') {
    $live_id = (int) ($_GET['live_id'] ?? 0);
    $last_id = (int) ($_GET['last_id'] ?? 0);

    if ($live_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid session']);
        exit;
    }

    $stmt = $conn->prepare("SELECT lc.*, u.name as user_name, u.id as student_id, t.name as teacher_name
                            FROM live_comments lc 
                            LEFT JOIN users u ON lc.user_id = u.id 
                            LEFT JOIN teachers t ON lc.teacher_id = t.id
                            WHERE lc.live_id = ? AND lc.id > ? 
                            ORDER BY lc.id ASC");
    $stmt->bind_param("ii", $live_id, $last_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Get blocked users for this session
    $blocked = [];
    $b_res = $conn->query("SELECT user_id FROM live_blocks WHERE live_id = $live_id");
    while ($b = $b_res->fetch_assoc())
        $blocked[] = (int) $b['user_id'];

    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = [
            'id' => $row['id'],
            'user' => clean($row['teacher_id'] ? $row['teacher_name'] : $row['user_name']),
            'user_id' => $row['student_id'],
            'message' => clean($row['message']),
            'is_blocked' => in_array($row['student_id'], $blocked),
            'is_teacher' => !empty($row['teacher_id']),
            'time' => date('H:i', strtotime($row['created_at']))
        ];
    }

    echo json_encode(['success' => true, 'comments' => $comments]);
    exit;
}

if ($action === 'block') {
    if (!$teacher_id) {
        echo json_encode(['success' => false, 'message' => 'Only teachers can block users.']);
        exit;
    }

    $live_id = (int) ($_POST['live_id'] ?? 0);
    $target_user_id = (int) ($_POST['user_id'] ?? 0);
    $block = ($_POST['block'] ?? 'true') === 'true';

    if ($live_id <= 0 || $target_user_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        exit;
    }

    // Verify teacher owns the live session
    $stmt = $conn->prepare("SELECT id FROM live_sessions WHERE id = ? AND teacher_id = ?");
    $stmt->bind_param("ii", $live_id, $teacher_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        // Also check if admin (teacher_id 0 in DB means admin-created, but typically teacher_id maps to SESSION teacher_id)
        // For simplicity, checking ownership or admin access
        echo json_encode(['success' => false, 'message' => 'Access denied']);
        exit;
    }

    if ($block) {
        $stmt = $conn->prepare("INSERT IGNORE INTO live_blocks (live_id, user_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $live_id, $target_user_id);
    } else {
        $stmt = $conn->prepare("DELETE FROM live_blocks WHERE live_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $live_id, $target_user_id);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    exit;
}

if ($action === 'load_older') {
    $live_id = (int) ($_GET['live_id'] ?? 0);
    $before_id = (int) ($_GET['before_id'] ?? 0);

    if ($live_id <= 0 || $before_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
        exit;
    }

    $stmt = $conn->prepare("SELECT lc.*, u.name as user_name, u.id as student_id, t.name as teacher_name
                            FROM live_comments lc 
                            LEFT JOIN users u ON lc.user_id = u.id 
                            LEFT JOIN teachers t ON lc.teacher_id = t.id
                            WHERE lc.live_id = ? AND lc.id < ? 
                            ORDER BY lc.id DESC LIMIT 10");
    $stmt->bind_param("ii", $live_id, $before_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = [
            'id' => $row['id'],
            'user' => clean($row['teacher_id'] ? $row['teacher_name'] : $row['user_name']),
            'user_id' => $row['student_id'],
            'message' => clean($row['message']),
            'is_teacher' => !empty($row['teacher_id']),
            'time' => date('H:i', strtotime($row['created_at']))
        ];
    }

    echo json_encode(['success' => true, 'comments' => array_reverse($comments)]);
    exit;
}
?>