<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

/**
 * Simplified Community API (v2) for SkillzUp
 * Centralized Doubt & Comment system.
 */

ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json');
define('IS_API', true);

require_once __DIR__ . '/../common/config.php';

// Global error handler
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno))
        return false;
    echo json_encode(['success' => false, 'message' => "PHP Error: $errstr"]);
    exit;
});

try {
    if (!$conn || $conn->connect_error) {
        echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
        exit;
    }

    $user_id = $_SESSION['user_id'] ?? 0;
    $teacher_id = $_SESSION['teacher_id'] ?? 0;
    $student_teacher_id = $_SESSION['student_teacher_id'] ?? 0;
    $admin_id = $_SESSION['admin_id'] ?? 0;

    $eff_teacher_id = $teacher_id > 0 ? $teacher_id : $student_teacher_id;

    if ($user_id === 0 && $teacher_id === 0 && $admin_id === 0) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
        exit;
    }

    $action = $_GET['action'] ?? $_POST['action'] ?? 'fetch';

    /**
     * ACTION: FETCH (Doubts or Replies)
     */
    if ($action === 'fetch') {
        $parent_id = (int) ($_GET['parent_id'] ?? 0);
        $offset = (int) ($_GET['offset'] ?? 0);
        $limit = ($parent_id === 0) ? 10 : 50; // More replies allowed at once

        $query = "SELECT f.*, 
                         u.name as student_name, u.forum_blocked,
                         t.name as teacher_name,
                         (SELECT COUNT(*) FROM forum_posts WHERE parent_id = f.id) as reply_count
                  FROM forum_posts f
                  LEFT JOIN users u ON f.user_id = u.id
                  LEFT JOIN teachers t ON f.teacher_id = t.id
                  WHERE (f.teacher_id = $eff_teacher_id OR u.teacher_id = $eff_teacher_id OR $admin_id > 0)
                  AND f.parent_id = $parent_id ";

        if ($parent_id === 0) {
            $query .= " ORDER BY f.created_at DESC LIMIT $limit OFFSET $offset";
        } else {
            $query .= " ORDER BY f.id ASC";
        }

        $result = $conn->query($query);
        $posts = [];
        while ($row = $result->fetch_assoc()) {
            $posts[] = [
                'id' => $row['id'],
                'author' => $row['teacher_id'] ? ($row['teacher_name'] ?? 'Instructor') : ($row['student_name'] ?? 'Anonymous'),
                'is_teacher' => !empty($row['teacher_id']),
                'message' => clean($row['message']),
                'reply_count' => $row['reply_count'],
                'created_at' => date('d M, h:i A', strtotime($row['created_at'])),
                'forum_blocked' => $row['forum_blocked'] ?? 0,
                'user_id' => $row['user_id']
            ];
        }

        echo json_encode(['success' => true, 'posts' => $posts]);
        exit;
    }

    /**
     * ACTION: POST (New Doubt or Reply)
     */
    if ($action === 'post') {
        $parent_id = (int) ($_POST['parent_id'] ?? 0);
        $message = trim($_POST['message'] ?? '');

        if (empty($message)) {
            echo json_encode(['success' => false, 'message' => 'Message is required.']);
            exit;
        }

        // Check if blocked (Students only)
        if ($user_id > 0) {
            $check = $conn->query("SELECT forum_blocked FROM users WHERE id = $user_id");
            $u_row = $check->fetch_assoc();
            if ($u_row['forum_blocked'] == 1) {
                echo json_encode(['success' => false, 'message' => 'You are blocked from posting in the community.']);
                exit;
            }
        }

        if ($teacher_id > 0) {
            $stmt = $conn->prepare("INSERT INTO forum_posts (parent_id, teacher_id, message) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $parent_id, $teacher_id, $message);
        } else {
            $stmt = $conn->prepare("INSERT INTO forum_posts (parent_id, user_id, message) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $parent_id, $user_id, $message);
        }

        if ($stmt->execute()) {
            $new_id = $conn->insert_id;
            $fetch = $conn->query("SELECT f.*, u.name as student_name, t.name as teacher_name 
                                    FROM forum_posts f LEFT JOIN users u ON f.user_id = u.id 
                                    LEFT JOIN teachers t ON f.teacher_id = t.id WHERE f.id = $new_id");
            $row = $fetch->fetch_assoc();
            echo json_encode([
                'success' => true,
                'post' => [
                    'id' => $row['id'],
                    'author' => $row['teacher_id'] ? ($row['teacher_name'] ?? 'Instructor') : ($row['student_name'] ?? 'Anonymous'),
                    'is_teacher' => !empty($row['teacher_id']),
                    'message' => clean($row['message']),
                    'created_at' => date('d M, h:i A', strtotime($row['created_at']))
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error.']);
        }
        exit;
    }

    /**
     * ACTION: TOGGLE BLOCK (Teacher/Admin only)
     */
    if ($action === 'toggle_block') {
        if ($teacher_id === 0 && $admin_id === 0) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized.']);
            exit;
        }

        $target_user_id = (int) ($_POST['target_user_id'] ?? 0);
        if ($target_user_id === 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid user ID.']);
            exit;
        }

        $curr = $conn->query("SELECT forum_blocked FROM users WHERE id = $target_user_id");
        $u_row = $curr->fetch_assoc();
        $new_val = ($u_row['forum_blocked'] == 1) ? 0 : 1;

        $upd = $conn->prepare("UPDATE users SET forum_blocked = ? WHERE id = ?");
        $upd->bind_param("ii", $new_val, $target_user_id);
        if ($upd->execute()) {
            echo json_encode(['success' => true, 'blocked' => $new_val, 'message' => $new_val ? 'Student blocked.' : 'Student unblocked.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Update failed.']);
        }
        exit;
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
