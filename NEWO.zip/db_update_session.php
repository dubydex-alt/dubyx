<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

echo "Starting Session Token migration...\n";

$check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'session_token'");
if ($check_column->num_rows == 0) {
    if ($conn->query("ALTER TABLE users ADD COLUMN session_token VARCHAR(255) DEFAULT NULL AFTER onesignal_id")) {
        echo "Column 'session_token' added to 'users' table.\n";
    } else {
        echo "Error adding 'session_token' column: " . $conn->error . "\n";
    }
} else {
    echo "Column 'session_token' already exists in 'users' table.\n";
}

echo "Migration finished.\n";
?>