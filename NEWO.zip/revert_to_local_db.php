<?php
/**
 * revert_to_local_db.php
 * Removes ALL inline mysqli connections and sets the single local one.
 */

$local_conn = '$conn = new mysqli(\'sql301.infinityfree.com\', \'if0_41158662\', \'D2UQHHFoBdbafCp\', \'if0_41158662_backendxtra9\');' . "\n";

$dirs = [
    __DIR__ . '/',
    __DIR__ . '/admin/',
    __DIR__ . '/teacher/',
    __DIR__ . '/api/',
];

$updated = [];

foreach ($dirs as $dir) {
    if (!is_dir($dir))
        continue;
    foreach (glob($dir . '*.php') as $file) {
        if (basename($file) === basename(__FILE__))
            continue;
        if (basename($file) === 'add_inline_db.php')
            continue;

        $content = file_get_contents($file);

        // Remove ANY line starting with $conn = new mysqli (up to first line or two)
        // We use a regex to find and remove any variations of the mysqli connection string
        $new_content = preg_replace('/^\$conn\s*=\s*new\s*mysqli\s*\(.*?\);\s*[\r\n]+/m', '', $content);

        // Ensure it starts with <?php and then our local connection
        if (strpos($new_content, '<?php') === 0) {
            $new_content = substr_replace($new_content, "<?php\n" . $local_conn, 0, 5);

            if ($new_content !== $content) {
                file_put_contents($file, $new_content);
                $updated[] = str_replace(__DIR__ . '/', '', $file);
            }
        }
    }
}

echo "Updated " . count($updated) . " files to local DB.";
?>