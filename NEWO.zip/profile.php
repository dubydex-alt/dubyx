<?php
$conn = new mysqli('sql301.infinityfree.com', 'if0_41158662', 'D2UQHHFoBdbafCp', 'if0_41158662_backendxtra9');

require_once 'common/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

// AJAX Update Profile
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid request.']);
        exit;
    }

    $user_id = $_SESSION['user_id'];

    if ($_POST['action'] === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');

        if (empty($name) || empty($email)) {
            echo json_encode(['success' => false, 'message' => 'Name and email are required.']);
            exit;
        }

        // Check duplicate email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $email, $user_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Email already in use.']);
            $stmt->close();
            exit;
        }
        $stmt->close();

        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, email = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $phone, $email, $user_id);
        if ($stmt->execute()) {
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            log_activity($conn, $user_id, 'Updated profile');
            echo json_encode(['success' => true, 'message' => 'Profile updated!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Update failed.']);
        }
        $stmt->close();
        exit;
    }

    if ($_POST['action'] === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';

        if (strlen($new_pass) < 6) {
            echo json_encode(['success' => false, 'message' => 'New password must be at least 6 characters.']);
            exit;
        }

        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!password_verify($current, $user['password'])) {
            echo json_encode(['success' => false, 'message' => 'Current password is incorrect.']);
            exit;
        }

        $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed, $user_id);
        if ($stmt->execute()) {
            log_activity($conn, $user_id, 'Changed password');
            echo json_encode(['success' => true, 'message' => 'Password changed!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to change password.']);
        }
        $stmt->close();
        exit;
    }
}

// Fetch user data
$stmt = $conn->prepare("SELECT name, phone, email, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$page_title = 'Profile';
include 'common/header.php';
?>

<main class="p-4 max-w-lg mx-auto">
    <!-- Alert -->
    <div id="alert" class="hidden mb-4 p-3 text-sm text-center"></div>

    <!-- Profile Card -->
    <div class="bg-white p-6 mb-4 shadow-sm">
        <div class="flex items-center gap-4 mb-6">
            <div class="w-16 h-16 bg-primary text-white flex items-center justify-center flex-shrink-0">
                <i class="fas fa-user text-2xl"></i>
            </div>
            <div>
                <h2 class="font-bold text-lg text-gray-900"><?php echo clean($user['name']); ?></h2>
                <p class="text-gray-500 text-sm"><?php echo clean($user['email']); ?></p>
                <p class="text-gray-400 text-xs mt-1">Member since
                    <?php echo date('M Y', strtotime($user['created_at'])); ?>
                </p>
            </div>
        </div>

        <form onsubmit="return updateProfile(event)" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input type="text" id="p-name" value="<?php echo clean($user['name']); ?>" required
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input type="tel" id="p-phone" value="<?php echo clean($user['phone'] ?? ''); ?>"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" id="p-email" value="<?php echo clean($user['email']); ?>" required
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>
            <button type="submit" id="btn-profile" class="w-full bg-primary text-white py-3 font-semibold">Save
                Changes</button>
        </form>
    </div>

    <!-- Change Password -->
    <div class="bg-white p-6 mb-4 shadow-sm">
        <h3 class="font-bold text-gray-900 mb-4">Change Password</h3>
        <form onsubmit="return changePassword(event)" class="space-y-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                <input type="password" id="pw-current" required
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                <input type="password" id="pw-new" required minlength="6"
                    class="w-full px-4 py-3 border border-gray-300 bg-white text-gray-900 focus:outline-none focus:border-primary"
                    placeholder="Min 6 characters">
            </div>
            <button type="submit" id="btn-password" class="w-full bg-gray-800 text-white py-3 font-semibold">Change
                Password</button>
        </form>
    </div>

    <!-- Support -->
    <div class="bg-white p-6 mb-4 shadow-sm">
        <h3 class="font-bold text-gray-900 mb-4">Support & Tickets</h3>
        <div class="space-y-3">
            <a href="/mytickets.php"
                class="flex items-center justify-between p-4 bg-gray-50 text-sm font-semibold text-gray-700 hover:bg-gray-100 transition-all">
                <span class="flex items-center gap-3">
                    <i class="fas fa-ticket-alt text-primary"></i> My Support Tickets
                </span>
                <i class="fas fa-chevron-right text-gray-300"></i>
            </a>
            <a href="/help.php"
                class="flex items-center justify-between p-4 bg-gray-50 text-sm font-semibold text-gray-700 hover:bg-gray-100 transition-all">
                <span class="flex items-center gap-3">
                    <i class="fas fa-question-circle text-primary"></i> Help Center
                </span>
                <i class="fas fa-chevron-right text-gray-300"></i>
            </a>
        </div>
    </div>

    <!-- Logout -->
    <a href="/logout.php" class="block w-full bg-red-600 text-white text-center py-3 font-semibold">
        <i class="fas fa-sign-out-alt mr-2"></i>Logout
    </a>
</main>

<script>
    const csrfToken = '<?php echo csrf_token(); ?>';

    function showAlert(msg, type) {
        const el = document.getElementById('alert');
        el.className = 'mb-4 p-3 text-sm text-center ' + (type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200');
        el.textContent = msg;
        el.classList.remove('hidden');
        window.scrollTo(0, 0);
    }

    function updateProfile(e) {
        e.preventDefault();
        const btn = document.getElementById('btn-profile');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Saving...';
        btn.disabled = true;

        const data = new FormData();
        data.append('action', 'update_profile');
        data.append('csrf_token', csrfToken);
        data.append('name', document.getElementById('p-name').value);
        data.append('phone', document.getElementById('p-phone').value);
        data.append('email', document.getElementById('p-email').value);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/profile.php', true);
        xhr.onload = function () {
            btn.innerHTML = 'Save Changes';
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                showAlert(res.message, res.success ? 'success' : 'error');
            } catch (e) { showAlert('Something went wrong.', 'error'); }
        };
        xhr.send(data);
        return false;
    }

    function changePassword(e) {
        e.preventDefault();
        const btn = document.getElementById('btn-password');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Changing...';
        btn.disabled = true;

        const data = new FormData();
        data.append('action', 'change_password');
        data.append('csrf_token', csrfToken);
        data.append('current_password', document.getElementById('pw-current').value);
        data.append('new_password', document.getElementById('pw-new').value);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/profile.php', true);
        xhr.onload = function () {
            btn.innerHTML = 'Change Password';
            btn.disabled = false;
            try {
                const res = JSON.parse(xhr.responseText);
                showAlert(res.message, res.success ? 'success' : 'error');
                if (res.success) {
                    document.getElementById('pw-current').value = '';
                    document.getElementById('pw-new').value = '';
                }
            } catch (e) { showAlert('Something went wrong.', 'error'); }
        };
        xhr.send(data);
        return false;
    }
</script>

<?php include 'common/bottom.php'; ?>