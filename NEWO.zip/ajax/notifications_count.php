<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../common/config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['count' => 0]);
    exit;
}

// $conn is already initialized in common/config.php

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND read_status = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

echo json_encode(['count' => (int) $result['c']]);
